import { Component, OnInit } from '@angular/core';
import { MessageService } from '../services/message.service';
import { UserService } from '../services/user.service';
import { Router, ActivatedRoute } from '@angular/router';
import { OrganizationsService } from '../services/organizations.service';

@Component({
  selector: 'app-organization',
  templateUrl: './organization.component.html',
  styleUrls: ['./organization.component.css']
})
export class OrganizationComponent implements OnInit {
  user:boolean=false
  loginuserdata;
  orgdetails: any;
  rolesdata
  roles
  orgdata
  userslist
  orglist
  Organizationdata
  left
  constructor(private messageService:MessageService,public userService:UserService,private router:Router, private route:ActivatedRoute, private Organizationservice:OrganizationsService) { 
    this.messageService.Connectsocket({type:'connect'});
    this.loginuserdata = JSON.parse(localStorage.getItem('currentUser'));
    console.log(this.loginuserdata);
    this.user = JSON.parse(localStorage.getItem('UserStatus'));
    this.Organizationdata=JSON.parse(localStorage.getItem('orgdata'));
    if(this.user !== false){
    this.step = 'second'
           }
     else{
    this.step 
     }
  
    }

  ngOnInit() {
    this.route.queryParams
    .subscribe(params => {
      console.log(params); 
      this.orgdetails=params.id;
    
    })
    this.Organizationservice.getorganizations().subscribe(data=>{
      console.log(data);
      this.orgdata = data;
      
    })
    // this.userService.getorgusers(this.loginuserdata.id).subscribe(data=>{
    //   console.log(data);
    //   this.roles= data
    // })

    
  }






  step='first'
  go(id)
  {
    console.log(id);
    
    localStorage.setItem('orgdata', JSON.stringify(id));

    var id = id;
    console.log(id);
    this.Organizationservice.getorganizationdetais(id).subscribe(data=>{
       this.orglist =data

      // console.log("55555",this.orglist);
      console.log("999",data);
    })
    var org="Cognitiveinnovations"
    localStorage.setItem('UserStatus', 'true');
    if(this.user == false)
    {
      this.step = 'second'
    }
   
    this.router.navigate(['/organization'], { queryParams: { id:this.orghome,name:org} }); 
  }
  
  change()
  {
    var changepss = 'changepassword'
    this.router.navigate(['/organization'], { queryParams: { id:changepss} });
    
  }
  chngpass(data)
  {
   console.log(data)
  }
  orghome="DashBoard";
  home()
  {
   
 
    this.router.navigate(['/organization'], { queryParams: { id:this.orghome} });
  }

  Employees(id)
  {
 
 
    this.Organizationservice.getorganizationsusers(id).subscribe(data=>{
      this.userslist = data;
      
    });
      var empdetails="Employees"
      this.router.navigate(['/organization'],{queryParams:{id:empdetails}})
  }
  

  homeone()
  {
    this.step='first'
  }
// addRow(row: {Sno: string; Organization: string;  Employee_Name: string;  Employee_Number: string;  Employee_Mail: string; Designation: string}): void {
//     this.groups.push(row);
//  }


  LogOut() {
    if (localStorage.getItem('role') == "admin") this.adminLogout();
    if (localStorage.getItem('role') == "Client") this.UserLogout();
    if (localStorage.getItem('role') == "PremiumUser") this.PremiumUserLogout();
    localStorage.removeItem('orgdata')
  }
  
  adminLogout = function () {
    this.socketDisConnect();
    localStorage.removeItem('currentUser')
    localStorage.removeItem('role')
    localStorage.removeItem('adminloggedIn')
    localStorage.removeItem('profile')
    localStorage.setItem('UserStatus', 'false');
  
    this.userService.setAdminLogout();
    this.login = false;
    this.router.navigate(['']);
  }
  
  UserLogout = function () {
    let obj = {
      email: this.loginuserdata.EmailId,
      loginStatus: 0
    }
    this.userService.updateloginstatus(obj).subscribe(data => {
      console.log(data);
    });
    this.socketDisConnect();
    localStorage.removeItem('currentUser')
    localStorage.removeItem('role')
    localStorage.removeItem('clientloggedIn')
    localStorage.setItem('UserStatus', 'false');
    localStorage.removeItem('profile')
    localStorage.removeItem('chatuser')
    this.userService.setClientLogout();
    this.login = false;
    this.router.navigate(['']);
  }
  PremiumUserLogout = function () {
    this.socketDisConnect();
    localStorage.removeItem('currentUser')
    localStorage.removeItem('role')
    localStorage.removeItem('loggedIn1')
    localStorage.removeItem('profile')
    this.userService.setPremiumUserLogout();
    this.login = false;
    this.router.navigate(['']);
  }

  socketConnect() {
    var type = { type: 'connect' }
    this.messageService.Connectsocket(type).subscribe(socket => {
    });
  }
  //. 0
  socketDisConnect() {//disconnect socket during logout 
    var type = { type: 'disconnect' }
    this.messageService.Connectsocket(type).subscribe(socket => { });
  }
}