import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomenavbarComponent } from './homenavbar/homenavbar.component';
import { LoginComponent } from './login/login.component';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms'
import { UserprofileComponent } from './userprofile/userprofile.component';
import { MyInvitationsComponent } from './my-invitations/my-invitations.component';
import { UprofileComponent } from './uprofile/uprofile.component';
import { ErrorpageComponent } from './errorpage/errorpage.component';
import { NotificationsComponent } from './notifications/notifications.component';
import { MainComponent } from './main/main.component';
import { NavbarComponent } from './navbar/navbar.component';
import { SidenavComponent } from './sidenav/sidenav.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { OrganizationComponent } from './organization/organization.component';

const routes: Routes = [
  { path: '', component: HomenavbarComponent},
  { path: 'login', component: LoginComponent},
  {path:'navbar',component:NavbarComponent,   
  children: [
    {
    path:  'main',
    component:  MainComponent
  },
    { path: 'sidenav', 
    component:SidenavComponent},
   
    {
      path:'dashboard',
      component:DashboardComponent
    },
    { path:"MyInvitations", component:MyInvitationsComponent},
]},
{path:'organization', component:OrganizationComponent},
 
  {
    path:'notifications',
    component:NotificationsComponent
  
  },
  {
    path:"userprofile",
    component:UserprofileComponent
   },
    
    { path: 'Uprofile', component: UprofileComponent },
  { path: 'errorpage', component: ErrorpageComponent},
  
];

@NgModule({
  imports: [BrowserModule,FormsModule, RouterModule.forRoot(routes, {
    onSameUrlNavigation: 'reload',
    enableTracing: false,
  })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
