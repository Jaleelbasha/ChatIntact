import { DateagoPipe } from './dateago.pipe';

describe('DateagoPipe', () => {
  it('create an instance', () => {
    const pipe = new DateagoPipe();
    expect(pipe).toBeTruthy();
  });
});
