import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'search'
})
export class SearchPipe implements PipeTransform {

  transform(searchedUser: any, searchterm: any): any {
    if(!searchterm)
   {
     return null
   }
   {
     return searchedUser.filter(searchedUser=>(searchedUser.EmailId || searchedUser.Name).toLowerCase().indexOf(searchterm.toLowerCase())!==-1)
   }
  }

}
