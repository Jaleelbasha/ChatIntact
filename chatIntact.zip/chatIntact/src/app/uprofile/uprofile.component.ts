import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";
import { FrontEndConfig } from './../frontendconfig';
import { UserService } from '../services/user.service';

@Component({
  selector: 'app-uprofile',
  templateUrl: './uprofile.component.html',
  styleUrls: ['./uprofile.component.css']
})
export class UprofileComponent implements OnInit {

  profile;
  userprofile: any
  userprofilecurrent:any;
  serverurl;
  cnewPassword;
  hide;
  newPassword;
  oldPassword;
  check1;
  check;
  validclick;
  loginClick;
  constructor(private frontendconfig: FrontEndConfig, private router: Router, private userService: UserService) { 
    this.serverurl = this.frontendconfig.getserverurl();

  }

  role: any = localStorage.getItem('role')

  ngOnInit() {
    this.LoadProfile();
  }

  /* 
  Function Name: LoadProfile
  Input: None
  Output: Json
  Desc: Load Profile 
  */
 LoadProfile() {
   this.userService.get('userprofiles/get/current').subscribe(data => {
     this.userprofilecurrent = data;
     console.log("current",this.userprofilecurrent);

     if(!this.userprofile) this.userService.get('users/me').subscribe(data => {
       this.userprofile = data;
       console.log(this.userprofile)
     });
   });
 }

 /* 
 Function Name: UpdateProfile
 Input: None
 Output: None
 Desc: Navigating to other component 
 */

 updateProfile() {
   this.router.navigate(['userprofile'])
 }


 /* 
 Function Name: Change Password
 Input: JSON
 Output: JSON
 Desc: update the password
 */


changePass = function (user) {
  console.log("changepassword", user);
  this.check1 = false;
  this.check = false;
  this.loginClick = true;
  if (user.valid) {
    if (user.value.newPassword === user.value.cnewPassword) {
      this.userService.changePass(user.value).subscribe(data => {
        var result = data;
        console.log(result);
        
        if (result.res == "Success" || result.res == "OK") {
          this.message = "true";
          this.check = true;
          this.loginClick = false;
          user.resetForm();
        }
        else if (result.res == "Fail") {
          this.fmessage = "true";
          this.check1 = true;
        }
      });
    }
    else {
      this.fmessage = "true";
    }
  }
}

back(userForm) {
  userForm.resetForm();
  this.router.navigate(['/navbar/main']); // for user profile back test
}

}
