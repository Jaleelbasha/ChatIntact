import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-otpdialog',
  templateUrl: './otpdialog.component.html',
  styleUrls: ['./otpdialog.component.css']
})
export class OtpdialogComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
