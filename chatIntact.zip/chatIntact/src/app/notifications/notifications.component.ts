import { Component, OnInit } from '@angular/core';
import { NotificationsService } from 'src/app/services/notifications.service';
import { UserService } from '../services/user.service';
import { Router } from '@angular/router';
import { MessageService } from '../services/message.service';

@Component({
  selector: 'app-notifications',
  templateUrl: './notifications.component.html',
  styleUrls: ['./notifications.component.css']
})
export class NotificationsComponent implements OnInit {

  notify; // For notification
  notificationsdata = []
  data;
  loginUser

  constructor(private userService: UserService, private router: Router, private notification: NotificationsService, private messageService: MessageService) {
    this.loginUser = JSON.parse(localStorage.getItem('currentUser'));
    console.log(this.loginUser)
    this.messageService.autoRefreshNotification().subscribe(data => {
      console.log(data)
      this.notification.getNotifications().subscribe(data => {
        this.notify = data
      });
    });
    this.messageService.notifier.subscribe(data => {
      console.log(data);
      this.notificationsdata = data
    });
  }


  ngOnInit() {
    this.notification.getNotifications().subscribe(data => {
      this.notify = data;
      console.log("innotifications", this.notify);
      this.notificationsdata=this.notify;
      this.readAllNotification();
    });
  }

  readAllNotification() {
    this.notification.readAll().subscribe(data => {
      console.log(data);
    });
  }


  delete(info) {
    var index = this.notify.indexOf(info)
    if (index > -1) this.notify.splice(index, 1);
    this.notification.deleteOneNotification(info._id).subscribe(data => { })
  }
  notifications() {
    this.router.navigate(['MyInvitations'])
  }

  
}
