import { Injectable } from '@angular/core';
import { FrontEndConfig } from "../frontendconfig";
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class GroupsService {
  serverurl = this.frontendconfig.getserverurl();

  constructor(private http: HttpClient,private frontendconfig: FrontEndConfig) { }
  
  getgroupdata(id) {

    return this.http.get(this.serverurl + '/api/groups/' + id);
  }
  sendSlug(Group) {
    
    return this.http.post(this.serverurl + '/api/groups/groupsMail', Group)
  }
  addingMember(info){
    console.log("info: ",info);
    return this.http.post(this.serverurl + '/api/groupmembers/addingMembers', info);
    
  }

  gettingMembersList(group) {

    return this.http.get(this.serverurl + '/api/groupmembers/gettingMembers/'+group);
  }
  
  updateGroupMember(info){

    return this.http.post(this.serverurl + '/api/groupmembers/updateStatus', info);
    
  }
  gettingMembersCount(id){
 
    return this.http.get(this.serverurl + '/api/groupmembers/gettingCount/'+id); 
  }
  groupMessage(message){
    
    return this.http.post(this.serverurl + '/api/groupmessages/groupMessages', message);
  }
  getGroupMessages(data){
   
    return this.http.get(this.serverurl + '/api/groupmessages/getMessages/'+data);
    
  }
  getBadgeCount(obj){
    return this.http.post(this.serverurl + '/api/groupmessages/getMessageschat', obj);
  }
  removeBadgeCount(data){
    return this.http.post(this.serverurl + '/api/groupmessages/removeBadgeCount', data);
  }
  leaveGroup(did, gid, id){
    return this.http.delete(this.serverurl + '/api/groupmembers/leaveGroup/'+did+'/'+gid+'/'+id);
  }
  renameGroup(data){
    console.log(data);
    
    return this.http.put(this.serverurl + '/api/groups/rename/name' ,data);
  }
  gInfor(gid, id){
    console.log(gid, id);
    return this.http.get(this.serverurl + '/api/groupmembers/gInfor/'+gid+'/'+id);
    
  }
  gViewMembers(id){
    return this.http.get(this.serverurl + '/api/groupmembers/viewMembers/' + id);
  }

  fetchMemberDetails(id) {
    console.log("ID: ",id);
    return this.http.get(this.serverurl + '/api/groupmembers/getgroups2/' + id);
  }
  checkExits(gid){
    return this.http.get(this.serverurl + '/api/groups/checkingGroupExist/'+gid);
  }
}