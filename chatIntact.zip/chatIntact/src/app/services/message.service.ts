import { Injectable, Output, EventEmitter } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import * as socketIo from 'socket.io-client';
import { Socket } from '../shared/interfaces';
import { FrontEndConfig } from '../frontendconfig';
import { UserService } from './user.service';
import { Observable, Subject } from 'rxjs';
import { NotificationsService } from './notifications.service';
import { PushNotificationsService } from './push-notifications.service';
declare var io: { connect(url: string): Socket; };

import * as RecordRTC from 'recordrtc'; // for recording audio
import * as moment from 'moment';

interface RecordedAudioOutput {
  blob: Blob;
  title: string;
  data: any;
}

@Injectable({
  providedIn: 'root'
})
export class MessageService {

  serverurl: string
  constructor(private http: HttpClient, private router: Router, private userService: UserService, private frontendconfig: FrontEndConfig,
    private notifyService: NotificationsService, private _pushNotifyService: PushNotificationsService) {
    this.serverurl = this.frontendconfig.getserverurl();

  }
  socket: Socket;
  observer: any;
  profile: any;
  // Audio parameters
  private stream;
  private recorder;
  private interval;
  private startTime;
  private _recorded = new Subject<RecordedAudioOutput>();
  private _recordingTime = new Subject<string>();
  private _recordingFailed = new Subject<string>();
  getRecordedBlob(): Observable<RecordedAudioOutput> {
    return this._recorded.asObservable();
  }

  getRecordedTime(): Observable<string> {
    return this._recordingTime.asObservable();
  }

  recordingFailed(): Observable<string> {
    return this._recordingFailed.asObservable();
  }

  @Output() notifier: EventEmitter<boolean> = new EventEmitter();


  Connectsocket(type): Observable<number> {
    console.log('type', type.type)
    if (type.type === 'disconnect') {
      this.socket.emit("userDisconnect", "this.profile._id");
      this.profile = "disconnected";
    }

    if (type.type == 'connect') {
      this.socket = socketIo(this.serverurl);
      this.userService.userprofile().subscribe(data => {
        this.profile = data;
        this.socket.emit("info", this.profile._id);

        // offline Notifications 
        this.notifyService.getNotifications().subscribe(result => {
          let offlinedata: Array<any> = [];
          var i = 1;
          var messages: any = result;
          this.notifier.emit(messages);
          let count = 0;
          for (const message of messages) {
            if (this.profile && !message.read && message.status == 'Pending' && message.receiverid._id == this.profile._id) {
              offlinedata.push({
                'title': message.type,
                'alertContent': `${message.type} Bby ${message.senderId.Name}`,
                'data': message.senderId.Name
              });
              message.read = true;
              this.notifyService.markAsRead(message).subscribe(read => { });
            }

            // offline push notification messages push
            if (i++ == messages.length) {
              if (count) {
                offlinedata.push({
                  'title': 'Message',
                  'alertContent': `${message.type} Byy ${message.senderId.Name}`,
                  'data': count
                });
              }
            }
          }
          this._pushNotifyService.generateNotification(offlinedata);
        });
      });

      // Notification Message Socket
      this.socket.on('notification:save', (res) => {
        var data = [];
        if (res && !res.read) {
          console.log("Message Socket", res);
          if (res.receiverid._id == this.profile._id) {
            data.push({ 
              'title': res.type,
              'alertContent': `${res.type}  ${res.status} By ${res.senderId.Name}`,
            })
          }
        }

        this._pushNotifyService.generateNotification(data);
      });

      /////// group notifications
      this.socket.on('groupNotifications:save', (res) => {
        console.log("Message Socket", res);
        var data = [];
        if (res && res.read == true) {
          if (res.senderId._id == this.profile._id) {
            data.push({
              'title': res.type,
              'alertContent': `${res.type}  ${res.status} By ${res.receiverid.Name}`,
            })
          }
          else {
            if (res.receiverid._id == this.profile._id) {
              data.push({
                'title': res.type,
                'alertContent': `${res.type}  ${res.status} By ${res.senderId.Name}`,
              })
            }
          }
        }

        this._pushNotifyService.generateNotification(data);
      });
    }
    Observable.create(observer => {
      this.observer = observer
    });
    return this.createObservable();
  }

  createObservable(): Observable<number> {
    return new Observable<number>(observer => {
      this.observer = observer;
    });
  }
  /*
  
  */
  startSubscriber(userId) {
    console.log(userId);
    var obj = { userId: userId }
    return this.http.post(this.serverurl + '/api/messages/subscriber', obj);
  }

  /*
  Function Name: autorefreshFriends
  Input: None
  Output: JSON -- {new friend data}
  Desc: When user accepts friendrequest from invitations it will emit the backend from that we are subscribing the data through socket.on('friendslist:save')
  */

  autorefreshFriends() {
    let observable = new Observable<any>(observer => {
      if (this.socket)
        this.socket.on('friendslist:save', (data) => {
          observer.next(data); // for subscribe it will emit
        });
    });
    return observable;
  }



  // Notification refresh test
  autoRefreshNotification() {
    let observable = new Observable<any>(observer => {
      if (this.socket)
        this.socket.on('notification:save', (data) => {
          observer.next(data);
        });
    });
    return observable;
  }



  // Auto refresh groups
  autoRefreshGroups() {
    let observable = new Observable<any>(observer => {
      if (this.socket)
        this.socket.on('groupsGetting:save', (data) => {
          observer.next(data);
        });
    });
    return observable;
  }

  autoRefreshMemberStatus() {
    let observable = new Observable<any>(observer => {
      if (this.socket)
        this.socket.on('updateGroup:save', (data) => {
          observer.next(data);
        });
    });
    return observable;
  }


  autoRefreshremoveNotification() {
    let observable = new Observable<any>(observer => {
      if (this.socket)
        this.socket.on('notification:remove', (data) => {
          observer.next(data);
        });
    });
    return observable;
  }

  autoRefreshBadgeCount() {
    let observable = new Observable<any>(observer => {
      if (this.socket)
        this.socket.on('friendsdata:save', (data) => {
          observer.next(data);
        });
    });
    return observable;
  }

  // Message refresh test
  autoRefresMessage() {
    let observable = new Observable<any>(observer => {
      if (this.socket)
        this.socket.on('message', (data) => {
          console.log("emit function", data)
          observer.next(data);

        });
    });

    return observable;
  }
  autoRefreshEditedMessage(){
    let observable = new Observable<any>(observer => {
      if (this.socket)
        this.socket.on('editedMessage:save', (data) => {
          console.log("emit function", data)
          observer.next(data);
        });
    });
    return observable;
  }

  //auto refesh group messages
  autoRefreshGroupMessage() {
    let observable = new Observable<any>(observer => {
      if (this.socket)
        this.socket.on('gmessages:save', (data) => {
          console.log(data);
          observer.next(data);
        });
    });
    return observable;
  }
  // Auto refresh group edit messages
  autoRefreshGroupEditMessage(){
    let observable = new Observable<any>(observer => {
      if (this.socket)
        this.socket.on('gedit:save', (data) => {
          console.log(data);
          observer.next(data);
        });
    });
    return observable;
  }

  // auto refresh group removing badge count
  // autoRefreshGroupRemoveBadgeCount() {
  //   let observable = new Observable<any>(observer => {
  //     if (this.socket)
  //       this.socket.on('gcount:save', (data) => {
  //         console.log(data);
  //         observer.next(data);
  //       });
  //   });
  //   return observable;
  // }
  // auto refresh leave groups
  autoRefreshLeaveGroup() {
    let observable = new Observable<any>(observer => {
      if (this.socket)
        this.socket.on('gleave:save', (data) => {
          console.log(data);
          observer.next(data);
        });
    });
    return observable;
  }
  // rename the group
  autoRefreshRenameGroup() {
    let observable = new Observable<any>(observer => {
      if (this.socket)
        this.socket.on('grename:save', (data) => {
          console.log(data);
          observer.next(data);
        });
    });
    return observable;
  }
  autoRefreshRemoveMessage() {
    let observable = new Observable<any>(observer => {
      if (this.socket)
        this.socket.on('message:remove', (data) => {
          console.log(data);
          observer.next(data);
        });
    });
    return observable;
  }

  autoRefreshundoMessage() {
    let observable = new Observable<any>(observer => {
      if (this.socket)
        this.socket.on('message:undo', (data) => {
          console.log("Undo Message: ", data);
          observer.next(data);
        });
    });
    return observable;
  }
  autoRefreshBlockdata() {
    let observable = new Observable<any>(observer => {

      if (this.socket)
        this.socket.on('blockdata', (data) => {
          observer.next(data);
        });
    });
    return observable;
  }

  autoRefreshPriorityResponse() {
    let observable = new Observable<any>(observer => {

      if (this.socket)
        this.socket.on('priorityresponse', (data) => {

          observer.next(data);
        });
    });
    return observable;
  }

  autoRefreshDeletingAllMessages() {
    let observable = new Observable<any>(observer => {
      if (this.socket)
        this.socket.on('deletingallmsg', (data) => {
          console.log(data);
          observer.next(data);
        })
    })
    return observable;
  }

  sendMessage(data) {
    console.log(data);
    return this.http.post(this.serverurl + '/api/messages', data);
  }


  getMessages(data) {
    return this.http.get(this.serverurl + '/api/messages/' + data)
  }

  getmydata(id) {
    console.log("id", id);
    var id = id._id
    return this.http.get(this.serverurl + '/api/invitations/getme', id);
  }

  saveFiles(formData: any) {
    return this.http.post(this.serverurl + '/api/medias', formData);
  }
 // This is for paste url link in to the input field
  videoUrl(data) 
  {
    console.log(data,'ff');
    
    return this.http.post(this.serverurl + '/api/medias/urldata',data);
  }
  // This is for user login or logout status by emit function from msg controller
  autoUserStatus() {
    const observable = new Observable<any>(observer => {
      if (this.socket)
        this.socket.on("userloginstatus", (data) => {
          observer.next(data)
        })
    });
    return observable;
  }


  // This is for msg read reciepts 
  autoMsgReadReciept() {
    let observable = new Observable<any>(observer => {
      if (this.socket)
        this.socket.on("msgReadRecipts", (data) => {
          observer.next(data)
        })
    })
    return observable;
  }


  staredMessages(data) {
    console.log(data)
    return this.http.post(this.serverurl + '/api/messages/staredMessage', data)
  }

  // for clearing the message db
  deletingMsgs(data) {
    return this.http.post(this.serverurl + '/api/messages/deletingMsgs', { data })
  }

  // This is for msg read reciepts
  msgSeen(data) {
    return this.http.post(this.serverurl + '/api/messages/seenMsg', data)
  }

  blocking(blockingdata) {
    return this.http.post(this.serverurl + '/api/messages/blocking', blockingdata)
  }

  unstaredMessages(data) {
    console.log(data)
    return this.http.post(this.serverurl + '/api/starredmessages/unstar', data)
  }


  // audio recording functions
  startRecording() {
    console.log('hello receive')
    if (this.recorder) {
      // It means recording is already started or it is already recording something
      return;
    }
    this._recordingTime.next('00:00');
    navigator.mediaDevices.getUserMedia({ video: false, audio: true }).then(s => {
      this.stream = s;
      console.log(this.stream);
      this.record();
    }).catch(error => {
      console.log(error)
      this._recordingFailed.next();
    });
  }

  abortRecording() {
    this.stopMedia();
  }

  private record() {
    this.recorder = new RecordRTC.StereoAudioRecorder(this.stream, {
      type: 'audio',
      mimeType: 'audio/webm'
    });

    this.recorder.record();
    this.startTime = moment();
    this.interval = setInterval(
      () => {
        const currentTime = moment();
        const diffTime = moment.duration(currentTime.diff(this.startTime));
        const time = this.toString(diffTime.minutes()) + ':' + this.toString(diffTime.seconds());
        this._recordingTime.next(time);
      },
      1000
    );
  }

  private toString(value) {
    let val = value;
    if (!value) {
      val = '00';
    }
    if (value < 10) {
      val = '0' + value;
    }
    return val;
  }

  stopRecording() {
    if (this.recorder) {
      this.recorder.stop((blob) => {
        console.log("test", blob);
        if (this.startTime) {
          const mp3Name = encodeURIComponent('audio_' + new Date().getTime() + '.mp3');
          this.stopMedia();
          this._recorded.next({ blob: blob, title: mp3Name, data: blob });
        }
      }, () => {
        this.stopMedia();
        this._recordingFailed.next();
      });
    }
  }

  private stopMedia() {
    if (this.recorder) {
      this.recorder = null;
      clearInterval(this.interval);
      this.startTime = null;
      if (this.stream) {
        this.stream.getAudioTracks().forEach(track => track.stop());
        this.stream = null;
      }
    }
  }


  // This function will execute at the time of page loading for getting block status 
  blockingdata(blockingdata1) {
    console.log(blockingdata1)
    return this.http.post(this.serverurl + '/api/messages/blocking1', blockingdata1)
  }

  // This function will execute when user clicks on block button for getting response
  blockingData(blockingdata2) {
    console.log(blockingdata2)
    return this.http.post(this.serverurl + '/api/messages/blocking2', blockingdata2)
  }

  // This function will execute when user clicks on NotifyMe button 
  slideData(data) {
    console.log(data)
    return this.http.post(this.serverurl + '/api/messages/slide', data)
  }
  sendEditMessage(Data) {
    return this.http.post(this.serverurl + '/api/messages/updatingMessage', Data)
  }
  sendEditGroupMessage(data){
    return this.http.post(this.serverurl + '/api/groupmessages/editMessage', data);
  }

  // Forwarding message to multiple users
  forwardmsg(userdata) {
    return this.http.post(this.serverurl + '/api/messages/forwardmsg', userdata)
  }

  // This function will exectue when user clicks 
  starmsg(starmsgs) {
    return this.http.post(this.serverurl + '/api/messages/starmsg', starmsgs)
  }

  // This function will execute when user clicks on hide or show message button
  hidemessage(data) {
    console.log("data: ", data)
    return this.http.post(this.serverurl + '/api/friendslists/hideshow', data)
  }

  // This function will exectute when user clicks on active hide users 
  activehideuser(data) {
    console.log(data);
    return this.http.post(this.serverurl + '/api/friendslists/activehideusers', { data })
  }

  // This is for active hide user
  hideuser(hideuserdata) {
    console.log(hideuserdata);
    return this.http.post(this.serverurl + '/api/friendslists/hideuser', hideuserdata)
  }

  // This is for reply to exact message
  replymsg(data) {
    console.log(data);
    return this.http.post(this.serverurl + '/api/messages/replyingmsg', data)
  }

  //This is for incognito chat socket.emit function
  incognitochat() {
    let observable = new Observable<any>(observer => {
      if (this.socket)
        this.socket.on('incognito:chat', (data) => {
          console.log(data);
          observer.next(data);
        })
    })
    return observable;
  }

  // This is for incognito chat accept
  incognitoACCEPT2(data){
    console.log("57555555555555555",data) 
    return this.http.post(this.serverurl+ '/api/messages/incognitoaccept3',data)
  }

  // This is for incognito chat accept emit function
  INCOGNITOCHATACCEPT6() {
    let observable = new Observable<any>(observer => {
      if (this.socket)
        this.socket.on('incogacp5', (data) => {
          console.log("incogacp5",data)
          observer.next(data)
        })
    })
    return observable;
  }

  // This is for incognito chat reject   
  incognitoReject2(data){
    console.log(data)
    return this.http.post(this.serverurl+ '/api/messages/incognitoReject3',data)
  }

  // This is for incognito chat reject emit function
  incognitoRejectemit() {
    let observable = new Observable<any>(observer => {
      if (this.socket)
        this.socket.on('incogrjt', (data) => {
          console.log(data)
          observer.next(data)
        })
    })
    return observable;
  }

  // This is for incognito delete response
  incognitoDeleteResponse(){
    let observable = new Observable<any>(observer =>{
      if(this.socket)
      this.socket.on('incognitodelres',(data)=>{
        console.log(data)
        observer.next(data)
      })
    })
    return observable;
  }

  // This is for showresponse null
  showres(data){
    console.log(data)
    return this.http.post(this.serverurl+ '/api/messages/showresp',data)
  }


  // This is for incognitoRes null 
  incognitoshowres(){
    let observable = new Observable<any>(observer =>{
      if(this.socket)
      this.socket.on('showresnull',(data)=>{
        console.log("6333333",data)
        observer.next(data)
      })
    })
    return observable;
  }


// This is for message remove favourite socket emit function
messageRemoveFavouite(){
  let observable = new Observable<any>(observer =>{
    if(this.socket)
    this.socket.on('msgremfav',(data)=>{
      console.log("msgremfavvvvvvvv",data)
      observer.next(data)
    })
  })
  return observable;
}


// This is for when user in block state incognito chat request not sending 
incognitoBlockstate(data){
console.log(data)
return this.http.post(this.serverurl+ '/api/messages/incognitoblock',data)
}

}





