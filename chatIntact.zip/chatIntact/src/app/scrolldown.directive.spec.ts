import { ScrolldownDirective } from './scrolldown.directive';

describe('ScrolldownDirective', () => {
  it('should create an instance', () => {
    const directive = new ScrolldownDirective();
    expect(directive).toBeTruthy();
  });
});
