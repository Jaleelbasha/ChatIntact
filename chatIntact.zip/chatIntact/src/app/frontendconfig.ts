export class FrontEndConfig {

  constructor() { }

 serverurl = "http://localhost:9000"

  getserverurl() {
    return this.serverurl;
  }
}
//https://nodescm.webchatbot.co.uk
