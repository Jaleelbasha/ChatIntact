import { Component, OnInit } from '@angular/core';
import { UserService } from 'src/app/services/user.service';
import { Router, ActivatedRoute } from '@angular/router';
import { NotificationsService } from 'src/app/services/notifications.service';
import { MessageService } from 'src/app/services/message.service';
import { config } from 'src/app/configFile';
import { trigger, state, style, transition, animate } from '@angular/animations';
import { GroupsService } from '../services/groups.service';
import { MatSnackBar } from '@angular/material';
import { Subscription } from 'rxjs';
import { FrontEndConfig } from '../frontendconfig';
import { isNullOrUndefined } from 'util';
@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css'],
  animations: [
    trigger('slideInOut', [
      state('in', style({
        transform: 'translate3d(0,0,0)'
      })),
      state('out', style({
        transform: 'translate3d(100%, 0, 0)'
      })),
      transition('in => out', animate('400ms ease-in-out')),
      transition('out => in', animate('400ms ease-in-out'))
    ]),
    trigger('slideInOut1', [
      state('in', style({

        transform: 'translate3d(0, 0, 0)'
      })),
      state('out', style({
        transform: 'translate3d(100%,0,0)'
      })),
      transition('in => out', animate('400ms ease-in-out')),
      transition('out => in', animate('400ms ease-in-out'))
    ]),
    trigger('slideInOut2', [
      state('in', style({
        transform: 'translate3d(0,0,0)'
      })),
      state('out', style({
        transform: 'translate3d(-100%, 0, 0)',
        left: '-6rem'
      })),
      transition('in => out', animate('400ms ease-in-out')),
      transition('out => in', animate('400ms ease-in-out'))
    ]),
  ]
})
export class NavbarComponent implements OnInit {
  subscription: Subscription
  loginuserdata;
  _id;
  weburl;
  urllink;
  alreadyreg: Boolean;
  response: any;
  nodata: Boolean = false
  emailcheck: Boolean = false
  error: any;
  sendMailres
  recmail
  recevData;
  subsVar: any;
  newcount = 0;
  notify1: any;
  menuState: string = 'out';
  notificationState: string = 'out';
  Name: any;
  isShown = false;
  isShown1 = false;
  isShown2 = true;
  butnclick = false;
  userprofiledata: any;
  uprofile: any
  userForm: any;
  viewNotifiction: boolean = false;
  listusers: any;
  notify; // For notification
  notificationsdata = []
  data;
  loginUser;
  sentInvitations:any=[];
  Emailid

  Userdetails: any;
  selectedUser: any;
  groups: any;
  groupInvitations: any = [];
  x: boolean;
  contactpage: string = 'out';
  zindex: boolean;
  searchenable: boolean;
  invitefriendres: any;
  regresponse: any;
  viewcontact: boolean;
  serverurl: any;

  dashboardactive: boolean;
  notificationactive: boolean;
  contactactive: boolean;
  chatactive: boolean;
  groupactive: boolean;
  onScroll: any;
  pic: Boolean;
  Groups: any;
  profileresponse;
  isphotoClicked:Boolean=false;
imagePreview: any;
filesToUpload: Array<File> = [];
imagedata;
searchterm;
personadd;
invitationview;
EmailId;
menu;
  autoRefreshFriendsUn:Subscription;
  autoRefreshGroupsUn:  Subscription;
  autoRefreshNotificatioUn: Subscription;



  constructor(private groupsService: GroupsService, private configs: config, private userService: UserService, private router: Router, private frontendconfig: FrontEndConfig, private notification: NotificationsService, private messageService: MessageService, private route: ActivatedRoute, private snackbar: MatSnackBar) {
    this.weburl = this.configs.getWeburl();
    if (localStorage.getItem('role')) this.socketConnect();
    if (localStorage.getItem('role')) {
      this.autoRefreshNotify();

    }

    //getting freinds for passing query params
    this.userService.getFriends(this._id).subscribe(users => {
      this.listusers = users;
    })



    this.serverurl = this.frontendconfig.getserverurl(); // for image url

    this.clientNotificationValue();
    // Service invoking for Notification count
    this.messageService.notifier.subscribe(data => {
      var notify = data;
      console.log("Notification count", data)
      // this.newcount = notify.filter(x => !x.read).length;
      this.newcount = notify.filter(x => !x.read && x.receiverid._id==this._id).length;
    });

    this.autoRefreshNotificatioUn=this.messageService.autoRefreshNotification().subscribe(data => {
      console.log(data)
      this.notification.getNotifications().subscribe(data => {
        this.notify = data;
        console.log(this.notify)
        this.newcount = this.notify.filter(x => !x.read && x.receiverid._id==this._id).length;
         console.log(this.newcount);

      });
    });
    this.autoRefreshGroupsUn=this.messageService.autoRefreshGroups().subscribe(data => {
      console.log(data)
      this.notification.getNotifications().subscribe(data => {
        this.notify = data;
        this.newcount = this.notify.filter(x => !x.read).length;
        console.log(this.newcount);
        
      });
    });
    this.autoRefreshFriendsUn=this.messageService.autorefreshFriends().subscribe(data => {
      console.log("autofriends list", data);
      if (data.senderId._id == this._id || data.receiverid._id == this._id) {
        this.userService.getFriends(this._id).subscribe(users => {
          this.listusers = users;
          this.listusers.push(data);
          console.log("updated list", this.listusers);
        })
      }
    });
  };

  ngOnInit() {
    this.LoadProfile()
    this.loginuserdata = JSON.parse(localStorage.getItem('currentUser'));
    this.Name = this.loginuserdata.Name
    if (this.loginuserdata.id) this._id = this.loginuserdata.id;
    this.Emailid = this.loginuserdata.EmailId;
    this.createSlug(this.loginuserdata);
    // Service invoking for Notification count
    //  this.messageService.notifier.subscribe(data => {
    //    var notify = data;
    //    console.log("Notification count",data)
    //    this.newcount = notify.filter(x => !x.read).length;
    //  });   
    //getting groups for passing query params
    this.userService.getGroupss(this._id).subscribe(groups => {
      this.Groups = groups;
    })
    this.userService.getInvitations(this.loginuserdata.id).subscribe(invitations => {
      {
        this.sentInvitations = invitations;
       
        console.log(this.sentInvitations)
      }
    });
    this.userService.getGroupInvitations(this.loginuserdata.id).subscribe(invitations => {
      console.log(invitations);
   
   this.groupInvitations = invitations; 
      console.log(this.groupInvitations);

    })
  }
  update(data, status, i) {
    console.log(status, data, i);
    var updatedata = {
      senderId: data.senderId._id,
      receiverid: data.receiverid._id,
      from: this.loginuserdata.EmailId,
      to: data.to,
      status: status,
      _id: data._id
    }
    console.log(updatedata)
    this.userService.Updatestatus(updatedata).subscribe(res => {
      this.sentInvitations.splice(i, 1)
      this.sentInvitations.push(res)
      console.log(this.sentInvitations)
      console.log("response from backend", res);

    });
  }
  test:any;
  //Updating group members
  updateGroup(data, status, i) {
    console.log(this.groupInvitations);
    
    console.log(data, status, i);
    var info = {
      id: data._id,
      status: status
    }
    console.log("info: ",info)
    this.groupsService.updateGroupMember(info).subscribe((res:any) => {
      console.log("res: ",res)
      console.log(typeof res)
      this.groupInvitations.splice(i, 1)
      // this.groupInvitations.push(res);
      if(res === 'Rejected'){
        console.log(res);
      }
      else{
       
        console.log(res.GroupId._id, res.GroupId.GroupName);
      
        this.router.navigate(['/navbar/main'], { queryParams: { gid:res.GroupId._id, gname:res.GroupId.GroupName, value : true}});
        
      }
      
    })
  }

  toggleMenu() {
    this.isShown = !this.isShown;
    this.menuState = this.menuState === 'out' ? 'in' : 'out';
    this.isShown1 = false;
    this.isShown2 = true;
    this.butnclick = false;
    this.zindex = false;
    this.dashboardactive = false;
    this.groupactive = false;
    this.notificationactive = false;
    this.chatactive = false;
    this.contactactive = false;
    //this.LoadProfile()
  }
  close() {
    this.menuState = this.menuState === 'out' ? 'in' : 'out';
    this.isShown = false;
    this.butnclick=false;
    this.isShown2=true;
    this.isShown1=false
    this.imagePreview=null

  }
  close1() {
    console.log("Inside close function")
    this.notificationState = this.notificationState === 'out' ? 'in' : 'out';
    this.isShown = false;
    this.notificationactive=false;
  }
  edit() {
    this.butnclick = true;
    this.isShown1 = true;
    this.isShown2 = false;
    this.imagePreview=null
  }
  back() {
    this.butnclick = false;
    this.isShown1 = false;
    this.isShown2 = true;
  }
  logOut() {
    if (localStorage.getItem('role') == "admin") this.adminLogout();
    if (localStorage.getItem('role') == "Client") this.UserLogout();
    if (localStorage.getItem('role') == "PremiumUser") this.PremiumUserLogout();
  }

  adminLogout = function () {
    this.socketDisConnect();
    localStorage.removeItem('currentUser')
    localStorage.removeItem('role')
    localStorage.removeItem('adminloggedIn')
    localStorage.removeItem('profile')

    this.userService.setAdminLogout();
    this.login = false;
    this.router.navigate(['']);
  }

  UserLogout = function () {
    let obj = {
      email: this.loginuserdata.EmailId,
      loginStatus: 0
    }
    this.userService.updateloginstatus(obj).subscribe(data => {
      console.log(data);
    });
    this.socketDisConnect();
    localStorage.removeItem('currentUser')
    localStorage.removeItem('role')
    localStorage.removeItem('clientloggedIn')
    localStorage.removeItem('profile')
    localStorage.removeItem('chatuser')
    this.userService.setClientLogout();
    this.login = false;
    this.router.navigate(['']);
  }
  PremiumUserLogout = function () {
    this.socketDisConnect();
    localStorage.removeItem('currentUser')
    localStorage.removeItem('role')
    localStorage.removeItem('loggedIn1')
    localStorage.removeItem('profile')
    this.userService.setPremiumUserLogout();
    this.login = false;
    this.router.navigate(['']);
  }

  profile() {
    this.router.navigate(['Uprofile'])
    this.x = true;
  }
  myinvitations() {
    this.router.navigate(['MyInvitations'])

  }

  navigate() {
    this.x = true;
    if(this.listusers.length <= 0){
      this.router.navigate(['/navbar/main'],{ queryParams: { value: false } });
    }
    if(this.listusers.length > 0)
    {
    if (this._id == this.listusers[0].receiverid._id) {
      this.router.navigate(['/navbar/main'], { queryParams: { id: this.listusers[0]._id, userid: this.listusers[0].senderId._id, value: false } });
    }
    else if (this._id == this.listusers[0].senderId._id) {
      this.router.navigate(['/navbar/main'], { queryParams: { id: this.listusers[0]._id, userid: this.listusers[0].receiverid._id, value: false } });

    }
  }

    this.dashboardactive = false;
    this.groupactive = false;
    this.notificationactive = false;
    this.chatactive = true;
    this.contactactive = false;

  }
  navigateToGroup() {
    this.dashboardactive = false;
    this.groupactive = true;
    this.notificationactive = false;
    this.chatactive = false;
    this.contactactive = false;
    if(this.Groups){
      this.router.navigate(['/navbar/main'], { queryParams: { value: true } });
    }
    else{
      this.router.navigate(['/navbar/main'], { queryParams: { gid:this.Groups[0].GroupId._id, gname:this.Groups[0].GroupId.GroupName, value : true}});
    }
   

  }

  // 1
  autoRefreshNotify() {
    this.messageService.autoRefreshNotification().subscribe(data => {
      this.clientNotificationValue();
    });
  }

  // 2
  RemoveRefreshNotify() {
    this.messageService.autoRefreshremoveNotification().subscribe(data => {
      if (localStorage.getItem('role') == "Client") this.clientNotificationValue();
    });
  }
  //
  socketConnect() {
    var type = { type: 'connect' }
    this.messageService.Connectsocket(type).subscribe(socket => {
    });
  }
  //. 0
  socketDisConnect() {//disconnect socket during logout 
    var type = { type: 'disconnect' }
    this.messageService.Connectsocket(type).subscribe(socket => { });
  }

  // 0
  refreshNav() {
    this.subsVar = this.userService.refreshNav.subscribe(data => {
      if (data == "yes") {
        if (localStorage.getItem('role')) {
          this.socketDisConnect();
          this.socketConnect();
        }
        this.ngOnInit();
      }
    })
  }
  clientNotificationValue() {
    var notify;
    this.notification.getNotifications().subscribe(data => {
      notify = data;
      console.log(data)
      this.newcount = notify.filter(x => !x.read && x.receiverid._id == this._id).length;
      console.log(this.newcount)
    });
  }



  Notifications() {
    //  to stop  navigating to other page
    //  this.router.navigate(['/notifications']);
    this.newcount = 0
    this.viewNotifiction = !this.viewNotifiction;
    this.notificationState = this.notificationState === 'out' ? 'in' : 'out';
    this.isShown = !this.isShown;
    this.zindex = false;
    this.dashboardactive = false;
    this.groupactive = false;
    this.notificationactive = true;
    this.chatactive = false;
    this.contactactive = false;
  }
  /*
 Function Name: LoadProfile
 Input: None
 Output: Json
 Desc: Load Profile
 */
  LoadProfile() {
    this.LoadUserProfile();

    this.userService.get('users/me').subscribe(data => {
      this.uprofile = data;
      console.log("me", this.uprofile)

    });
  }

  LoadUserProfile() {
    this.userService.get('userprofiles/get/current').subscribe(data => {
      this.userprofiledata = data;
      console.log("currentuserprofile", this.userprofiledata);
      if (!this.userprofiledata)
        if (this.userprofiledata) this.disp(this.userprofiledata);
    })
  }


  disp = function (profile) {
    this.LoadData['FullName'] = this.uprofile.FullName;
    this.LoadData['Bio'] = this.uprofile.Bio;
    if (profile.photo) { this.photo = this.uprofile.photo; }
  }

  updateProfile(updatedata) {

    this.butnclick = false;
    //checking for photo 
    if (this.isphotoClicked ) {

      this.pic = isNullOrUndefined(this.userForm);
      console.log(this.pic);
      if (this.pic == false) {
        updatedata.photo = this.userForm;
        console.log('updatepic', updatedata.photo)
      }
    }
    
    if (this.pic == true) updatedata.photo = this.userprofiledata.photo._id;
    console.log("updatedata", updatedata.photo,this.userprofiledata._id);
    this.isShown2 = true;
    this.isShown1 = false;
    // updatedata.value.photo = this.userForm;
    this.userService.update('userprofiles/updateprofile/' + this.userprofiledata._id, updatedata).subscribe(data => {
     
      if (data) {
        this.updateUser(this.uprofile._id, updatedata.value);
        this.userService.openSnackBar("Profile Updated Successfully", "X");
        this.LoadUserProfile();
        // this.router.navigate(['Uprofile'])
      }
    });
    this.butnclick = false;
  }
  updateUser(id, info) {
    this.userService.update('users/updateprofile/' + id, info).subscribe(data => {
      console.log('updateuser data', data)
    });
  }

  sidenav() {
    this.router.navigate(['/navbar/sidenav'])
    this.dashboardactive = false;
    this.groupactive = false;
    this.notificationactive = false;
    this.chatactive = false;
    this.contactactive = true;
  }

  dashboard() {
    this.router.navigate(['/navbar/dashboard'])
    this.dashboardactive = true;
    this.groupactive = false;
    this.notificationactive = false;
    this.chatactive = false;
    this.contactactive = false;
  }

  // contactspage slider
  opencontact() {
    this.contactpage = this.contactpage === 'out' ? 'in' : 'out';
    this.isShown = !this.isShown;
    this.zindex = true;
    this.dashboardactive = false;
    this.groupactive = false;
    this.notificationactive = false;
    this.chatactive = false;
    this.contactactive = true;
  }

  closecontact() {
    this.contactpage = this.contactpage === 'out' ? 'in' : 'out';
    this.isShown = !this.isShown;
    this.contactactive=false;
  }
  // To close the sidenav
  closemodalbox() {
    this.menuState = 'out';
    this.contactpage = 'out';
    this.notificationState = 'out';
    this.isShown = false;
    this.notificationactive = false;
    this.contactactive=false;
    this.butnclick = false;
    this.isShown2 = true;
  }
  ////////////////////////////////////////////////////////////////////Contacts code/////////////////////////////////////////////////////////////////////////////////
  id;
userdetails(user) {
  this.contactpage = this.contactpage === 'out' ? 'in' : 'out';
  this.contactactive=false;
  this.isShown=false;
  console.log("user", user);
  this.selectedUser = user;
  localStorage.setItem('chatuser', JSON.stringify( this.selectedUser));
  this.userService.userName(user)
  this.userService.sendData(this.selectedUser)
  user.count = 0

  if (this._id == user.receiverid._id) {
    console.log("senderid", user.senderId._id)
    this.userService.getuserdata(user.senderId._id).subscribe(data => {
      console.log("responsedata", data);
   
      this.router.navigate(['/navbar/main'], { queryParams: { id: this.selectedUser._id,userid:user.senderId._id, value:false } });

    });
  }
  else if(this._id == user.senderId._id) {
    console.log("receiverid", user.receiverid)
    this.userService.getuserdata(user.receiverid._id).subscribe(data => {

    this.router.navigate(['/navbar/main'], { queryParams: { id: this.selectedUser._id,userid:user.receiverid._id, value:false} });

  

    });
  }


}

SearchMail21(e) {
  if ((e.which === 32 || e.which === 9 || e.which === 8 || e.which === 46) && e.target.value.trim() === "") {
    console.log('!!!!!!!!!!!!!!')
    return this.searchenable=false;
   
  }
  else { this.searchenable = true }
}

email
SearchMail(email) {
this.email=email
  if (this.email != undefined && this.email != '') {
    console.log(this.email);

    this.userService.getsearchedemail(this.email).subscribe((res) => {
      if (res !== null || res !== undefined) {
        console.log(res);
        this.response = res;
      }
    });
  }

}

status: boolean = false
InviteFriend(user) {
  console.log("user", user);
  user = {
    senderId: this.loginuserdata.id,
    receiverid: user._id,
    senderEmailId: this.loginuserdata.EmailId,
    receiverEmailId: user.EmailId,
    status: this.status,
  }
  console.log(user)
  this.userService.InvitedUser(user).subscribe(res => {
    console.log('res', res);
    this.invitefriendres = res;
    if (this.invitefriendres == 'You already sent a request or Already Your Friend') {
      this.snackbar.open(this.invitefriendres, "X", {
        duration: 5000,
        panelClass: ['bar-color'],
        horizontalPosition: 'right',
        verticalPosition: 'top'
      });
    }
    else {
      this.snackbar.open("Invitation sent", "X", {
        duration: 1000,
        panelClass: ['bar-color'],
        horizontalPosition: 'right',
        verticalPosition: 'top'
      });
    }
  })
  user.reset()
}

onInvite = function (data) {
  console.log(data.value)
  if (data.valid) {
    console.log("123456789");
    
    this.recevData = data.value
    console.log("1111111111111111",this.recevData);
    
    this.recmail = this.recevData.EmailId;
    console.log(this.recmail);
    this.error = true;

    if ( this.recmail == undefined) {
      this.nodata = true;
    }

    else {
      data.value.slug = this.loginuserdata.slug;
      data.value.urllink = this.urllink;
      data.value.senderId = this.loginuserdata.id;
      data.value.senderEmailId = this.loginuserdata.EmailId;
      data.value.senderName = this.loginuserdata.Name;
      if (this.response) {
        data.value.receiverid = this.response._id;
        data.value.Name = this.response.Name
      }

      this.userService.sendInviteMail(data.value).subscribe(invitationack => {
        console.log("invack", invitationack);
        this.error = false;
        this.sendMailres = invitationack;

        if (this.sendMailres.result == "error") {
          this.userService.openSnackBar("NOO!! Something went wrong", "X");
        }
        else if (this.sendMailres == "Invitation Sent") {
              
    // to display success message
  this.invitationview=true;

          console.log(this.sendMailres);
          this.userService.openSnackBar(this.sendMailres, "X");
        }
        // you already sent the invitation
        else if (this.sendMailres == "you already sent the invitation") {
          this.userService.openSnackBar(this.sendMailres, "X");
        }
        console.log(this.recevData);
      });
      // document.getElementById("closeModal").click()
    }
  }

  data.reset()
}

createSlug = function (profile) {
  this.urllink = this.weburl + '/?slug=' + profile.slug;
}


checkInvitationMail(email) {
  console.log(email);
  var regexp = new RegExp('([A-Za-z]|[0-9])[A-Za-z0-9.]+[A-Za-z0-9]@((?:[-a-z0-9]+\.)+[a-z]{2,})');
  if (regexp.test(email)) {
    console.log(email);
    this.emailcheck = true
    this.userService.getuseremail(email).subscribe((res) => {
      if (res !== null || res !== undefined) {
        console.log(res);
        this.regresponse = res;

      }
     
    });

  }
}


showgmail(){
  this.viewcontact=true;
}

// to close the modal
closeModal(){

  document.getElementById("closeModal").click()
  
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


// ////////////////////////image upload////////////////////////////////////////

onFileSelected(fileInput:any, title:any) {

  this.imagedata;
  const file = fileInput.target.files[0];
  const reader = new FileReader();
  if(!title) 
    reader.onload = () =>{
      this.imagePreview = reader.result;
    };
    reader.readAsDataURL(file);
    this.filesToUpload = <Array<File>>fileInput.target.files;
    const formData: any = new FormData(); // for image
    const files: Array<File> = this.filesToUpload;
    
    formData.append("uploads[]", files[0], files[0]['name']);    
    this.userService.saveFiles(formData).subscribe(data => {
     this.imagedata = data;
      console.log("imagedata",this.imagedata);
      
      if(title) {
        title.doc = this.imagedata[0]._id;
        title.pic = this.imagedata[0].originalFilename;
      }
      else if (!title){ this.userForm = this.imagedata[0]._id; this.isphotoClicked=true; console.log(this.userForm);}
      else {
        this.isphotoClicked=false;
      }
      
    });

}


createProfile(userprofile)
{

  console.log(userprofile);
  console.log('userform', this.userForm);
  if(userprofile)
  {
    console.log(userprofile)
    const userprofiledata = userprofile
    userprofiledata.photo = this.userForm;
    console.log(userprofiledata)
    this.userService.add('userprofiles/saveuser', userprofiledata).subscribe(data => {
      console.log('addsaveuser', data);
      this.profileresponse=data
      console.log( "***********************",this.profileresponse);
         if (data) {
        this.updateUser(this.uprofile._id, userprofiledata);
      }
    });
    this.snackbar.open('Profile updated','x',{
          duration:1000,
          verticalPosition:'top',
          horizontalPosition:'center'
        })
  }
  else{
    this.snackbar.open('enter data into fields','x',
    {
      duration:1000,
      verticalPosition:'top',
      horizontalPosition:'center'
    })
  }
  this.isShown2 = true;
  this.isShown1 = false;
  this.butnclick = false;

}
ngOnDestroy(){
  this.autoRefreshFriendsUn.unsubscribe();
  this.autoRefreshGroupsUn.unsubscribe();
  this.autoRefreshNotificatioUn.unsubscribe();
}

}