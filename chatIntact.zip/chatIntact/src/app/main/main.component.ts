import { Component, OnInit, Input, ViewChild, ElementRef, ChangeDetectorRef, NgZone, TemplateRef, ɵConsole, } from '@angular/core'
import { MessageService } from 'src/app/services/message.service';
import { UserService } from 'src/app/services/user.service';
import { MatSnackBar, MatDialog } from '@angular/material';
import { FrontEndConfig } from 'src/app/frontendconfig';
import { Subscription } from 'rxjs';
import { NgxSpinnerService } from 'ngx-spinner';
import { NgxFileDropEntry, FileSystemFileEntry, FileSystemDirectoryEntry } from 'ngx-file-drop';
import { ImageCompressService, ResizeOptions, ImageUtilityService, IImage, SourceImage } from 'ng2-image-compress';
import { GroupsService } from 'src/app/services/groups.service';
import { LoginComponent } from '../login/login.component';
import { DomSanitizer } from '@angular/platform-browser';
import { ActivatedRoute, Router } from '@angular/router';
import { MapviewComponent } from '../mapview/mapview.component';
import { config } from '../configFile';
import { EmojiComponent } from '../emoji/emoji.component'

@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.css']
})
export class MainComponent implements OnInit {
  msg: any;
  subscription: Subscription
  userMessage: any=[]
  user;
  list;
  loginuserdata;
  id;
  emailSentMsg;
  incognitoRes;
  incognitoo: boolean = false;
  incognitores;
  Staredmessage: any;  // this is for star messages
  searchTerm: any;
  forwardlistusers;
  forwardmsgdata;         // this is for forward message 
  listofusersfrwdmsgEmails = []; // this is for listusers emails data for sending forward msg
  listofusersfrwdmsgId = []; // this is for listusers id's data for sending forward msg
  frwdmsglistusers = []; // This is for forward message search listusers data 
  x;  // This is for forward message search listusers data 
  currentuser
  listusers
  data;
  sendMess: String
  receviedMess;
  listuser;
  hideEmail; // this is for hide user 
  replying; // this is for replying to exact message
  incognitoBlockState;
  _id;
  name;
  test;
  showModal;
  display
  imgmimetype = ["image/apng", "image/bmp", "image/gif", "image/jpeg", "image/png", "image/tiff", "image/webp"];
  audiomimetype = ["audio/mpeg", "audio/ogg", "audio/wav", "audio/mp3"];
  videomimetype = ["video/mp4", "video/ogg", "video/webm"];
  docmimetype = ["application/msword", "text/csv", "application/vnd.openxmlformats-officedocument.wordprocessingml.document", "text/plain", "application/pdf", "application/vnd.ms-powerpoint", "application/vnd.openxmlformats-officedocument.presentationml.presentation", "application/vnd.ms-excel", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"];
  blockdfltdata
  isMedia: boolean = false;
  starmsg1: boolean = false;
  message: String
  searchValue: string = '';
  counter = 0;
  uploadedFilePath: string = null;
  userForm = [];
  serverurl; // form image path url
  BlockedByReceiver: Boolean = false
  BlockedBySender: Boolean = false;
  flag: boolean = false

  // @Output() sentMessage = new EventEmitter();
  // @ViewChild('scroll', { static: false }) scroll: ElementRef //Scroll down messages
  // To open the fwdmsg dialog box
  @ViewChild('fwdMsgModal', { static: false }) fwdMsgModal: TemplateRef<any>;
  // Groupsmodal
  @ViewChild('groupsModal', { static: false }) groupsModal: TemplateRef<any>;
  @ViewChild('imgRenderer', { static: false }) imgRenderer: ElementRef;
  deletingMessage;
  chatuserdata: any;
  chatuserid: any;
  // order:any
  staredMessage: any;
  userdata: any;
  unstaredMessage: any;
  selectphoto: any;
  blockResponse: any;
  blockinguser;
  msgindex;
  // scroll: ScrolldownDirective;

  isRecording = false; // is audio recording boolean
  recordedTime; // time of recording
  blobUrl; // url of the audio
  blobdata; // user audio data
  audiodata;
  audiotitle;
  location = null;
  locationlink
  locationurl = null;
  blockdata: any;
  blockingRes;
  urls = [];
  dragFiles = [];
  snackcounter = 0;
  files: NgxFileDropEntry[] = [];
  scrolltop: any
  showIput;
  Userdetails;
  Userselected;
  priorityResponse
  selectedUser: any;
  chatuser;

  Userlastmessage;
  searchenable: boolean = false;
  response: any;
  EmailId;
  invitefriendres: any;
  emailcheck: Boolean = false;
  regresponse: any;
  alreadyreg: Boolean;
  activehideuserslist: any;
  change: any;
  Groups: any = [];
  selectedGroup: any;
  deletecontact;
  divheight: number;
  weburl: any;
  viewcontact: boolean;
  message2: any;
  gotlocation: any;
  firstGroup: any;
  groupMembersCount: any;
  groupMembersInfo: any;
  groupMessages: any;
  firstGroupId: any;
  publicgroup: boolean = true;


  selectedEmoji: any;
  gInformation: any;
  showemoji: boolean;
  invitationview;
  personadd;
  index;
  slidedata1;
  imagePreview;
  nogdata;
  GroupName;
  info;
  Emailid;
  nodata;
  searchterm:any;
  filesToUpload: Array<File> = [];
  group;
  length: any;
  cursorPos:number=0;
  groupcreated: boolean;
  mediatype;
  // for unsubscribing observable
  autoRefreshFriends; 
  autoRefreshMessage :Subscription;
  autoRefreshRemoveMessage;
  autorefreshgroupmessages;
  autoRefreshRenameGroup: Subscription;
  autoRefreshLeaveGroup: Subscription;
  AutoRefreshMemberStatus: Subscription;
  AutoRefreshGroups: Subscription;
  IcognitoShowRes: Subscription;
  IcognitoDelRes: Subscription;
  IcognitoReject: Subscription;
  IcognitoChatAccept: Subscription;
  IcognitoChat: Subscription;
  getFriends: Subscription;
  autoRefreshPriorityRes: Subscription;
  autoRefreshDelAllMsg: Subscription;
  autoRefreshBlockdata: Subscription;
  autoMessageReceipt: Subscription;
  autoRefreshUndoMessage: Subscription;
  incognitopopupshow: boolean = false;
  // mediatype;
  chtheight: number;
  userid
  loginUser: any;
  emojiobservable: Subscription;
  editUserdata: any;
  newEditUserdata: Object;

  selectedmessage : any
  autoRefreshGroupEditMessage: Subscription;
  autoRefrshEditedMessage: Subscription;

  constructor(private imgCompressService: ImageCompressService, private groupService: GroupsService,
    private dialogbox: MatDialog,
    private frontendconfig: FrontEndConfig,
    private zone: NgZone,
    private cdref: ChangeDetectorRef,
    private userService: UserService,
    private messageService: MessageService,
    private snackbar: MatSnackBar,
    private spinner: NgxSpinnerService,
    private sanitizer: DomSanitizer,
    private router: ActivatedRoute,
    private route: Router,
    private configs: config,

    public dialog: MatDialog) {
    this.weburl = this.configs.getWeburl();

    this.autoRefreshFriends = this.messageService.autorefreshFriends().subscribe(data => {
      console.log("autofriends list", data);
      if (data.senderId._id == this.id || data.receiverid._id == this.id) {
        this.listusers.push(data);
        console.log("updated list", this.listusers);
      }
    });

   this.autoRefreshMessage = this.messageService.autoRefresMessage().subscribe(data => {
   console.log("autoRefresMessage", data)
    if ((data.receiverId == this.chatuser._id && data.senderId == this.id) || (data.receiverId == this.id && data.senderId == this.chatuser._id)) {
         this.getMessage();
        var test = document.getElementById("test");
        // this.scrolltop = test.scrollHeight;
      }


      if (data.receiverId == this.loginuserdata.id && this.chatuser._id != data.senderId) {

        for (var i = 0; i < this.listusers.length; i++) {
          if (this.listusers[i].senderId._id == data.senderId) {
            let x = this.listusers.splice(i, 1)
            this.listusers.unshift(x[0])
             this.userMessage.push(data)

          }
          if (this.listusers[i].receiverid._id == data.senderId) {
            let x = this.listusers.splice(i, 1);
            this.listusers.unshift(x[0])
             this.userMessage.push(data)
          }
        }
        var index = this.listusers.findIndex(x => (x.senderId._id == data.senderId) || (x.receiverid._id == data.senderId))
        this.listusers[index].count = this.listusers[index].count + 1;
      }

      // This is for msg read reciepts
      if (data.receiverId == this.loginuserdata.id && (this.chatuser._id == data.senderId || this.chatuser._id == data.senderId)){
        this.messageService.msgSeen(data).subscribe(data1 => {
          console.log(data1)
        })
      }
      this.mediatype = data
      console.log(this.mediatype);
      //  var index = this.userMessage.findIndex(x=>x._id == data.parentId)
      //  {
      //   console.log("123",index);
      //   if (index) this.userMessage[index] = data.message
      //   console.log("123456789", this.userMessage[index-1]);

      //  }

    });

    this.subscription = this.userService.sendObs().subscribe(msg => {
      this.msg = msg
      // this.chatuser=msg.chat;

      if (this.msg.receiverid._id == this.id && this.msg.BlockedByReceiver) this.msg.block = true;
      else if (this.msg.senderId._id == this.id && this.msg.BlockedBySender) this.msg.block = true;
      else this.msg.block = false;
    });
    this.serverurl = this.frontendconfig.getserverurl(); // for image url
    this.display = 'none'

    this.loginuserdata = JSON.parse(localStorage.getItem('currentUser'));
    this.id = this.loginuserdata.id;
    this.EmailId = this.loginuserdata.EmailId
    this.createSlug(this.loginuserdata)

    this.autoRefreshRemoveMessage = this.messageService.autoRefreshRemoveMessage().subscribe(data => {
      console.log(data);
      if (this.userMessage) {
        var index = this.userMessage.findIndex(x => x._id == data._id)
        if (index) this.userMessage[index] = data
      }

      if (this.Staredmessage) {
        var index = this.Staredmessage.findIndex(x => x._id == data._id)
        if (index) this.Staredmessage[index] = data
      }
    })

    this.autoRefreshUndoMessage = this.messageService.autoRefreshundoMessage().subscribe(data => {
      if (this.userMessage) {
        var index = this.userMessage.findIndex(x => x._id == data._id)
        if (index) this.userMessage[index] = data
      }

      if (this.Staredmessage) {
        var index = this.Staredmessage.findIndex(x => x._id == data._id)
        if (index) this.Staredmessage[index] = data
      }
    })

   // This is for message remove faviourite 
   this.messageService.messageRemoveFavouite().subscribe(data =>{
   console.log(data)
   this.Staredmessage = data
  })
    this.messageService.recordingFailed().subscribe(() => {
      this.isRecording = false;
    });

    this.messageService.getRecordedTime().subscribe((time) => {
      this.recordedTime = time;
    });


    // This is for msg read reciepts status by emit function
    this.autoMessageReceipt = this.messageService.autoMsgReadReciept().subscribe(data => {
      this.userMessage = data;
    })

    this.messageService.getRecordedBlob().subscribe((data) => {
      this.audiotitle = data.title;
      this.blobdata = data.blob;

      this.blobUrl = this.sanitizer.bypassSecurityTrustUrl(URL.createObjectURL(this.blobdata));
      let file = new File([this.blobdata], this.audiotitle, {
        type: "audio/wav"
      });
      const formData: any = new FormData();
      formData.append("uploads[]", file, file['name']);

      this.messageService.saveFiles(formData).subscribe(data => {
        this.audiodata = data;
        this.audiodata = this.audiodata[0]._id;
      });
    });

    this.autoRefreshBlockdata = this.messageService.autoRefreshBlockdata().subscribe(data => {
      this.blockdata = data
    });

    this.autoRefreshDelAllMsg = this.messageService.autoRefreshDeletingAllMessages().subscribe(data => {
      console.log("clearchat", data)
      this.userMessage = data
    })

    this.autoRefreshPriorityRes = this.messageService.autoRefreshPriorityResponse().subscribe(data => {
      if ((this.id == data.receiverid._id) || (this.id == data.senderId._id)) {
        this.priorityResponse = data;
        this.userService.getFriends(this.id).subscribe(users => {
          this.listusers = users;
          console.log("friendsssssssss", this.list)
        });
      }
    });


   this.getFriends =  this.userService.getFriends(this.id).subscribe(users => {
      this.listusers = users;    
  })

 // This is for incognito chat socket emit function
   this.IcognitoChat = this.messageService.incognitochat().subscribe(data =>{
        let Data = data;
        if(Data.loginuser == this.loginuserdata.id){
          this.incognitores = data;
          // if(Data.chatuser == this.chatuser._id){ 
            this.incognitoo = true;
            document.getElementById("incognito").click()
          // }
        }
      // }
    })

 // This is for incognitoaccept chat socket emit function
  this.IcognitoChatAccept =  this.messageService.INCOGNITOCHATACCEPT6().subscribe(data=>{
     this.incognitoRes = data
  
     if(this.incognitoRes.chatuser == this.loginuserdata.id){
      this.snackbar.open("user was accepted your request Let's start incognito chat", "x", {
        duration: 4000,
        verticalPosition: 'top',
        horizontalPosition: 'center'
      });
     }  
   })

   // This is for incognitoreject chat socket emit function
  this.IcognitoReject = this.messageService.incognitoRejectemit().subscribe(data=>{
    // this.incognitoRes = data;
    let Data = data
    console.log(Data)
    if(Data){
      if(Data.chatuser == this.loginuserdata.id){
        this.snackbar.open("user was rejected your request","x",{
          duration: 4000,
          verticalPosition: 'top',
          horizontalPosition: 'center'
        });
       }
    } 
   });

   // This is for incognito delete response socket emit function
  this.IcognitoDelRes =  this.messageService.incognitoDeleteResponse().subscribe(data=>{
     for(var i=0;i<this.userMessage.length;i++){
       if(this.userMessage[i].create_At == data.create_At){
        this.userMessage.splice(i,1,data)
       }
     }
   })

   //This is for incognito showresponse null
  this.IcognitoShowRes = this.messageService.incognitoshowres().subscribe(data=>{ 

     let Data = data
     if(Data){
     if(this.incognitoRes.chatuser == this.loginuserdata.id || this.incognitoRes.loginuser == this.loginuserdata.id){
      if(Data == "incognitoResnull"){
        this.incognitoRes = null
        this.snackbar.open("user was left from incognito chat","x",{
          duration: 3000,
          verticalPosition: 'top',
          horizontalPosition: 'center'
        });
       }
     }
    }   
   })


   // for automatically refresh groups this service
    this.AutoRefreshGroups = this.messageService.autoRefreshGroups().subscribe(data=>{
      console.log("groupdata", data);
      this.getGroups()
    });

    // user accepts group request this socket will emit and shows group in 
    this.AutoRefreshMemberStatus = this.messageService.autoRefreshMemberStatus().subscribe(data => {
      console.log(data);
      this.firstGroupId = data.GroupId._id;
    });

    // Auto Refresh group messages
    this.autorefreshgroupmessages = this.messageService.autoRefreshGroupMessage().subscribe(messages => {
      console.log("groupmessage emit", messages);
      this.groupMessages.push(messages);
      console.log('groupmessages updated', this.groupMessages)
      this.gettingBadgeCount();
    });
    // Auto refresh group edit messages
    this.autoRefreshGroupEditMessage=this.messageService. autoRefreshGroupEditMessage().subscribe(editMessage=>{
      for(let message of this.groupMessages){
        if(message._id == editMessage._id){
          message.message = editMessage.message;
          message.photo = editMessage.photo;
        }
      }
      
    });
    // Auto refresh One-One edit message
    this.autoRefrshEditedMessage = this.messageService.autoRefreshEditedMessage().subscribe(editedMessage=>{
      console.log(editedMessage);
      for(let message of this.userMessage){
        if(message._id == editedMessage._id){
          message.message = editedMessage.message;
          message.photo = editedMessage.photo;
        }
      }
      
    })
    // Auto Refresh Leave the group
    this.autoRefreshLeaveGroup = this.messageService.autoRefreshLeaveGroup().subscribe(leave => {
      this.userService.getGroupss(this.id).subscribe(groups => {
        console.log(groups);
        this.Groups = groups;
      });
    });
    // Auto refresh rename the group
    this.autoRefreshRenameGroup = this.messageService.autoRefreshRenameGroup().subscribe(rename => {
      console.log(rename);
      if (this.firstGroupId == rename._id)
        this.firstGroup = rename.GroupName
      this.userService.getGroupss(this.id).subscribe((groups: any) => {
        this.Groups = groups;
      });
    });

  }
  ngOnInit() {
    this.divheight = window.innerHeight - 200;
    this.chtheight = window.innerHeight - 200;
    console.log(this.divheight)
    this.router.queryParams.subscribe(params => {
      console.log("11111", params);
      // Don't remove this params value == true we 'll get cast error
      if (params.value == 'true') {
        this.userForm = [];
        this.urls = [];
        this.dragFiles = [];
        this.blobUrl = null
        this.blobdata = null
        this.audiodata = null
        this.locationurl = null;
        this.message2 = null
        this.files = [];
        this.change = params.value;
        this.firstGroupId = params.gid;
        this.firstGroup = params.gname;
        if (!this.selectedGroup) { this.getGroups() }
        else { this.getGroupMessages(); this.gettingMembersCount() }
      }
      this.Userdetails = params.id;
      this.userid = params.userid;
      this.change = params.value;
      this.firstGroupId = params.gid;
      this.firstGroup = params.gname;
      // this.useremail=params.useremail
      if (this.userid) {
        this.userService.getuserdata(this.userid).subscribe(data => {
          console.log(data);
          this.chatuser = data;
          this.searchValue = null;
          this.searchTerm = [];
          this.message2 = null
          this.locationurl = null;
          this.urls = [];
          this.userForm = [];
          this.blobUrl = null;
          this.blobdata = null;
          this.audiodata = null;
          this.getMessage()
        })
      }
    });
    this.ActiveHideUsers(this.loginuserdata.EmailId)

  }

getMessage()
{

  this.messageService.getMessages(this.Userdetails).subscribe(data => {
    console.log(data);
    this.userMessage = data
 
    setTimeout(() => {
      var test = document.getElementById("test");
      if (test && test.scrollHeight) this.scrolltop = test.scrollHeight;
    }, 100);

    // This is for getting user default response for show the block or unblock state
    let obj = {
      from: this.loginuserdata.EmailId,
      to: this.chatuser.EmailId
    }
    console.log("ngoninit+++", obj)
    this.messageService.blockingdata(obj).subscribe(data => {
      this.blockdfltdata = data
      console.log("blockdfltdata", this.blockdfltdata)
    });

    // This is for user login status  by emit function 
    this.messageService.autoUserStatus().subscribe(data => {
    this.chatuser.loginStatus = data.loginStatus
    this.getFriends =  this.userService.getFriends(this.id).subscribe(users => {
    this.listusers = users;    
    })
    });
  })
}
  select($event)
  {
    console.log($event);
    this.selectedEmoji = $event.emoji;
  }

  // Getting groups

// unhide users butto hidders

// Getting groups
  getGroups() {
    this.userService.getGroupss(this.id).subscribe((groups: any) => {
      this.Groups = groups;
      console.log(this.Groups);

      if (this.Groups != '') {
        if (this.firstGroupId) {
          this.groupService.gInfor(this.firstGroupId, this.id).subscribe((res:any) => {
            console.log(res);
            if(res.length>0){
              this.gInformation = res[0]
            this.route.navigate(['/navbar/main'], { queryParams: { gid: this.gInformation.GroupId._id, gname: this.gInformation.GroupId.GroupName, value: true } });
            }
            else{
              if(this.Groups){
                this.route.navigate(['/navbar/main'], {queryParams: {value:true}});
              }
              else{
              this.route.navigate(['/navbar/main'], { queryParams: { gid:this.Groups[0].GroupId._id, gname: this.Groups[0].GroupId.GroupName, value:true } }); 
              } 
            }
          })
          this.gettingMembersCount();
          this.getGroupMessages();
          this.gettingBadgeCount();

        }
        else {
          this.groupService.gInfor(this.Groups[0].GroupId._id, this.id).subscribe(res => {
            console.log(res);
            this.gInformation = res[0]
            this.route.navigate(['/navbar/main'], { queryParams: { gid: this.gInformation.GroupId._id, gname: this.gInformation.GroupId.GroupName, value: true } })
          })
        }
      }
    })
  }
  // Getting Badge count
  gropuids = [];
  gettingBadgeCount() {
    this.Groups.forEach(element => {
      this.gropuids.push(element.GroupId._id);
    });
    let obj = {
      gids: this.gropuids,
      id: this.loginuserdata.id
    }
    this.groupService.getBadgeCount(obj).subscribe(response => {
      console.log(response);
      this.Groups = response
    })

  }
  // Getting meembers count
  gettingMembersCount() {
    this.groupService.gettingMembersCount(this.firstGroupId).subscribe((count: any) => {
      this.groupMembersInfo = count
      this.groupMembersCount = count.length
    })
  }
  // Getting group messages
  getGroupMessages() {
    this.groupService.getGroupMessages(this.firstGroupId).subscribe((res: any) => {
      console.log(res);
      this.groupMessages = res

    })
  }

  // leave the group
  leaveGroup(group) {
    console.log(group);

    const logindialogRef = this.dialog.open(LoginComponent, {
      width: 'auto',
      data: {
        type: 'leave',
        Groupinfo: group
      }
    })
    logindialogRef.afterClosed().subscribe(result => {
      console.log(result)
    });
  }
  // View members
  gView(group) {
    const logindialogRef = this.dialog.open(LoginComponent, {
      // disableClose: true,
      width: '800px',
      data: {
        type: 'view',
        Groupinfo: group
      }

    });
    logindialogRef.afterClosed().subscribe(result => {
      console.log(result)
    });
  }
  myGroup(group) {
    console.log("Test", group)
    const logindialogRef = this.dialog.open(LoginComponent, {
      // disableClose: true,
      width: '800px',
      data: {
        type: 'group',
        Groupinfo: group

      }

    });
    logindialogRef.afterClosed().subscribe(result => {
      console.log(result)
    });
  }

  myGroup2() {
    console.log("myGroup2")
    const logindialogRef = this.dialog.open(LoginComponent, {
      // disableClose: true,
      width: '600px',
      data: {
        type: 'group2',
        source: "AddMember"
      }

    });
    logindialogRef.afterClosed().subscribe(result => {
      console.log(result)

    });
  }

  // onGroupCreate = function (data) {
  //   console.log(data.valid);
  //   console.log(data.value);
  //   // test code
  //   if (data.valid) {
  //     this.error = true;

  //     if (data.value.GroupName == undefined) {
  //       this.nodata = true;
  //     }
  //     else {
  //       // To display success msg after creating group
  //       this.groupcreated=true;
  //       var groupdata = {
  //         creatorId: this.loginuserdata.id,
  //         creatorEmailId: this.loginuserdata.EmailId,
  //         creatorName: this.loginuserdata.Name,
  //         GroupName: data.value.GroupName,
  //         info: data.value.info,
  //         Type: 'public',
  //         GroupIcon: this.userForm,
  //         Role: 'Admin',
  //       }
  //       console.log(this.userForm);
  //       this.userService.createGroup(groupdata).subscribe(groupack => {
  //         this.route.navigate(['/navbar/main'], { queryParams: { gid: groupack.group._id, gname: groupack.group.GroupName, value: true } });
  //         this.error = false;
  //         this.sendgroupres = groupack;
  //         if (this.sendgroupres) {
  //           console.log(this.sendgroupres);
  //           this.userService.openSnackBar(this.sendgroupres.response, "X");
  //         }
  //         // you already sent the invitation
  //         else if (this.sendgroupres == "you already created this Group") {
  //           this.userService.openSnackBar(this.sendgroupres, "X");
  //         }
  //       });
  //       document.getElementById("closeModal").click()
  //     }
  //   }
  //   // test code end     
  //   this.imagePreview = null;
  //   data.reset()
  // }

  groupdetails(group) {
    // this.getGroups()
    this.selectedGroup = group;
    this.gInformation = this.selectedGroup
    console.log("selected Group", this.selectedGroup);
    this.route.navigate(['/navbar/main'], { queryParams: { gid: this.selectedGroup.GroupId._id, gname: this.selectedGroup.GroupId.GroupName, value: true } });
  }
  //Remove badge count
  removeBadgeCount(group) {
    let info = {
      gid: group.GroupId._id,
      id: this.id
    }
    this.groupService.removeBadgeCount(info).subscribe(result => {
      console.log(result);
      this.gettingBadgeCount();
    })
  }
  // Renaming the group
  gRename(info) {
    console.log(info);
    const logindialogRef = this.dialog.open(LoginComponent, {
      // disableClose: true,
      width: '800px',
      data: {
        type: 'rename',
        Groupinfo: info
      }

    });
    logindialogRef.afterClosed().subscribe(result => {
      console.log(result)
    });

  }

  /* 
    FunctionName : getFrienddata
    
    Input: Friendlist id
    Output: JSON
    Desc: Getting Particular friendlist data when user clicks on friend
   
    getFrienddata = function (id) {
      console.log(id);
      this.userService.get('friendslists/' + id).subscribe(data => {
        this.order = data;
        console.log(this.order);
        localStorage.setItem('chatuser', JSON.stringify(this.order));
      })
    }
   */

  closeModal() {
    this.display = 'none';
  }
  // Reset the data for media
  reset(index) {
    console.log(index);
    
    this.userForm.splice(index, 1);
    this.urls.splice(index, 1);
    this.newEditData= this.urls
    console.log("URLs: ", this.urls);
    console.log("UserForm: ", this.userForm);
  }
  // Editing for 1-1 chat
  editingData(data, id, user) {
    let editData = {
      message: data,
      id: id,
      photo: this.newEditData
    }
    console.log(editData);

    if (user.edit3 == true) {
      user.edit = false;
      user.edit2 = false;

    }
    if (this.message1 !== data.toString().trim()) {
      if (data == '') {
      }
      else {
        this.messageService.sendEditMessage(editData).subscribe(res => {
        });

      }
    }
  }
  // Editing for Group chat
  editingData2(data, id, groupmessage){
    let editData = {
      message:data,
      id:id,
      photo: this.newEditData
    }
    console.log(editData);
    if (this.message1 !== data.toString().trim()) {
      if (data == '') {
      }
      else {
        this.messageService.sendEditGroupMessage(editData).subscribe(res => {
        });

      }
    }

    
  }


  message1;
  newEditData =[];
// Edit messages for 1-1 chat
  edit1(user) {
    this.searchValue =user.message
    this.editUserdata = user
    this.editUserdata.photo.forEach(photo => {
      this.urls.push(photo);
      this.newEditData.push(photo)
    });
    console.log(this.urls);
    this.newEditUserdata;
  }
  // Edit messages for Group chat
  edit2(groupmessage){
    this.searchValue = groupmessage.message
    this.editUserdata = groupmessage
    this.editUserdata.photo.forEach(photo => {
      this.urls.push(photo);
      this.newEditData.push(photo)
    });
    console.log(this.urls);
    this.newEditUserdata;
  }
  keyDownFunction(event, data, id, user) {
    if (event.keyCode === 13) {
      if (this.message1 !== data.toString().trim()) {
        if (data == '') {
        }
        else {
          this.editingData(data, id, user)
        }
      }
    }
  }


  openModal(user) {
    this.selectphoto = user;
    this.display = 'block';
  }
  // Group chat box
  listArr = [];
  groupBadgeIds = [];
  groupbox(message) {
    if(this.editUserdata){
      this.counter = 1;
      this.searchValue = null;
      this.message2 = null;
      this.userForm = [];
      this.urls = [];
      this.dragFiles = [];
      this.blobUrl = null
      this.blobdata = null
      this.audiodata = null
      this.locationurl = null; 
      this.files = [];
      this.editingData2(message.message, this.editUserdata._id, this.editUserdata)
      
    }
    if(!this.editUserdata){
    console.log(message)
    this.counter = 1;
    this.searchValue = null;
    this.message2 = null;
    this.groupMembersInfo.forEach(element => {
      this.listArr.push(element.memberId);
    });
    this.listArr.forEach(mid => {
      if (this.id == mid) {
        console.log('Nothing is pushed');
      }
      else {
        this.groupBadgeIds.push(mid);
      }
    })
    if (message.message != null && message.message.trim() == '') {
      return false
    }
    else {
      var messageData = {
        message: message.message,
        groupSenderId: this.loginuserdata.id,
        groupReceiverId: this.listArr,
        groupId: this.groupMembersInfo[0].GroupId,
        unReadMessages: this.groupBadgeIds,
        photo: this.userForm,
        media: this.audiodata,
        isMedia: false,
        blobdata: this.blobdata,
        Gps: this.gotlocation,
        locationurl: this.locationurl,
      }
      if ((messageData.photo.length == 0) && (messageData.media == null || !messageData.blobdata == null)
        && (!messageData.Gps && !messageData.locationurl)) { messageData.isMedia = false }
      else {
        messageData.isMedia = true;
      }
    }

    if ((messageData.message == null || messageData.message == undefined) && (messageData.isMedia == false) && (this.location == null)) {
      this.snackbar.open("No Input data", "x", {
        duration: 1000,
        verticalPosition: 'top',
        horizontalPosition: 'center'
      });
    }
    else {
      this.groupService.groupMessage(messageData).subscribe(msgRes => {
        console.log(msgRes);
        this.listArr = [];
        this.groupBadgeIds = [];
        this.userForm = [];
        this.urls = [];
        this.dragFiles = [];
        this.blobUrl = null
        this.blobdata = null
        this.audiodata = null
        this.locationurl = null;
        this.files = [];

      })
    }

  }
  }

  chatbox(message) {
    if(this.editUserdata){
      console.log(message.message);
      console.log(this.editUserdata.photo);
      console.log(this.userForm);
      this.counter = 1;
      this.searchValue = null;
      this.message2 = null;
      this.userForm = [];
      this.urls = [];
      this.dragFiles = [];
      this.blobUrl = null
      this.blobdata = null
      this.audiodata = null
      this.locationurl = null; 
      this.files = [];
      this.editingData(message.message, this.editUserdata._id, this.editUserdata)
      
    }

if(!this.editUserdata){
    if (this.incognitoRes) {
      this.counter = 1;
      this.searchValue = null;
      this.message2 = null;
      if (message.message != null && message.message.trim() == '') {
        return false
      }
      else {      
        var messageData1 = {
          message: message.message,
          senderId: this.loginuserdata.id,
          senderEmail: this.loginuserdata.EmailId,
          senderName: this.loginuserdata.Name,
          receiverId: this.chatuser._id,
          receiverEmailId: this.chatuser.EmailId,
          photo: this.userForm,
          media: this.audiodata,
          isMedia: false,
          blobdata: this.blobdata,
          Gps: this.gotlocation,
          locationurl: this.locationurl,
          incognito: "incognito chat",
          incognitoStatus: '0',
          parentId: null
        }
       
        if ((messageData1.photo.length == 0) && (messageData1.media == null || !messageData1.blobdata == null)
          && (!messageData1.Gps && !messageData1.locationurl)) { messageData1.isMedia = false }
        else {
          messageData1.isMedia = true;
        }
      }
      if ((messageData1.message == null || messageData1.message == undefined) && (messageData1.isMedia == false) && (this.location == null)) {
        this.snackbar.open("No Input data", "x", {
          duration: 1000,
          verticalPosition: 'top',
          horizontalPosition: 'center'
        });
      }
      else {
        console.log("messageData", messageData1);
        this.messageService.sendMessage(messageData1).subscribe(res => {
          console.log("Res: ", res)
          this.blockingRes = res
          if (res == "receiverblocked") {
            this.userForm = [];
            this.urls = [];
            this.blobUrl = null
            this.blobdata = null
            this.audiodata = null
            this.locationurl = null;
            this.snackbar.open("user was blocked to you ", "x", {
              duration: 2000,
              verticalPosition: 'top',
              horizontalPosition: 'center'
            });
          }else if(res == 'senderblocked'){
            this.userForm = [];
            this.urls = [];
            this.blobUrl = null
            this.blobdata = null
            this.audiodata = null
            this.locationurl = null;
            this.snackbar.open("please, Remove the user from block state", "x", {
              duration: 2000,
              verticalPosition: 'top',
              horizontalPosition: 'center'
            });
          }else {
            // this.userMessage.push(res);
            // var test = document.getElementById("test");
            // this.scrolltop = test.scrollHeight;
            this.userForm = [];
      this.urls = [];
            this.dragFiles = [];
            this.blobUrl = null
            this.blobdata = null
            this.audiodata = null
            this.locationurl = null; 
            this.files = [];
          }
        });
      };
    } else {
      this.counter = 1;
      this.searchValue = null;
      console.log(this.userForm)
      if (message.message != null && message.message.trim() == '' && this.userForm.length == 0) {
        return false
      } else {
        if (this.message2) {
          var messageData :any= {
            message: message.message,
            parentId: this.message2._id,
            senderId: this.loginuserdata.id,
            senderEmail: this.loginuserdata.EmailId,
            senderName: this.loginuserdata.Name,
            receiverId: this.chatuser._id,
            receiverEmailId: this.chatuser.EmailId,
            photo: this.userForm,
            media: this.audiodata,
            isMedia: false,
            blobdata: this.blobdata,
            Gps: this.gotlocation,
            locationurl: this.locationurl
          }
        } else {
          var messageData :any= {
            message: message.message,
            parentId: null,
            senderId: this.loginuserdata.id,
            senderEmail: this.loginuserdata.EmailId,
            senderName: this.loginuserdata.Name,
            receiverId: this.chatuser._id,
            receiverEmailId: this.chatuser.EmailId,
            photo: this.userForm,
            media: this.audiodata,
            isMedia: false,
            blobdata: this.blobdata,
            Gps: this.gotlocation,
            locationurl: this.locationurl,
          }     
        }
        //console.log("messageData: ",messageData)
        // if (!messageData.photo && !messageData.Gps && !messageData.locationurl) { messageData.isMedia = false }
        if ((messageData.photo.length == 0) && (messageData.media == null || !messageData.blobdata == null)
          && (!messageData.Gps && !messageData.locationurl)) { messageData.isMedia = false }
        else {
          messageData.isMedia = true;
        }
      }

      console.log("messageData: ", messageData)

      if ((messageData.message == null || messageData.message == undefined) && (messageData.isMedia == false) && (this.location == null)) {
        this.snackbar.open("No Input data", "x", {
          duration: 1000,
          verticalPosition: 'top',
          horizontalPosition: 'center'
        });
      }
      else {
        console.log("messageData", messageData);
        this.messageService.sendMessage(messageData).subscribe(res => {
          this.emailSentMsg = res;
          console.log("Res: ", res)
          this.blockingRes = res
          if (res == "receiverblocked") {
            this.userForm = [];
            this.urls = [];
            this.blobUrl = null
            this.blobdata = null
            this.audiodata = null
            this.locationurl = null;
            this.snackbar.open("user was blocked to you", "x", {
              duration: 2000,
              verticalPosition: 'top',
              horizontalPosition: 'center'
            });
          } else if(res == 'senderblocked'){
            this.userForm = [];
            this.urls = [];
            this.blobUrl = null
            this.blobdata = null
            this.audiodata = null
            this.locationurl = null;
            
            this.snackbar.open("please, Remove the user from block state", "x", {
              duration: 2000,
              verticalPosition: 'top',
              horizontalPosition: 'center'
            });
          }else {
            this.userForm = [];
            this.urls = [];
            this.dragFiles = [];
            this.blobUrl = null
            this.blobdata = null
            this.audiodata = null
            this.locationurl = null;
            this.message2 = null
            this.files = [];
          }
        });
      };
    }
  }
  };

  FetchExtension(file: any) {
    console.log("File Dragged: ", file);
    console.log("File name length: ", file.name.length)

    var pos = file.name.length;
    while (pos > 0) {
      if (file.name.charAt(pos - 1) == '.') {
        break;
      }
      else {
        pos--;
      }
    }
    var extension = file.name.substring(pos);
    console.log("File extension: ", extension);
    return extension;
  }

  //Create Image Blob
  CreateBlobImage(dataURI, filename) {
    var byteString = atob(dataURI.split(',')[1]);
    var mimeString = dataURI.split(',')[0].split(':')[1].split(';')[0]
    var ab = new ArrayBuffer(byteString.length);
    var ia = new Uint8Array(ab);
    for (var i = 0; i < byteString.length; i++) {
      ia[i] = byteString.charCodeAt(i);
    }
    var bb = new Blob([ab], { type: mimeString });
    const imgFile = new File([bb], filename, { type: mimeString });
    return imgFile;
  }

  fileProgress = (fileSelect: any) => {

    console.log("FileProgress event: ", fileSelect);

    this.snackcounter = 0;

    var fileInput = [];

    fileInput = Array.from(fileSelect.target.files);
    console.log("FileInput at FileProgress: ", fileInput)
    this.fileProcess(fileInput);
  }

  fileProcess = (fileInput: any) => {
    var flag = false, flag2 = false;
    var imagedata = [];
    var imagelist = [];

    if (this.userForm.length == 5) {
      this.zone.run(() => {
        this.snackbar.open("Maximum limit reached!!", "x", {
          duration: 5000,
          verticalPosition: 'top',
          horizontalPosition: 'center'
        });
      });
      return;
    }
    else if ((this.userForm.length + fileInput.length) > 5) {
      this.zone.run(() => {
        this.snackbar.open(`Maximum limit Exceeded!! Selecting first ${5 - this.userForm.length} files.`, "x", {
          duration: 5000,
          verticalPosition: 'top',
          horizontalPosition: 'center'
        });
      });
      while ((this.userForm.length + fileInput.length) > 5) {
        fileInput.splice(fileInput.length - 1, 1);
      }
    }
    var extension = "";

    const formData = new FormData;
    for (var i = 0; i < fileInput.length; i++) {
      extension = this.FetchExtension(fileInput[i]);
      console.log("Extension at FileInput: ", extension);

      flag2 = false;
      if (fileInput[i]['type'].match(/image\/*/)) {
        for (var j = 0; j < this.imgmimetype.length; j++) {
          if (fileInput[i]['type'] == this.imgmimetype[j]) {
            flag2 = true;

            if (fileInput[i]['size'] > (1024 * 1024) && this.snackcounter == 0) {
              this.zone.run(() => {
                this.zone.run(() => {
                  this.snackbar.open(`Some images are larger than 1 MB. Will be compressed.`, "x", {
                    duration: 5000,
                    verticalPosition: 'top',
                    horizontalPosition: 'center'
                  });
                });
              });

              this.snackcounter += 1;
              imagelist.push(fileInput[i]);
            }
            else {
              flag = true;
              var reader = new FileReader();
              reader.onload = (e: any) => {
               this.urls.push({ url: e.target.result, type: "image" }) 
              }
              console.log("URL: ", this.urls)
              reader.readAsDataURL(fileInput[i]);
              formData.append("uploads[]", fileInput[i], fileInput[i]['name']);
              // this.fileData[this.fileData.length]=fileInput[i];
              // console.log("FileData: ",this.fileData);
            }
          }
        }

      }
      else if (fileInput[i]['type'].match(/audio\/*/)) {
        ;
        for (var j = 0; j < this.audiomimetype.length; j++) {
          if (fileInput[i]['type'] == this.audiomimetype[j]) {
            flag2 = true;
            if (fileInput[i]['size'] > (25 * 1024 * 1024)) {
              this.zone.run(() => {
                this.snackbar.open(`Audio files larger than 25 MB not allowed. Discarding!!!`, "x", {
                  duration: 5000,
                  verticalPosition: 'top',
                  horizontalPosition: 'center'
                });
              });
            }
            else {
              flag = true;
              var reader = new FileReader();
              reader.onload = (e: any) => {
                this.urls.push({ url: e.target.result, type: "audio" });
              }
              reader.readAsDataURL(fileInput[i]);
              formData.append("uploads[]", fileInput[i], fileInput[i]['name']);
            }
          }


        }
      }
      else if (fileInput[i]['type'].match(/video\/*/)) {
        for (var j = 0; j < this.videomimetype.length; j++) {
          if (fileInput[i]['type'] == this.videomimetype[j]) {
            flag2 = true;
            if (fileInput[i]['size'] > (25 * 1024 * 1024)) {
              this.zone.run(() => {
                this.snackbar.open(`Video files larger than 25 MB not allowed. Discarding!!!`, "x", {
                  duration: 5000,
                  verticalPosition: 'top',
                  horizontalPosition: 'center'
                });
              });
            }
            else {
              flag = true;
              var reader = new FileReader();
              reader.onload = (e: any) => {
                this.urls.push({ url: e.target.result, type: "video" });
              }
              reader.readAsDataURL(fileInput[i]);
              formData.append("uploads[]", fileInput[i], fileInput[i]['name']);
            }
          }
        }


      }
      else if (fileInput[i]['type'].match(/application\/*/) || fileInput[i]['type'].match(/text\/*/) || extension == "txt" || extension == "csv" || extension == "pdf" || extension == "doc" || extension == "docx" || extension == "xls" || extension == "xlsx" || extension == "ppt" || extension == "pptx") {
        console.log("Detected File Type: Document");
        flag2 = true;
        if (fileInput[i]['size'] > (25 * 1024 * 1024)) {
          this.zone.run(() => {
            this.snackbar.open(`Documents larger than 25 MB not allowed. Discarding!!!`, "x", {
              duration: 5000,
              verticalPosition: 'top',
              horizontalPosition: 'center'
            });
          });
        }
        else {
          flag = true;
          console.log("File extension: ", extension)
          var reader = new FileReader();
          this.urls.push({ url: null, type: "document", extension: extension });
          formData.append("uploads[]", fileInput[i], fileInput[i]['name']);
        }
      }

      else {

        this.zone.run(() => {
          this.snackbar.open(`Not a valid file!!`, "x", {
            duration: 5000,
            verticalPosition: 'top',
            horizontalPosition: 'center'
          });
        });
      }


    };
    console.log("PreviewURL", this.urls);

    if (flag2 == false && fileInput.length != 0) {
      console.log("Invalid File Type: ", fileInput);

      this.zone.run(() => {
        this.snackbar.open(`File type not supported by your browser!!`, "x", {
          duration: 5000,
          verticalPosition: 'top',
          horizontalPosition: 'center'
        });
      });
    }


    if (flag == true)
      this.messageService.saveFiles(formData).subscribe((data:any) => {
        console.log(data);
     data.forEach(element => {
       console.log(element);
       this.newEditData.push(element)
       
     });

   
        
        for (let i in data) {
          imagedata.push(data[i]);
          this.userForm.push(imagedata[i]._id);
        }
        this.dragFiles = [];
        this.files = [];
      });

    this.imgprocess(imagelist);
  }

  //To process image files inserted by user
  imgprocess(filelist: any) {

    var imagedata = [], tempfiles = [];

    let images: Array<IImage> = [];

    ImageCompressService.filesArrayToCompressedImageSource(filelist).then(observableImages => {

      observableImages.subscribe((image) => {

        images.push(image);

      }, (error) => {

        console.log("Error while converting: ", error);

      }, () => {

        let i = 0;
        for (let image of images) {
          var file = this.CreateBlobImage(image.compressedImage.imageDataUrl, filelist[i]['name']);
          // this.fileData.push(file);
          tempfiles.push(file);
          i++;
          // console.log("BlobFile: ",this.fileData[j]);          
          // i++;
          // console.log("File successfully inserted. ", this.fileData)
        }

        // console.log("FileData after inserting compressed images: ", this.fileData)
        var imagedata = [];

        if (tempfiles != []) {
          const formData = new FormData;

          for (let file of tempfiles) {
            var reader = new FileReader();
            reader.onload = (e: any) => {
              this.urls.push({ url: e.target.result, type: "image" });

            }
            reader.readAsDataURL(file);
            formData.append("uploads[]", file, file['name']);
          }
          console.log("Preview Files: ", this.urls)

          this.messageService.saveFiles(formData).subscribe(data => {
            for (let i in data) {
              imagedata.push(data[i]);
              this.userForm.push(imagedata[i]._id);
            }
          });
        }

      })
    });
  }

  draggedFilesList(file) {
    this.dragFiles.push(file);
    if (this.dragFiles.length == this.files.length) {
      this.fileProcess(this.dragFiles);
      console.log("drag length: ", this.files.length);
      console.log("Exported length: ", this.dragFiles.length);
    }
  }

  // Drag and Drop

  dropped(files: NgxFileDropEntry[]) {
   this.files = [];
    this.dragFiles = [];
    this.snackcounter = 0;
    console.log("Typeof: ", typeof this.files);
    for (const droppedFile of files) {
      // Is it a file?
      if (droppedFile.fileEntry.isFile) {
        this.files.push(droppedFile);
        const fileEntry = droppedFile.fileEntry as FileSystemFileEntry;
        fileEntry.file((file: File) => {
          console.log("Dragged File: ", file)
          this.draggedFilesList(file);
        });
      }
      else {
        // It was a directory (empty directories are added, otherwise only files)
        const fileEntry = droppedFile.fileEntry as FileSystemDirectoryEntry;
        console.log(droppedFile.relativePath, fileEntry);
      }
    }
  }
  fileDrag: any;
  public fileOver(event) {
    console.log(event);
    this.fileDrag = event
  }

  public fileLeave(event) {
    console.log(event);
  }

  DownloadSuccess(event) {
    console.log("DownloadEvent: ", event)
    this.zone.run(() => {
      this.snackbar.open(`File successfully downloaded!!`, "x", {
        duration: 5000,
        verticalPosition: 'top',
        horizontalPosition: 'center'
      });
    });
  }
  Downloadfail(event) {
    console.log("DownloadEvent: ", event)
    this.zone.run(() => {
      this.snackbar.open(`Unable to download file. Verify the permissions!!`, "x", {
        duration: 5000,
        verticalPosition: 'top',
        horizontalPosition: 'center'
      });
    });
  }


  // deltingAllmsgs will execute if user clicks clear chat then it will updatd senderDeltedEmailId == userlogin emailId
  deltingAllmsgs() {
    var details = {
      loginuser: this.id,
      chatuser: this.chatuser._id
    }
    this.userService.deltingAllmsgs(details).subscribe(data => {
      this.cdref.detectChanges();
    })
  }



  //This function wil execute when user clicks a single msg deleting
  del(delSinglemsgdata, index) {
    this.userService.deltingSinglemsg(delSinglemsgdata).subscribe(data => {
      this.userMessage[index] = data
      this.userMessage[index]
    })
  }

  undel(delSinglemsgdata, index) {
    this.userService.undeltingSinglemsg(delSinglemsgdata).subscribe(data => {
      this.userMessage[index] = data
    })
  }

  star(data, data1, index) {
    var obj = {
      data: data,         //msg docuemnt
      data1: data1        // login user id
    }
    this.messageService.staredMessages(obj).subscribe(res => {
      console.log(res);
      this.staredMessage = res;
      this.staredMessage[index] = res;
      this.userMessage[index] = res;
    })
  }

  /* 
 Function Name: sendlocation
 Input: None
 Output: Latitude and Longitude (Geo location of current user)
 Desc: When user clicks on send location, Check Grant permissions for location access or else send location link
 */

  sendlocation() {
    console.log("show my location");
    if (!navigator.geolocation) {
      console.warn('Geolocation is not supported/ Disabled by your browser')
    }
    else {
      navigator.geolocation.getCurrentPosition((Position) => {
        this.location = {
          latitude: Position.coords.latitude,
          longitude: Position.coords.longitude
        }
        console.log(this.location);
        this.locationlink = "https://www.google.com/maps?q="
        // console.log(this.locationlink)
        this.locationurl = `${this.locationlink}${this.location.latitude},${this.location.longitude}`;
        console.log(this.locationurl)
      },
        function () {
          // alert('unable to fetch location')
        })
    }
    this.cdref.detectChanges();
  }



  /*
Function Name: startRecording
Input: None
Output: Stream Bloburl with Blobdata (size and type of audio)
Desc: Calling the service for recording audio
Error: 
*/

  startRecording() {
    if (!this.isRecording) {
      this.isRecording = true;
      this.messageService.startRecording();
    }
  }
  /*
  Function Name: stopRecording
  Input: None
  Output: None
  Desc: Calling the service to stop audio recording
  Error: 
  */
  stopRecording() {
    if (this.isRecording) {
      this.messageService.stopRecording();
      this.isRecording = false;
    }
  }

  /*
  Function Name: clearRecordedData
  Input: None
  Output: Clearing the recorded Data
  Desc: deleting existing recorded audio data
  Error: --
  */
  clearRecordedData() {
    this.blobUrl = null;
    this.blobdata = null;
    this.audiodata = null;
  }

  //This function will execute when user clicks on block or unblock button
  blocking(blockdata1, blockdata2) {
    let obj = {
      senderEmailId: blockdata1,
      recieverEmailId: blockdata2
    }
    this.messageService.blockingData(obj).subscribe(data => {
      this.blockdfltdata = data
      console.log(this.blockdfltdata)
    })
  }


  //This function will execute when user clicks on notify me button
  slideData;
  slide(data1) {
    console.log(data1)
    let obj = {
      data1: data1
    }
    this.messageService.slideData(obj).subscribe(data => {
      this.slideData = data
      this.chatuser.slidedata = this.slideData.slidedata
      console.log(this.chatuser)
    })
  };
  

  resetloc() {
    this.locationurl = null;
    this.gotlocation.latitude = null;
    this.gotlocation.longitude = null;
  }

  // This function will execute when user clicks on forward message
  forwardmsg(userdata) {
    // document.getElementById('forwardmsg').click()

    this.messageService.forwardmsg(userdata).subscribe(data => {
      this.forwardmsgdata = data
    })

    let dialogRef = this.dialog.open(this.fwdMsgModal);
    dialogRef.afterClosed().subscribe(result => {
      // Note: If the user clicks outside the dialog or presses the escape key, there'll be no result
      if (result !== undefined) {
        if (result === 'yes') {
          // TODO: Replace the following line with your code.
          console.log('User clicked yes.');
        } else if (result === 'no') {
          // TODO: Replace the following line with your code.
          console.log('User clicked no.');
        }
      }
    })
  }



  // This is for forward message to multiple users
  frwdmsguserdetails(user) {
    if (this.loginuserdata.EmailId == user.from) {
      var value1 = this.listofusersfrwdmsgEmails.includes(user.receiverid.EmailId)
      if (value1 == true) {
        let x1 = this.listofusersfrwdmsgEmails.indexOf(user.receiverid.EmailId)
        let x2 = this.listofusersfrwdmsgId.indexOf(user.receiverid._id)
        this.listofusersfrwdmsgEmails.splice(x1, 1)
        this.listofusersfrwdmsgId.splice(x2, 1)
      } else {
        this.listofusersfrwdmsgEmails.push(user.receiverid.EmailId)
        this.listofusersfrwdmsgId.push(user.receiverid._id)
      }
    } else {
      var value2 = this.listofusersfrwdmsgEmails.includes(user.senderId.EmailId)
      if (value2 == true) {
        let y1 = this.listofusersfrwdmsgEmails.indexOf(user.senderId.EmailId)
        let y2 = this.listofusersfrwdmsgId.indexOf(user.senderId._id)
        this.listofusersfrwdmsgEmails.splice(y1, 1)
        this.listofusersfrwdmsgId.splice(y2, 1)
      } else {
        this.listofusersfrwdmsgEmails.push(user.senderId.EmailId)
        this.listofusersfrwdmsgId.push(user.senderId._id)
      }
    }
  }

  //This message will execute when user clicks 
  sendForwardMsg(emails, id, msgdata) {
    if (emails.length != []) {
      for (var i = 0; i <= emails.length; i++) {
        if (i == emails.length) {
          this.listofusersfrwdmsgEmails = []
          this.listofusersfrwdmsgId = []
        }
        this.counter = 1;
        this.searchValue = null;
        if (msgdata == null) {
          return false
        } else {
          var messageData = {
            message: msgdata,
            senderId: this.loginuserdata.id,
            senderEmail: this.loginuserdata.EmailId,
            senderName: this.loginuserdata.Name,
            receiverId: id[i],
            receiverEmailId: emails[i],
            photo: this.userForm,
            media: this.audiodata,
            isMedia: false,
            blobdata: this.blobdata,
            Gps: this.location,
            locationurl: this.locationurl
          }
          // if (!messageData.photo && !messageData.Gps && !messageData.locationurl) { messageData.isMedia = false }
          if ((messageData.photo.length == 0) && (messageData.media == null || !messageData.blobdata == null)
            && (!messageData.Gps && !messageData.locationurl)) { messageData.isMedia = false }
          else {
            messageData.isMedia = true;
          }
        }

        if ((messageData.message == null || messageData.message == undefined) && (messageData.isMedia == false) && (this.location == null)) {
          this.snackbar.open("No Input data", "x", {
            duration: 1000,
            verticalPosition: 'top',
            horizontalPosition: 'center'
          });
        }
        else {
          console.log("messageData", messageData);
          this.messageService.sendMessage(messageData).subscribe(res => {
            console.log("Res: ", res)
            this.blockingRes = res
            if (res == "You are in blocking state") {
              this.userForm = [];
              this.urls = [];
              this.blobUrl = null
              this.blobdata = null
              this.audiodata = null
              this.locationurl = null;
              this.snackbar.open("you are in blocked ", "x", {
                duration: 2000,
                verticalPosition: 'top',
                horizontalPosition: 'center'
              });
            } else {
              console.log("PreviewURL", this.urls);
              // this.userMessage.push(res);
              // var test = document.getElementById("test");
              // this.scrolltop = test.scrollHeight;
              // this.cdref.detectChanges();
              this.userForm = [];
              this.urls = [];
              this.dragFiles = [];
              this.blobUrl = null
              this.blobdata = null
              this.audiodata = null
              this.locationurl = null;
              this.files = [];
            }
          });
        };
      }
    } else {
      this.snackbar.open("Please select the user", "x", {
        duration: 2000,
        verticalPosition: 'top',
        horizontalPosition: 'center'
      });
    }
    document.getElementById("exampleModal").click()
  }


  //forward msg clear selected users data close function 
  frwdmsgcleardata() {
    this.listofusersfrwdmsgEmails = []
    this.listofusersfrwdmsgId = []
  }

  // select all users for forward message to all users
  selectallusers(selectallusers) {
    if (this.listofusersfrwdmsgEmails.length == selectallusers.length - 1) {
      this.listofusersfrwdmsgEmails = []
      this.listofusersfrwdmsgId = []
    } else {
      this.listofusersfrwdmsgEmails = []
      this.listofusersfrwdmsgId = []
      for (var i = 0; i < selectallusers.length; i++) {
        if (this.loginuserdata.EmailId == selectallusers[i].from) {
          var value1 = this.listofusersfrwdmsgEmails.includes(selectallusers[i].receiverid.EmailId)
          if (value1 == true) {
            let x1 = this.listofusersfrwdmsgEmails.indexOf(selectallusers[i].receiverid.EmailId)
            let x2 = this.listofusersfrwdmsgId.indexOf(selectallusers[i].receiverid._id)
            this.listofusersfrwdmsgEmails.splice(x1, 1)
            this.listofusersfrwdmsgId.splice(x2, 1)
          } else {
            if (selectallusers[i].senderId._id != this.chatuser._id && selectallusers[i].receiverid._id != this.chatuser._id) {
              this.listofusersfrwdmsgEmails.push(selectallusers[i].receiverid.EmailId)
              this.listofusersfrwdmsgId.push(selectallusers[i].receiverid._id)
            }
          }
        } else {
          var value2 = this.listofusersfrwdmsgEmails.includes(selectallusers[i].senderId.EmailId)
          if (value2 == true) {
            let y1 = this.listofusersfrwdmsgEmails.indexOf(selectallusers[i].senderId.EmailId)
            let y2 = this.listofusersfrwdmsgId.indexOf(selectallusers[i].senderId._id)
            this.listofusersfrwdmsgEmails.splice(y1, 1)
            this.listofusersfrwdmsgId.splice(y2, 1)
          } else {
            if (selectallusers[i].senderId._id != this.chatuser._id && selectallusers[i].receiverid._id != this.chatuser._id) {
              this.listofusersfrwdmsgEmails.push(selectallusers[i].senderId.EmailId)
              this.listofusersfrwdmsgId.push(selectallusers[i].senderId._id)
            }
          }
        }
      }
    }
  }

  // This function will execute when user wants to forward for a specific user search 
  searchName(data) {
    this.x = data;
    this.frwdmsglistusers = []
    for (var i = 0; i < this.listusers.length; i++) {
      if (this.loginuserdata.EmailId == this.listusers[i].from) {
        var search1 = this.listusers[i].receiverid.Name.includes(this.x);
        if (search1 == true) {
          this.frwdmsglistusers.push(this.listusers[i])
        }
      } else {
        var search2 = this.listusers[i].senderId.Name.includes(this.x);
        if (search2 == true) {
          this.frwdmsglistusers.push(this.listusers[i])
        }
      }
    }
  }


  // This function will execute when user clicks on star msgs then it will get all faviourates message
  STARMSGS(loginuserdata, chatuser) {
    let obj = {
      loginuserdata: loginuserdata,
      chatuser: chatuser
    }
    if (this.starmsg1 == false) {
      this.starmsg1 = true
      this.messageService.starmsg(obj).subscribe(statmsgsdata => {
        console.log(statmsgsdata)
        this.Staredmessage = statmsgsdata
      })
    } else {
      this.starmsg1 = false
    }
  }

  openMap() {
    const dialogRef = this.dialogbox.open(MapviewComponent, {

      disableClose: true,
      autoFocus: true,
      width: '526px',
      height: '590px',
      backdropClass: 'mapdrop',
      // position: {
      //   top:'15rem',
      //   left: 'auto'
      // },
      panelClass: 'mapdialog'
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
      if (result && result.locationId) {
        var gets = this;
        var xhr = new XMLHttpRequest()
        xhr.open("GET", 'https://geocoder.api.here.com/6.2/geocode.json?app_id=xeeSniVGFJguQieOyDvg&app_code=CYXw3RyDsetaa5pSVf3EAw&locationid=' + result.locationId + '&jsonattributes=1&gen=9')
        xhr.responseType = 'json'
        xhr.onload = function () {
          if (xhr && xhr.response) {
            let location = xhr.response.response.view[0].result[0].location.displayPosition;
            console.log("location", location);
            gets.gotlocation = {
              latitude: location.latitude,
              longitude: location.longitude
            }
            console.log("result", gets.gotlocation);
            gets.locationlink = "https://www.google.com/maps?q="
            console.log(gets.locationlink)
            gets.locationurl = `${gets.locationlink}${gets.gotlocation.latitude},${gets.gotlocation.longitude}`;
          }
        }
        xhr.send()
        xhr.onerror = function () {
        }
      }
      else {
        let ResArray = Array.isArray(result.position);
        console.log("result", result, Array.isArray(result.position));
        if (result && ResArray == true) {
          this.gotlocation = {
            latitude: result.position[0],
            longitude: result.position[1]
          }
          console.log("result", this.gotlocation);
          this.locationlink = "https://www.google.com/maps?q="
          console.log(this.locationlink)
          this.locationurl = `${this.locationlink}${this.gotlocation.latitude},${this.gotlocation.longitude}`;
        }
        else {
          if (result && ResArray == false) {
            this.gotlocation = {
              latitude: result.latitude,
              longitude: result.longitude
            }
            console.log("result", this.gotlocation);
            this.locationlink = "https://www.google.com/maps?q="
            console.log(this.locationlink)
            this.locationurl = `${this.locationlink}${this.gotlocation.latitude},${this.gotlocation.longitude}`;
          }
          console.log('No result');
        }
      }
    });
  }
  getCursorPosition(Inputfield) {
    if (Inputfield.selectionStart || Inputfield.selectionStart == '0') {
      this.cursorPos = Inputfield.selectionStart;  
   }
   console.log("Cursor Position: ",this.cursorPos)
  }

  EmojisArray = []; //Emoji array

  openEmoji() {
    var data:any
this.emojiobservable=this.userService.getEmoji().subscribe((data:any)=>{
  if(data) {
console.log(data);

if(this.searchValue==null) {
  this.searchValue=data.native;
  this.cursorPos=this.cursorPos+data.native.length;
  console.log(this.searchValue)
  console.log(this.cursorPos);
}
else {
  console.log(this.cursorPos);
  console.log(this.searchValue)
  console.log("1. ",this.searchValue.substring(0,this.cursorPos));
  console.log("2. ",data.native.length)
  console.log("3. ",this.searchValue.substring(this.cursorPos));
  this.searchValue=this.searchValue.substring(0,this.cursorPos)+data.native+this.searchValue.substring(this.cursorPos);
  console.log("4. ",this.searchValue)
  // this.searchValue=temp;
  this.cursorPos=this.cursorPos+data.native.length;
  console.log(this.cursorPos);
  console.log(this.searchValue)
}
  }
})
    const dialogRef = this.dialogbox.open(EmojiComponent, {

      disableClose: false,
      autoFocus: true,
      width: 'auto',
      height: 'auto',
      backdropClass: 'mapdrop',
      panelClass: 'emojidialog'
    });

    // dialogRef.afterOpened().subscribe(emojiresponse => {
    //   console.log("emojiresponse: ",emojiresponse);
    //   return emojiresponse;
    // })

    //dialog closed
    dialogRef.afterClosed().subscribe(emojiresponse => {
      console.log("After Closed")
      // console.log('emoji response', emojiresponse);
      this.emojiobservable.unsubscribe();
      // if (emojiresponse){
      //   if(this.searchValue==null) {
      //     this.searchValue=emojiresponse.native
      //   }
      //   else {
      //     this.searchValue+=emojiresponse.native
      //   }
      // }

    });

  }
  emojicollect(data) {
    console.log("invoking", data)
    this.EmojisArray.push(data);
    this.EmojisArray.forEach(emoji => {
      console.log(emoji.native, emoji.id)
    })
  }

  incognitochatCancel(){
    var data = { data: "incognitoResnull" }
    this.messageService.showres(data).subscribe(data => {
      })
      document.getElementById("incognitoTerminate").click()
    }

  users(user){
    // var data = { data: "incognitoResnull" }
    if (this.incognitoRes) { 
    if (this.incognitoRes.chatuser == this.loginuserdata.id || this.incognitoRes.loginuser == this.loginuserdata.id) {
    // this.messageService.showres(data).subscribe(data => {
    document.getElementById("incognitoTerminate").click()
      //  })
      }
    }

    console.log("testing", user);
    this.starmsg1 = false
    user.count = 0
    this.Userselected = user
    if(!this.incognitoRes){
    if (this.id == user.receiverid._id) {
      console.log("senderid", user.senderId._id)
      this.userService.getuserdata(user.senderId._id).subscribe(data => {
        console.log("responsedata", data);
        // this.valueChange=(data);
        this.route.navigate(['/navbar/main'], { queryParams: { id: this.Userselected._id, userid: user.senderId._id, value: false } });
      });
    }
    else if (this.id == user.senderId._id) {
      console.log("receiverid", user.receiverid)
      this.userService.getuserdata(user.receiverid._id).subscribe(data => {
        // this.valueChange=(data);
        this.route.navigate(['/navbar/main'], { queryParams: { id: this.Userselected._id, userid: user.receiverid._id, value: false } });
      });
    }
  }
  }

  priores
  /*
  Function Name: makePriority
  Input: Selected User data is coming
  Output: Sending priority status to backend
  Desc: Putting users in priority list and getting back into friends list
  Error: None
  */
  makePriority(priorityUser) {
    console.log("5656", priorityUser);

    if (this.id == priorityUser.senderId._id) {
      priorityUser.priorityBySender = !priorityUser.priorityBySender
    }
    else if (this.id == priorityUser.receiverid._id) {
      priorityUser.priorityByReceiver = !priorityUser.priorityByReceiver
    }
    let info = {
      id: priorityUser._id,
      priorityBySender: priorityUser.priorityBySender,
      priorityByReceiver: priorityUser.priorityByReceiver
    }
    console.log('information', info);
    this.userService.priorityFriends(info).subscribe(res => {
      this.priores = res
      console.log("123456789", this.priores);

    });
  }

  SearchMail21(e) {
    if ((e.which === 32 || e.which === 9 || e.which === 8 || e.which === 46) && e.target.value.trim() === "") {
      console.log('!!!!!!!!!!!!!!')
      return this.searchenable = false;

    }
    else { this.searchenable = true }
  }

  email
  SearchMail(email) {
    this.email = email
    if (this.email != undefined && this.email != '') {
      console.log("this.email: ", this.email);
      this.userService.getsearchedemail(this.email).subscribe((res: any) => {
        if (res !== null || res !== undefined) {
          console.log("res: ", res);
          this.response = res;
          this.loginUser = JSON.parse(localStorage.getItem('currentUser'));
          console.log("loginUser: ", this.loginUser);
          this.userService.getFriends(this.loginUser.id).subscribe((users: any) => {
            console.log("Users: ", users);
            for(let resp of this.response) {
              resp.user=null;
              var flag =false;
              for(let user of users) {              
                if(user.from == this.loginUser.EmailId) {
                  if(resp.EmailId == user.to) {
                    flag = true;
                    resp.user = user
                  }
                }
               else if(user.to == this.loginUser.EmailId) {
                  if(resp.EmailId == user.from) {
                    flag = true;
                    resp.user = user;
                  }
                }
              }
              if (flag == true) {
                resp.status = true;
              }
              else {
                resp.status = false;
              }
            }
            console.log("resp: ", this.response)
        });
      }
      });
    }

  }

  status: boolean = false
  InviteFriend(user) {
    console.log("user", user);
    user = {
      senderId: this.id,
      receiverid: user._id,
      senderEmailId: this.EmailId,
      receiverEmailId: user.EmailId,
      status: this.status,
    }
    console.log(user)
    this.userService.InvitedUser(user).subscribe(res => {
      console.log('res', res);
      this.invitefriendres = res;
      if (this.invitefriendres == 'You already sent a request or Already Your Friend') {
        this.snackbar.open(this.invitefriendres, "X", {
          duration: 5000,
          panelClass: ['bar-color'],
          horizontalPosition: 'right',
          verticalPosition: 'top'
        });
      }
      else {
        this.snackbar.open("Invitation sent", "X", {
          duration: 1000,
          panelClass: ['bar-color'],
          horizontalPosition: 'right',
          verticalPosition: 'top'
        });
      }
    })
    // user.reset()
  }

  onInvite = function (data) {
    console.log(data)
    if (data.valid) {
      this.recevData = data.value
      this.recmail = this.recevData.Emailid;
      console.log(this.recmail);
      this.error = true;

      if (this.recmail == undefined) {
        this.nodata = true;
      }

      else {
        data.value.slug = this.loginuserdata.slug;
        data.value.urllink = this.urllink;
        data.value.senderId = this.loginuserdata.id;
        data.value.senderEmailId = this.loginuserdata.EmailId;
        data.value.senderName = this.loginuserdata.Name;
        if (this.response) {
          data.value.receiverid = this.response._id;
          data.value.Name = this.response.Name
        }

        this.userService.sendInviteMail(data.value).subscribe(invitationack => {
          console.log("invack", invitationack);
          this.error = false;
          this.sendMailres = invitationack;

          if (this.sendMailres.result == "error") {
            this.userService.openSnackBar("NOO!! Something went wrong", "X");
          }
          else if (this.sendMailres == "Invitation Sent") {

            // to display success message
            this.invitationview = true;

            console.log(this.sendMailres);
            this.userService.openSnackBar(this.sendMailres, "X");
          }
          // you already sent the invitation
          else if (this.sendMailres == "you already sent the invitation") {
            this.userService.openSnackBar(this.sendMailres, "X");
          }
          console.log(this.recevData);
        });
        // document.getElementById("closeModal").click()
      }
    }

    data.reset()
  }


  createSlug = function (profile) {
    this.urllink = this.weburl + '/?slug=' + profile.slug;
  }


  checkInvitationMail(email) {
    console.log(email);
    var regexp = new RegExp('([A-Za-z]|[0-9])[A-Za-z0-9.]+[A-Za-z0-9]@((?:[-a-z0-9]+\.)+[a-z]{2,})');
    if (regexp.test(email)) {
      console.log(email);
      this.emailcheck = true
      this.userService.getuseremail(email).subscribe((res) => {
        if (res !== null || res !== undefined) {
          console.log(res);
          this.regresponse = res;

        }
      });

    }
  }

  showgmail() {
    this.viewcontact = true;
  }

  // This is for hide user 
  hideUser(data1, data2) {
    let obj = {
      senderId: data1.id,
      receiverid: data2._id,
    }
    this.messageService.hidemessage(obj).subscribe(data => {
      this.hideEmail = data
      console.log("hideEmaillllllssss",this.hideEmail)
      this.ActiveHideUsers(this.loginuserdata.EmailId)
      if (this.hideEmail.length != 0) {
        if (this.loginuserdata.id == this.hideEmail[0].receiverid._id) {
          this.selectedUser = this.hideEmail[0];
          this.route.navigate(['/navbar/main'], { queryParams: { id: this.selectedUser._id, userid: this.selectedUser.senderId._id, value: false } });
        } else {
          this.selectedUser = this.hideEmail[0]
          this.route.navigate(['/navbar/main'], { queryParams: { id: this.selectedUser._id, userid: this.selectedUser.receiverid._id, value: false } });
        }
      }
      this.hideEmail.forEach(element => {
        element.count = 0
      });
      this.listusers = data;
    })
  }

  // This is for unhide users list
  ActiveHideUsers(data) {
    this.messageService.activehideuser(data).subscribe(data => {
      this.activehideuserslist = data
    })
  }

  // This is for hide user into active user
  sendhidedata(loginuser, hideuser) {
    document.getElementById('activehideusers').click()
    let obj = {
      from: loginuser,
      to: hideuser
    }
    this.messageService.hideuser(obj).subscribe(data => {
      console.log("activehideusers", data)
      this.listusers = data;
      this.ActiveHideUsers(this.loginuserdata.EmailId)
    })
  }
  // This is for reply to exact message
  messagename
  reply(data) {
    console.log(data);
    this.message2 = data
    if(this.message2.photo && !this.message2.media && !(this.message2.Gps) )
    {
    this.messagename = this.message2.photo[0].originalFilename.substring(0,this.message2.photo[0].originalFilename.lastIndexOf("."))
    }
    if(this.message2.media)
    {
      console.log(this.message2.media);
      
    this.messagename = this.message2.media.originalFilename.substring(0,this.message2.media.originalFilename.lastIndexOf("."))
    }

  }


  // to close the modal
  close() {

    document.getElementById("closeModal").click()

  }

  // This is for delete contact from friendslist permanently
  deleteContact(data1, data2) {
    let obj = {
      senderId: data1.id,
      receiverid: data2._id
    }
    this.userService.deletecontact(obj).subscribe(data => {
      console.log("deletecontact", data)
      this.listusers = data;
      this.deletecontact = data
      if (this.deletecontact.length != 0) {
        if (this.loginuserdata.id == this.deletecontact[0].receiverid._id) {
          this.selectedUser = this.deletecontact[0];
          this.route.navigate(['/navbar/main'], { queryParams: { id: this.selectedUser._id, userid: this.selectedUser.senderId._id, value: false } });
        } else {
          this.selectedUser = this.deletecontact[0]
          this.route.navigate(['/navbar/main'], { queryParams: { id: this.selectedUser._id, userid: this.selectedUser.receiverid._id, value: false } });
        }
      }
      this.deletecontact.forEach(element => {
        element.count = 0
      });
    })
  }




  // This is for incognito button click function
  incognito(loginuser, chatuser) {
    let obj = {
      loginuserid: loginuser.id,
      chatuserid: chatuser._id
    }
    this.userService.inCognito(obj).subscribe(data => {
      console.log(data)
    })
  }

  // Image Upload 
  /*
  Function Name: onFileSelected
  Input: Image and Image Name
  Output: None
  Desc: Getting image as input and store in collection as path stored the image in uploads folder
   */

  onFileSelected(fileInput: any, title: any) {

    var imagedata;
    const file = fileInput.target.files[0];
    const reader = new FileReader();
    if (!title)
      reader.onload = () => {
        this.imagePreview = reader.result;
      };
    reader.readAsDataURL(file);
    this.filesToUpload = <Array<File>>fileInput.target.files;
    const formData: any = new FormData(); // for image
    const files: Array<File> = this.filesToUpload;

    formData.append("uploads[]", files[0], files[0]['name']);
    this.userService.saveFiles(formData).subscribe(data => {
      imagedata = data;
      if (title) {
        title.doc = imagedata._id;
        title.pic = imagedata.originalFilename;
      }
      else if (!title) this.userForm = imagedata._id
    });
  }


  // To select either public or private groups
  showpublic() {
    this.publicgroup = true;
  }

  showprivate() {
    this.publicgroup = false;
  }

  // To select either public or private groups end

  // emoji selector
  emojiview() {
    this.showemoji = !this.showemoji;
  }



  // When user accept the incognito chat
  incognitoACCEPT1(data) {
    this.messageService.incognitoACCEPT2(data).subscribe(data => {
    console.log(data)
      })
    for (var i = 0; i<= this.listusers.length; i++) {
      if (this.listusers[i].senderId._id == data.chatuser) {
        return this.route.navigate(['/navbar/main'], { queryParams: { id: this.listusers[i]._id, userid: this.listusers[i].senderId._id, value: false } });
      }
      if (this.listusers[i].receiverid._id == data.chatuser) {
        return this.route.navigate(['/navbar/main'], { queryParams: { id: this.listusers[i]._id, userid: this.listusers[i].receiverid._id, value: false } });
      }
    }
  }

  // When user reject the incogntio chat 
  incognitoreject1(data) {
    console.log(data)
    this.messageService.incognitoReject2(data).subscribe(data => {
      console.log(data)
    })
  }

  // This is for incognito user offline 
  incognitoUserOffline(loginuser,chatuser) {
    if (this.chatuser.loginStatus == 0) {
      this.snackbar.open("user is not in online", "x", {
        duration: 2000,
        verticalPosition: 'top',
        horizontalPosition: 'center'
      });
    }
    let obj = {
      login : loginuser,
      chat : chatuser
    }
    this.messageService.incognitoBlockstate(obj).subscribe(data=>{
      console.log(data)
      this.incognitoBlockState = data;
      if(this.incognitoBlockState.from == this.loginuserdata.EmailId){
        if(this.incognitoBlockState.fromblockingStatus == "blocked"){
          this.incognitopopupshow = true
          this.snackbar.open("please remove the user from block state", "x", {
            duration: 2000,
            verticalPosition: 'top',
            horizontalPosition: 'center'
          });
          
        }
          if(this.incognitoBlockState.toblockingStatus == "blocked"){ 
            this.incognitopopupshow = true
            this.snackbar.open("user was blocked to you", "x", {
              duration: 2000,
              verticalPosition: 'top',
              horizontalPosition: 'center'
            });
          }
      }
      if(this.incognitoBlockState.to== this.loginuserdata.EmailId){
        if(this.incognitoBlockState.fromblockingStatus == "blocked"){
          this.incognitopopupshow = true
          this.snackbar.open("user was blocked to you", "x", {
            duration: 2000,
            verticalPosition: 'top',
            horizontalPosition: 'center'
          });
        }
          if(this.incognitoBlockState.toblockingStatus == "blocked"){ 
            this.incognitopopupshow = true
            this.snackbar.open("please remove the user from block state", "x", {
              duration: 2000,
              verticalPosition: 'top',
              horizontalPosition: 'center'
            });
          }
      }
    })
  }

  //  To open groups modal
  CreateGroup() {
    let dialogRef = this.dialog.open(LoginComponent, {
      width: '600px',
      data: {
        type: 'group2',
        source: "CreateGroup"
      }


    });
    dialogRef.afterClosed().subscribe(result => {
      // Note: If the user clicks outside the dialog or presses the escape key, there'll be no result
      if (result !== undefined) {
        if (result === 'yes') {
          // TODO: Replace the following line with your code.
          this.groupcreated = false;
          console.log('User clicked yes.');
        } else if (result === 'no') {
          // TODO: Replace the following line with your code.
          console.log('User clicked no.');
        }
      }
    })
  }
  chatFriend(data) {
    console.log(data);
    for (let i = 0; i <= this.listusers.length; i++) {
      if (data.EmailId == this.listusers[i].receiverid.EmailId) {
        this.route.navigate(['/navbar/main'], { queryParams: { id: this.listusers[i]._id, userid: this.listusers[i].receiverid._id, value: false } });
      }
      if (data.EmailId == this.listusers[i].senderId.EmailId) {
        this.route.navigate(['/navbar/main'], { queryParams: { id: this.listusers[i]._id, userid: this.listusers[i].senderId._id, value: false } });
      }
    }


  }



  replymsg() {
    this.message2 = null
  }

  // for unsubscribing the observable services
  ngOnDestroy() {

    this.autorefreshgroupmessages.unsubscribe();
    this.autoRefreshFriends.unsubscribe();
    this.autoRefreshMessage.unsubscribe();
    this.autoRefreshRemoveMessage.unsubscribe();
    this.autorefreshgroupmessages.unsubscribe();
    this.autoRefreshRenameGroup.unsubscribe();
    this.autoRefreshLeaveGroup.unsubscribe();
    this.AutoRefreshMemberStatus.unsubscribe();
    this.AutoRefreshGroups.unsubscribe();
    this.IcognitoShowRes.unsubscribe();
    this.IcognitoDelRes.unsubscribe();
    this.IcognitoReject.unsubscribe();
    this.IcognitoChatAccept.unsubscribe();
    this.IcognitoChat.unsubscribe();
    this.getFriends.unsubscribe();
    this.autoRefreshPriorityRes.unsubscribe();
    this.autoRefreshDelAllMsg.unsubscribe();
    this.autoRefreshBlockdata.unsubscribe();
    this.autoMessageReceipt.unsubscribe();
    this.autoRefreshUndoMessage.unsubscribe();
    this.autoRefreshGroupEditMessage.unsubscribe();
    this.autoRefrshEditedMessage.unsubscribe();
  }



  //// copying the message to clipboard

  copyMessage(val: string) {
    const selBox = document.createElement('textarea');
    selBox.style.position = 'fixed';
    selBox.style.left = '0';
    selBox.style.top = '0';
    selBox.style.opacity = '0';
    selBox.value = val;
    document.body.appendChild(selBox);
    selBox.focus();
    selBox.select();
    document.execCommand('copy');
    document.body.removeChild(selBox);
  }


  /// pasting the image in to input by using ctrl v 

  mediaPaste(event: any, url) {
    setTimeout(() => {
      console.log( url.value)
      var data= {
        url:url.value
      }
      var regex = new RegExp("^(http[s]?:\\/\\/(www\\.)?|ftp:\\/\\/(www\\.)?|www\\.){1}([0-9A-Za-z-\\.@:%_\+~#=]+)+((\\.[a-zA-Z]{2,3})+)(/(.)*)?(\\?(.)*)?");
      console.log(regex.test(url.value))
      if (regex.test(url.value)) {
        this.messageService.videoUrl(data).subscribe(( data :any) => {
        var path = this.serverurl +'/'+ data.path;
          this.urls.push({ url: path, type: "video" });
          console.log(data)
          this.userForm.push(data._id)
        })
      }

    }, 1);


    const items = (event.clipboardData || event.originalEvent.clipboardData).items;
    let blob = null;

    for (const item of items) {
      if (item.type.indexOf('image') === 0) {
        blob = item.getAsFile();
        this.pasteimages(blob)
      }
    }
  }

  onInput(content: string) {
    console.log("New content: ", content);
  }
  pasteimages = (data: any) => {

    const formData: any = new FormData();
    console.log(formData);

    formData.append("uploads[]", data, data['name']);
    this.messageService.saveFiles(formData).subscribe(data => {
      var path = this.serverurl + '/' + data[0].path;
      this.urls.push({ url: path, type: "image" });
      this.userForm.push(data[0]._id)

    })
  }

  selectedMessage(data)
  {
   
   var index = this.userMessage.findIndex(x =>x._id == data.parentId._id )
   console.log(index);   
  this.selectedmessage=this.userMessage[index]._id
  console.log(this.selectedmessage)
  var element = document.getElementById(`${this.selectedmessage}`);
  console.log(element)
  element.scrollIntoView({behavior: "smooth"})
  }
}




