import { Component, OnInit, Output, EventEmitter, ChangeDetectorRef } from '@angular/core';
import { UserService } from 'src/app/services/user.service';
import { Router } from '@angular/router';
import { MessageService } from 'src/app/services/message.service';
import { MatSnackBar } from '@angular/material';
import { Subscription } from 'rxjs';
import { config } from 'src/app/configFile';
import { MatAutocompleteModule } from '@angular/material/autocomplete'


@Component({
  selector: 'app-sidenav',
  templateUrl: './sidenav.component.html',
  styleUrls: ['./sidenav.component.css']
})
export class SidenavComponent implements OnInit {
  subscription: Subscription
  receviedMess;
  listusers
  _id;
  name;
  test;
  loginuserdata;
  searchterm: String;
  searchenable: boolean = false;
  weburl;
  urllink;
  alreadyreg: Boolean;
  regresponse: any;
  nodata: Boolean = false;
  error: any;
  sendMailres;
  recmail;
  recevData;
 
  emailcheck: Boolean = false
  response: any = [];
  z: boolean = true;
  Message;
  Emailid: any;
  selectedUser: any;
  invitefriendres: any;
  invitedata: any
  priorityBySender;
  priorityByReceiver;
  currentuser: any;
  searchValue: any;
  urls: any[];
  userForm: any[];
  userMessage: Object;
  blockdata: any;
  priorityResponse: any;
  viewcontact: boolean;
  invitationview: boolean;
  userselect: boolean;
  valueChange;
  email;
  EmailId;
  makePriority;
  personadd:boolean;
  autorefreshFriendsUn: Subscription;
  constructor(private userService: UserService, private router: Router, private cdref: ChangeDetectorRef, private messageService: MessageService, private snackbar: MatSnackBar, private configs: config) {


    this.autorefreshFriendsUn=this.messageService.autorefreshFriends().subscribe(data => {
      console.log("autofriends list", data);
      if (data.senderId._id == this._id || data.receiverid._id == this._id) {
        this.userService.getFriends(this._id).subscribe(users => {
          this.listusers = users;
          this.listusers.push(data);
          console.log("updated list", this.listusers);
        })
      }
    });
    this.weburl = this.configs.getWeburl();
    this.loginuserdata = JSON.parse(localStorage.getItem('currentUser'));
    this._id = this.loginuserdata.id;
    this.name = this.loginuserdata.Name;
    this.Emailid = this.loginuserdata.EmailId;
    this.createSlug(this.loginuserdata)
 
    // this.messageService.autoRefresMessage().subscribe(data => {
    //   console.log(data)
    //   if (data.receiverId == this._id && this.selectedUser.senderId._id != data.senderId && this.selectedUser.receiverid._id != data.senderId) {
    //     var index = this.listusers.findIndex(x => (x.senderId._id == data.senderId) || (x.receiverid._id == data.senderId))
    //     this.listusers[index].count = this.listusers[index].count + 1;
    //   }
    //   // This is for msg read reciepts
    //   if (data.receiverId == this._id && (this.selectedUser.senderId._id == data.senderId || this.selectedUser.receiverid._id == data.senderId)) {

    //     this.messageService.msgSeen(data).subscribe(data1 => {
    //       console.log(data1)
    //     })
    //   }
    // });
    this.alreadyreg = false;

  }

  ngOnInit() {
    this.userService.getFriends(this._id).subscribe(users => {
      this.listusers = users;
      console.log(this.listusers);
     

    })
  }
  id;
  userdetails(user) {
    console.log("user", user);
    this.selectedUser = user;
    localStorage.setItem('chatuser', JSON.stringify( this.selectedUser));
    this.userService.userName(user)
    this.userService.sendData(this.selectedUser)
    user.count = 0
  
    if (this._id == user.receiverid._id) {
      console.log("senderid", user.senderId._id)
      this.userService.getuserdata(user.senderId._id).subscribe(data => {
        console.log("responsedata", data);
     
        this.router.navigate(['/navbar/main'], { queryParams: { id: this.selectedUser._id,userid:user.senderId._id, value:false } });

      });
    }
    else if(this._id == user.senderId._id) {
      console.log("receiverid", user.receiverid)
      this.userService.getuserdata(user.receiverid._id).subscribe(data => {
 
      this.router.navigate(['/navbar/main'], { queryParams: { id: this.selectedUser._id,userid:user.receiverid._id, value:false} });

    

      });
    }
  }

  SearchMail21(e) {
    if ((e.which === 32 || e.which === 9 || e.which === 8 || e.which === 46) && e.target.selectionStart === 0) {
      console.log('!!!!!!!!!!!!!!')
   
      return false;
    }
    else { this.searchenable = true }
  }


  SearchMail(email) {
    if (email != undefined && email != '') {
      console.log(email);
      this.userService.getsearchedemail(email).subscribe((res) => {
        if (res !== null || res !== undefined) {
          console.log(res);
          this.response = res;
        }
      });
    }
  }


  data;
  status: boolean = false
  InviteFriend(user) {
    console.log("user", user);
    user = {
      senderId: this._id,
      receiverid: user._id,
      senderEmailId: this.Emailid,
      receiverEmailId: user.EmailId,
      status: this.status,
    }
    console.log(user)
    this.userService.InvitedUser(user).subscribe(res => {
      console.log('res', res);
      this.invitefriendres = res;
      if (this.invitefriendres == 'You already sent a request or Already Your Friend') {
        this.snackbar.open(this.invitefriendres, "X", {
          duration: 5000,
          panelClass: ['bar-color'],
          horizontalPosition: 'right',
          verticalPosition: 'top'
        });
      }
      else {
        this.snackbar.open("Invitation sent", "X", {
          duration: 1000,
          panelClass: ['bar-color'],
          horizontalPosition: 'right',
          verticalPosition: 'top'
        });
      }
    })
    user.reset()
  }

  onInvite = function (data) {
    console.log(data)
    if (data.valid) {
      this.recevData = data.value
      console.log(this.recevData)
      this.recmail = this.recevData.EmailId;
      console.log(this.recmail);
      this.error = true;

      if (this.recevData.EmailId == undefined) {
        this.nodata = true;
      }
      else {
        data.value.slug = this.loginuserdata.slug;
        data.value.urllink = this.urllink;
        data.value.senderId = this.loginuserdata.id;
        data.value.senderEmailId = this.loginuserdata.EmailId;
        data.value.senderName = this.loginuserdata.Name;
        if (this.response) {
          data.value.receiverid = this.response._id;
          data.value.Name = this.response.Name
        }

        this.userService.sendInviteMail(data.value).subscribe(invitationack => {
          console.log("invack", invitationack);
          this.error = false;
          this.sendMailres = invitationack;

          if (this.sendMailres.result == "error") {
            this.userService.openSnackBar("NOO!! Something went wrong", "X");
          }
          else if (this.sendMailres == "Invitation Sent") {
                
      // to display success message
    this.invitationview=true;

            console.log(this.sendMailres);
            this.userService.openSnackBar(this.sendMailres, "X");
          }
          // you already sent the invitation
          else if (this.sendMailres == "you already sent the invitation") {
            this.userService.openSnackBar(this.sendMailres, "X");
          }
          console.log(this.recevData);
        });
        // document.getElementById("closeModal").click()
      }
    }

    data.reset()
  }


  createSlug = function (profile) {
    this.urllink = this.weburl + '/?slug=' + profile.slug;
  }


  checkInvitationMail(email) {
    console.log(email);
    var regexp = new RegExp('([A-Za-z]|[0-9])[A-Za-z0-9.]+[A-Za-z0-9]@((?:[-a-z0-9]+\.)+[a-z]{2,})');
    if (regexp.test(email)) {
      console.log(email);
      this.emailcheck = true
      this.userService.getuseremail(email).subscribe((res) => {
        if (res !== null || res !== undefined) {
          console.log(res);
          this.regresponse = res;
  
        }
       
      });

    }
  }


  showgmail(){
    this.viewcontact=true;
  }
  
  // to close the modal
  close(){

    document.getElementById("closeModal").click()
    
  }
  ngOnDestroy(){
    this.autorefreshFriendsUn.unsubscribe();
  }
}
