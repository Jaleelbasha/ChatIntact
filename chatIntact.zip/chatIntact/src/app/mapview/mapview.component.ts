import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { MainComponent } from '../main/main.component';
import { MatDialogRef } from '@angular/material';
import { UserService } from '../services/user.service';

@Component({
  selector: 'app-mapview',
  templateUrl: './mapview.component.html',
  styleUrls: ['./mapview.component.css']
})
export class MapviewComponent implements OnInit {

  public query: string;
  location = null;
  locationlink
  locationurl = null;
  nearbylocations:any;
  selectedlocationData
  constructor(private cdref: ChangeDetectorRef,  private userService: UserService,public dialogRef: MatDialogRef<MainComponent>)
    { 
      this.userService.nearbyplacechange.subscribe(data=>{
        this.nearbylocations = data;
      });
 
    }

  ngOnInit() { }

  onNoClick(): void {
    this.dialogRef.close();
  }

  locationname(data) {
    this.query = data.label;
    this.selectedlocationData = data;
  }

  selectedlocation(place) {
    this.dialogRef.close(place);

  }
  GO(){
    if(this.selectedlocationData){
      this.dialogRef.close(this.selectedlocationData);
    }  
  }

/* 
 Function Name: sendlocation
 Input: None
 Output: Latitude and Longitude (Geo location of current user)
 Desc: When user clicks on send location, Check Grant permissions for location access or else send location link
 */

sendlocation() {
  console.log("show my location");
  if (!navigator.geolocation) {
    console.warn('Geolocation is not supported/ Disabled by your browser')
  }
  else {
    navigator.geolocation.getCurrentPosition((Position) => {
      this.location = {
        latitude: Position.coords.latitude,
        longitude: Position.coords.longitude
      }
      console.log(this.location);
      this.dialogRef.close(this.location)
      this.locationlink = "https://www.google.com/maps?q="
      // console.log(this.locationlink)
      this.locationurl = `${this.locationlink}${this.location.latitude},${this.location.longitude}`;
      console.log(this.locationurl)
    },
      function () {
        // alert('unable to fetch location')
      })
  }
  this.cdref.detectChanges();
}

}