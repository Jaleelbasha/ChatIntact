export class config {

    constructor() { }

    weburl = "http://localhost:4200"
    getWeburl() {
        return this.weburl;
    }
}
//https://scm.webchatbot.co.uk