import { Component, OnInit,ChangeDetectorRef, ViewChild } from '@angular/core';
import { UserService } from '../services/user.service';
import { MatSnackBar } from '@angular/material';
import { Router } from '@angular/router';
import { NgForm } from '@angular/forms';
@Component({
  selector: 'app-userprofile',
  templateUrl: './userprofile.component.html',
  styleUrls: ['./userprofile.component.css']
})
export class UserprofileComponent implements OnInit {
  
  singleUser: any;
  imagePreview: any;
  filesToUpload: Array<File> = [];
  userForm: any;
  userprofiledata:any;
  profile: any;
  validclick: boolean;
  Name
  showme:Boolean

  constructor(private userService:UserService,private snackbar:MatSnackBar,private router:Router) { 
    this.singleUser = JSON.parse(localStorage.getItem('currentUser'));
    console.log(this.singleUser)
    this.autoRefreshUser();

  }

  autoRefreshUser() {
    this.userService.autoRefreshUserProfile().subscribe(data => {
      this.LoadUserProfile()
    })
  }


  LoadUserProfile() {
    this.userService.get('userprofiles/get/current').subscribe(data => {
      this.userprofiledata = data;
      console.log("currentuserprofile",this.userprofiledata);
      if (!this.userprofiledata)
      if (this.userprofiledata)  this.disp(this.userprofiledata);
    })
  }

  disp= function(profile) {
    this.LoadData['FullName'] = profile.FullName;
    this.LoadData['Bio'] = profile.Bio;
    if (profile.photo) { this.photo = profile.photo; }
  }

  ngOnInit() {
    this.LoadProfile();
  }

  LoadProfile() {

   this.userService.get('users/me').subscribe(data => {
      this.profile = data;
      console.log("me",this.profile)
      
      this.LoadUserProfile();
    });
  }

  createProfile(userprofile)
  {
    this.validclick = true;
    console.log(userprofile);
    console.log('userform', this.userForm);
    if(userprofile.valid)
    {
      console.log(userprofile.value)
      const userprofiledata = userprofile.value
      userprofiledata.photo = this.userForm;
      console.log(userprofiledata)
      this.userService.add('userprofiles/saveuser', userprofiledata).subscribe(data => {
        console.log('addsaveuser', data);
        
        if (data) {
          this.showme = true;
          this.updateUser(this.profile._id, userprofiledata);
        }
      });
      this.snackbar.open('Profile updated','x',{
            duration:1000,
            verticalPosition:'top',
            horizontalPosition:'center'
          })
    }
    else{
      this.snackbar.open('enter data into fields','x',
      {
        duration:1000,
        verticalPosition:'top',
        horizontalPosition:'center'
      })
    }
    this.router.navigate(['Uprofile'])

  }


  updateUser(id, info) {
    this.userService.update('users/updateprofile/' + id, info).subscribe(data => { 
      console.log('updateuser data', data)
    });
  }

  // Image Upload 
  /*
  Function Name: onFileSelected
  Input: Image and Image Name
  Output: None
  Desc: Getting image as input and store in collection as path stored the image in uploads folder
   */

   onFileSelected(fileInput:any, title:any) {

    var imagedata;
    const file = fileInput.target.files[0];
    const reader = new FileReader();
    if(!title) 
      reader.onload = () =>{
        this.imagePreview = reader.result;
      };
      reader.readAsDataURL(file);
      this.filesToUpload = <Array<File>>fileInput.target.files;
      const formData: any = new FormData(); // for image
      const files: Array<File> = this.filesToUpload;
      
      formData.append("uploads[]", files[0], files[0]['name']);
      this.userService.saveFiles(formData).subscribe(data => {
        imagedata = data;
        if(title) {
          title.doc = imagedata._id;
          title.pic = imagedata.originalFilename;
        }
        else if (!title) this.userForm = imagedata._id
      });
  }
  close()
  {
    this.router.navigate(['navbar/main'])
  }

  updateProfile(updatedata) {      
    console.log("testing")
    updatedata.value.photo = this.userForm;
    this.userService.update('userprofiles/updateprofile/' + this.userprofiledata._id, updatedata.value).subscribe(data => {
      if (data) {
        this.updateUser(this.profile._id,updatedata.value);
        this.userService.openSnackBar("Profile Updated Successfully", "X");
        this.LoadUserProfile();
        this.router.navigate(['Uprofile'])
      }
    });
  }
}

