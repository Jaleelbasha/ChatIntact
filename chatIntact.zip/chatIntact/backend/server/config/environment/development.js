'use strict';

// Development specific configuration
// ==================================
module.exports = {
  // MongoDB connection options 
  mongo: {
    uri:'mongodb+srv://chatapp_user:Q7VCnVrgQrqMYtVc@chat-app-ewobx.mongodb.net/test_db'
  },
  seedDB: false
};
