var passport = require('passport');
var LocalStrategy = require('passport-local').Strategy;

exports.setup = function (User, config) {
  // based on schema we will define the same field name here => EmaiId, password
  passport.use(new LocalStrategy({
    username: 'EmailId',
      password: 'password' // this is the virtual field on the model
    },
    function(EmailId, password, done) {
      User.findOne({
        EmailId: EmailId.toLowerCase()
      }).populate('roleid').exec(function(err, user) {
        if (err) return done(err);

        if (!user) {
          console.log('return response', 'This email is not registered.')
          return done(null, false, { message: 'This email is not registered.' });
        }
        if (!user.authenticate(password)) {
          return done(null, false, { message: 'This password is not correct.' });
        }
        if (user.status!="Active")
        {
          return done(null, false, { message: 'This is blocked account... Please contact Admin.' });
        }
        return done(null, user);
      });
    }
  ));
};