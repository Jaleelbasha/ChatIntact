'use strict';

var _ = require('lodash');
var Media = require('./media.model');

// Get list of medias
exports.index = function(req, res) {
  Media.find(function (err, medias) {
    if(err) { return handleError(res, err); }
    return res.status(200).json(medias);
  });
};

// Get a single media
exports.show = function(req, res) {
  Media.findById(req.params.id, function (err, media) {
    if(err) { return handleError(res, err); }
    if(!media) { return res.status(404).send('Not Found'); }
    return res.json(media);
  });
};

// Creates a new media in the DB.
exports.create = function(req, res) {
  var imagedata=[];
  var extension=null,type=null;
  for(let file of req.files.uploads){
    if(file.type == "application/octet-stream") {
      var pos = file.originalFilename.length;
      console.log("OriginalFilename length: ",pos);
      while (pos>0) {
        if(file.originalFilename.charAt(pos - 1) == '.')
        {
          break;
        }
        else {
          pos--;
        }
      }
      extension=file.originalFilename.substring(pos);
      console.log(extension);
      if(extension == "pdf") {
        type="application/pdf"
      }
      else if(extension == "txt") {
        type="text/plain"
      }
      else if(extension == "csv") {
        type="text/csv"
      }
      else if(extension == "doc"){
        type="application/msword"
      }
      else if(extension == "docx"){
        type="application/vnd.openxmlformats-officedocument.wordprocessingml.document"
      }
      else if(extension == "ppt") {
        type="application/vnd.ms-powerpoint";
      }
      else if(extension == "pptx"){
        type="application/vnd.openxmlformats-officedocument.presentationml.presentation"
      }
      else if(extension == "xls") {
        type="application/vnd.ms-excel"
      }
      else if(extension == "xlsx") {
        type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
      }
    }
    else {
      type = file.type;
    }
    // console.log("File Details: ",file)
    imagedata.push({
      originalFilename: file.originalFilename,
      path: file.path,
      size: file.size,
      name: file.name,
      type: type,     
    })
  }
  var image=[];
  // console.log("ImageData",imagedata);
  for(var i in imagedata) {
    Media.create(imagedata[i], function(err, medias) {
      // console.log("Medias: ", medias);
      image.push(medias);
      console.log("image", image)
      console.log("imagelength", imagedata.length, image.length)
      // console.log('resfromdb for ',imagedata[i].originalFilename," : ", medias);
      if(err) { return handleError(res, err); }
      if(imagedata.length === image.length) { return res.status(201).json(image); }
    });

  }
}

// Updates an existing media in the DB.
exports.update = function(req, res) {
  if(req.body._id) { delete req.body._id; }
  Media.findById(req.params.id, function (err, media) {
    if (err) { return handleError(res, err); }
    if(!media) { return res.status(404).send('Not Found'); }
    var updated = _.merge(media, req.body);
    updated.save(function (err) {
      if (err) { return handleError(res, err); }
      return res.status(200).json(media);
    });
  });
};

// Deletes a media from the DB.
exports.destroy = function(req, res) {
  Media.findById(req.params.id, function (err, media) {
    if(err) { return handleError(res, err); }
    if(!media) { return res.status(404).send('Not Found'); }
    media.remove(function(err) {
      if(err) { return handleError(res, err); }
      return res.status(204).send('No Content');
    });
  });
};
//// downloading the url link 
exports.urldata=function(req,res){
  console.log(req.body);
  const download=require('download');
  const fs =require('fs')
  download(req.body.url).then(async data => {
    var fileName = req.body.url;
    var extension = fileName.replace(/^.*\./, '');
    console.log (extension);
var encryptedname= Math.round(Date.now())
    fs.writeFileSync('./uploads/' + encryptedname+'.'+extension, data);
  var   stats = fs.statSync('./uploads/' + encryptedname+'.'+extension)
    console.log(encryptedname);
    var exec =require('child_process').exec;
var path=' ./uploads/'+encryptedname+'.'+extension;

exec(`file -b --mime-type ${path}` ,function(error,stdout,stderr){
    console.log(stdout)
    console.log(error)
    var image={
      originalFilename: 'chatintact',
      path: 'uploads/'+  encryptedname+'.'+extension,
      size: stats.size,
      name:  encryptedname+'.'+extension,
      type: stdout.trim(''),     
    }
    Media.create(image, function(err, medias) {
      if(err) { return handleError(res, err); }
      if(medias) { return res.status(201).json(medias); }
    });
})


 

})


}

function handleError(res, err) {
  return res.status(500).send(err);
}