'use strict';

var _ = require('lodash');
var Friendslist = require('./friendslist.model');
var Notifications = require('../notification/notification.model'); 
var Messages= require('../message/message.model');
const async = require('async')
// For Creating Notification for

// Get list of friendslists
exports.index = function (req, res) {
  Friendslist.find(function (err, friendslists) {
    if (err) { return handleError(res, err); }
    return res.status(200).json(friendslists);
  });
};

// Get a single friendslist
exports.show = function (req, res) {
  Friendslist.findById(req.params.id).populate('senderId').populate('receiverid').exec(function (err, friendslist) {
    if (err) { return handleError(res, err); }
    if (!friendslist) { return res.status(404).send('Not Found'); }
    return res.json(friendslist);
  });
};

// Creates a new friendslist in the DB.
exports.create = function (req, res) {
  Friendslist.create(req.body, function (err, friendslist) {
    if (err) { return handleError(res, err); }
    return res.status(201).json(friendslist);
  });
};

//Creating friendslist in the DB.
exports.creatingFriends = function (req, res) {
  console.log("11111111111111111111111111111111111",req.body);
  
  Friendslist.findOne(
    { $or : [ {$and: [{from: req.body.senderEmailId, to: req.body.receiverEmailId}] }, 
              {$and: [ {from: req.body.receiverEmailId, to:req.body.senderEmailId}] } ] },function(err,response){
    
    if(response){
     
      var Message = 'You already sent a request or Already Your Friend';
      return res.status(201).json(Message);
    }
    else{
      Friendslist.create({ from: req.body.senderEmailId, to: req.body.receiverEmailId, senderId:req.body.senderId, receiverid:req.body.receiverid, 
                           fromblockingStatus:"unblocked state", toblockingStatus:"unblocked state" ,fromhideshow:'value will be updated',tohideshow:'value will be updated'}, (err, data) => {
        if (err) throw err;
        else {
         
          /*Creating notification for friend request */
          createNotification(data);
          return res.status(201).json(data);        }
      })
    }
  });
}


//Getting priority friends
exports.priorityFriends = function(req, res){

  Friendslist.findOneAndUpdate({_id:req.body.id}, {$set :{priorityBySender:req.body.priorityBySender,  priorityByReceiver:req.body.priorityByReceiver}}, {new: true}).populate('senderId').populate('receiverid').exec((err,response)=>{
    if(err) throw err;
  
    require('../../app').socket.emit('friendslist:psave',response); // emit update friend to data
    return res.status(200).json(response)
  });
}




/* 
Function Name: createNotification
@Input: JSON data
@Output: JSOn
@Desc: Creating Notification with corresponding data (FriendRequestId,SenderId, ReceiverId, Request-Type, Read)
*/
function createNotification(data) {

  var notificationdata = { Frid: data._id, senderId: data.senderId, receiverid: data.receiverid, status: data.invitationStatus, read: 'false', 
                           type: 'FriendRequest' }
  console.log("notification data2", notificationdata);

  Notifications.create(notificationdata, (err, notificationack) => {
    console.log('dsfsdf',notificationack)
    var id = notificationack._id;
    console.log("222",id)
    Notifications.findOne({ _id:id}).populate('senderId','Name').populate('receiverid','Name').exec(function (err, newdata) {
    
       if (err) { return handleError(res, err); }
        console.log("55555",newdata);
       // if (!friendslist) { return res.status(404).send('Not Found'); }
      // return res.json(friendslist);
      require('../../app').socket.emit('notification:save',newdata)
    });

    
    if (err) throw err;
    else {
      console.log("notification ack", notificationack);
    }
  });
}

//Getting Friends list and getting Unseen messages

exports.gettingFriends = function (req, res) {
  Friendslist.find({ $and: [{ $or: [{ senderId: req.user._id, fromhideshow:"value will be updated" }, { receiverid: req.user._id,tohideshow:'value will be updated'}] }, { invitationStatus: 'Accepted' }] }).populate('senderId').populate('receiverid').exec(function (err, friends) {
    if (err) { return handleError(res, err); }
    var friendsdata=JSON.parse(JSON.stringify(friends))

    async.each(friendsdata, function(friend, callback) {
        
      if(req.user._id == friend.senderId._id) {
       Messages.find({ receiverId: req.user._id, senderId:friend.receiverid._id }).sort({create_At: -1}).exec(function (err, message) {
        var msgfilter = message.filter(m=>(m.messageStatus=='✔' || m.messageStatus =='✔✔') && m.deletingMsgstatus != '1');
        friend.count=msgfilter.length;
          callback()
           });
      }
      else {
        Messages.find({ receiverId: req.user._id, senderId: friend.senderId._id }).sort({create_At: -1}).exec(async function (err, message) {
          var msgfilter = message.filter(m=>(m.messageStatus=='✔' || m.messageStatus =='✔✔') && m.deletingMsgstatus != '1');
          friend.count=msgfilter.length
          callback()
           });
      }
    },function (err) {  
      require('../../app').socket.emit('friendsdata:save',friendsdata);
      return res.status(200).json(friendsdata);
    });
  });
}

//Invitations list
exports.myInvitations = function (req, res) {
  Friendslist.find({ $or: [{ senderId: req.user._id }, { receiverid: req.user._id }] }).populate('senderId').populate('receiverid').sort({create_At: -1}).exec(function (err, userinfo) {
    if (err) { return handleError(res, err); }
    return res.status(200).json(userinfo);
  });
}

// Making Priority Updates
exports.priorityFriends = function(req, res){
  Friendslist.findOneAndUpdate({_id:req.body.id}, {$set :{priorityBySender:req.body.priorityBySender,  priorityByReceiver:req.body.priorityByReceiver}}, {new: true}).populate('senderId').populate('receiverid').exec((err,response)=>{
    if(err) throw err;
    else{
  
    require('../../app').socket.emit('priorityresponse', response);
    }
    return res.status(200).json(response)
  });
}

//Making Invitation Status update
exports.updatingAccept = function (req, res) { 
  console.log("req.body", req.body);
  let status = req.body.status;
  Friendslist.findOneAndUpdate({ _id: req.body._id }, { $set: {invitationStatus: req.body.status } }, { new: true }, (err, data) => {
    // console.log("data", data);  
    if (err) throw err;
      else {
        require('../../app').socket.emit('friendslist:save',data);
  
        Notifications.findOneAndUpdate(
          { Frid: data._id }, { $set: { status: data.invitationStatus } }, function (err, res) {
        
          Notifications.findOne({_id:res._id}).populate('senderId').populate('receiverid').exec(function(err, updatenotifier) {
            if(err) throw err;
            else {
         
              require('../../app').socket.emit('friendslist:save',updatenotifier); // emit update friend to data
              require('../../app').socket.emit('notification:save',updatenotifier);
            }
          });
        });
        // UpdateNotification(data);
      }
      return res.status(200).json(data);
    })
}

// Updates an existing friendslist in the DB.
exports.update = function (req, res) {
  if (req.body._id) { delete req.body._id; }
  Friendslist.findById(req.params.id, function (err, friendslist) {
    if (err) { return handleError(res, err); }
    if (!friendslist) { return res.status(404).send('Not Found'); }
    var updated = _.merge(friendslist, req.body);
    updated.save(function (err) {
      if (err) { return handleError(res, err); }
      return res.status(200).json(friendslist);
    });
  });
};

// Deletes a friendslist from the DB.
exports.destroy = function (req, res) {
  Friendslist.findById(req.params.id, function (err, friendslist) {
    if (err) { return handleError(res, err); }
    if (!friendslist) { return res.status(404).send('Not Found'); }
    friendslist.remove(function (err) {
      if (err) { return handleError(res, err); }
      return res.status(204).send('No Content');
    });
  });
};


// This function will execute when user click on Delete contact then user will be deleted from the friendslist permanently
exports.deletecontact = async function(req,res){
  if(req.body != null){
  Friendslist.findOneAndRemove({$or:[{senderId:req.body.senderId,receiverid:req.body.receiverid},{receiverid:req.body.senderId,senderId:req.body.receiverid}]},function(err,response){
  Messages.find({$or:[{senderId:req.body.senderId,receiverId:req.body.receiverid},{receiverId:req.body.senderId,senderId:req.body.receiverid}]},function(err,updatingmsgs){
  if(updatingmsgs.length == 0){
  Friendslist.find({$or:[{senderId:req.body.senderId,invitationStatus:'Accepted' },{receiverid:req.body.senderId,invitationStatus:'Accepted'}]}).populate('senderId').populate('receiverid').exec(function (err, deletecontactfriends) {
  return res.status(200).json(deletecontactfriends)
     });
    }else{  
  for(var i=0;i<updatingmsgs.length;i++){
  if(updatingmsgs[i].deletingfriend != 'deletingfriend'){
  Messages.update(updatingmsgs[i],{$set:{deletingfriend:"deletingfriend"}},function(err,respons){
           })
          } 
  if(updatingmsgs.length-1 == i){
  Friendslist.find({$or:[{senderId:req.body.senderId,invitationStatus:'Accepted' },{receiverid:req.body.senderId,invitationStatus:'Accepted'}]}).populate('senderId').populate('receiverid').exec(function (err, deletecontactfriends) {
  return res.status(200).json(deletecontactfriends)
           });
          }
        }
       }
      })
    })
  }
}

// This function will execute when user clicks on hide user    
exports.hideShow =  async function (req, res) {
  var flag =0;
     await Friendslist.update({senderId:req.body.senderId, receiverid:req.body.receiverid,invitationStatus:'Accepted'},{$set:{fromhideshow:1}},function(err1,res2){
      if(err1) throw err1;
     
    })
    await Friendslist.update({senderId:req.body.receiverid, receiverid:req.body.senderId,invitationStatus:'Accepted'},{$set:{tohideshow:1}},function(err1,res2){
      if(err1) throw err1;
     
    })

  // setTimeout(function(){  
     await Friendslist.find({$or:[{senderId:req.body.senderId,invitationStatus:'Accepted',fromhideshow:"value will be updated"},{receiverid:req.body.senderId,invitationStatus:'Accepted',tohideshow:'value will be updated'}]}).populate('senderId').populate('receiverid').exec(function (err, hideuserres){
      //  console.log("hideuserressssssssssssssS",hideuserres)
       return res.status(200).json(hideuserres)
     });
    // }, 1000);
}

// This function will execute when user clicks on active hide users
exports.activeusers = function(req,res){
  Friendslist.find({$or:[{from:req.body.data,invitationStatus:'Accepted',fromhideshow:1},{to:req.body.data,invitationStatus:'Accepted',tohideshow:1}]},function(err,activehideusers){
   return res.status(200).json(activehideusers)
  })
}

// This is for active hide user
exports.hideUser = async function(req,res){
  await Friendslist.update({from:req.body.from,to:req.body.to,invitationStatus:'Accepted',fromhideshow:1},{$set:{fromhideshow:'value will be updated'}},function(err,updatehideuser1){
    }).then(()=>{
      console.log("updddd");
    });
  await Friendslist.update({to:req.body.from,from:req.body.to,invitationStatus:'Accepted',tohideshow:1},{$set:{tohideshow:'value will be updated'}},function(err,updatehideuser2){
    })
 await Friendslist.find({$or:[{from:req.body.from,invitationStatus:'Accepted',fromhideshow:"value will be updated"},{to:req.body.from,invitationStatus:'Accepted',tohideshow:'value will be updated'}]}).populate('senderId').populate('receiverid').exec( function (err, hideuserres){
   return res.status(200).json(hideuserres)
 });
}

// This is for incognito chat       
exports.INCOGNITOCHAT = function(req,res){
  Friendslist.find({senderId:req.body.loginuserid,receiverid:req.body.chatuserid},function(err,incognitoresponse){
    let obj1 = {
      loginuser:req.body.chatuserid,
      chatuser:req.body.loginuserid     
    }
    if(incognitoresponse.length != 0){
      require('../../app').socket.emit('incognito:chat',obj1);
      return res.status(200).json(incognitoresponse)
    }   
    Friendslist.find({senderId:req.body.chatuserid,receiverid:req.body.loginuserid},function(err,incognitoresponse2){
      let obj2 = {
      loginuser : req.body.chatuserid,
      chatuser:req.body.loginuserid
      }
      if(incognitoresponse2.length != 0){
        require('../../app').socket.emit('incognito:chat',obj2);
        return res.status(200).json(incognitoresponse2)
      }   
    })
  })
}

function handleError(res, err) {
  return res.status(500).send(err);
}
