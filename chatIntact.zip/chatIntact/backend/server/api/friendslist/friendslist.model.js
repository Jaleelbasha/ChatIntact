'use strict';

var mongoose = require('mongoose'),
    Schema = mongoose.Schema;

    var FriendslistSchema = new Schema({
      from : String,
      to : String,
      fromhideshow:String,
      tohideshow:String, 
      fromblockingStatus:String,
      toblockingStatus:String,
      count : { type:Number, defalut: 0},
      invitationStatus : {type : String, default : 'Pending'},
      userid: { type: Schema.Types.ObjectId, ref: 'User' },
      senderId: { type: Schema.Types.ObjectId, ref: 'User' },
      receiverid: { type: Schema.Types.ObjectId, ref: 'User' },
      priorityBySender:{type:Boolean, default : false},
      priorityByReceiver :{ type : Boolean, default : false},
     },{ timestamps: true });

module.exports = mongoose.model('Friendslist', FriendslistSchema);