'use strict';

var _ = require('lodash');
var Userprofile = require('./userprofile.model');
var User = require('../user/user.model');
var media = require('../media/media.model')
//var Notification = require('../notification/notification.model');
// Get list of userprofiles
exports.index = function(req, res) {
  Userprofile.find(function (err, userprofiles) {
    if(err) { return handleError(res, err); }
    return res.status(200).json(userprofiles);
  });
  
};


// Get userprofile
exports.CurrentUserInfo = function (req, res) {
  console.log('req get userprofile', req.user._id);
  Userprofile.findOne({uid: req.user._id}).populate('userid').populate('photo').exec(function (err, userinfo) {
    if(err) {return handleError(res, err); }
    console.log("userinfo",userinfo);
    return res.status(200).json(userinfo);
  })
}

// Get a single userprofile
exports.show = function(req, res) {
  Userprofile.findById(req.params.id, function (err, userprofile) {
    if(err) { return handleError(res, err); }
    if(!userprofile) { return res.status(404).send('Not Found'); }
    return res.json(userprofile);
  });
};

// Creates a new userprofile in the DB.
exports.create = function (req, res) {
  console.log("sssssssssssss",req.body)
   Userprofile.find({_id:req.body._id},function(err,updateprofres){
     console.log(updateprofres)
     if(updateprofres.length != 0){
      Userprofile.findOne({_id:req.body._id},function(err,response){
        Userprofile.update(response,{$set:{UserName:req.body.Name,FullName:req.body.FullName,EmailId:req.body.EmailId,Bio:req.body.bio,mobileno:req.body.mobile,photo:req.body.photo}},{new:true},function(err,resp){     
          Userprofile.findOne({_id:req.body._id},function(err,finalresp){
            media.find({_id:finalresp.photo},function(err,photo){  
              return res.status(200).json({data:photo});
            })
           
          })
         
        }) 
       })
     }else{
      req.body.uid = req.user._id;
      req.body.userid = req.user._id;
      req.body.Bio = req.body.bio;
      req.body.mobileno =req.body.mobile
      console.log("profilecreation",req.body);
      Userprofile.create(req.body, function (err, profile) {
      console.log("999999999",profile)
        if (err) return res.status(500).send(err);
        User.findById(req.user._id).exec(function (err, user) {
          console.log('userupdatedata', user);
          var update = _.merge(user)
          update.save();
        })
      media.findOne({_id:profile.photo},function(err,response){
        console.log(response)
        return res.status(200).json({result:response});
      })
     
      });
     }
   })
	
}
// Updates an existing userprofile in the DB.
exports.update = function(req, res) {
  if(req.body._id) { delete req.body._id; }
  Userprofile.findById(req.params.id, function (err, userprofile) {
    if (err) { return handleError(res, err); }
    if(!userprofile) { return res.status(404).send('Not Found'); }
    var updated = _.merge(userprofile, req.body);
    updated.save(function (err) {
      if (err) { return handleError(res, err); }
      return res.status(200).json(userprofile);
    });
  });
};

// Deletes a userprofile from the DB.
exports.destroy = function(req, res) {
  Userprofile.findById(req.params.id, function (err, userprofile) {
    if(err) { return handleError(res, err); }
    if(!userprofile) { return res.status(404).send('Not Found'); }
    userprofile.remove(function(err) {
      if(err) { return handleError(res, err); }
      return res.status(204).send('No Content');
    });
  });
};



exports.updateprofile = function(req,res){
Userprofile.findOne({_id:req.params.id},function(err,response){
  Userprofile.update(response,{$set:{userName:req.body.Name,FullName:req.body.FullName,EmailId:req.body.EmailId,Bio:req.body.Bio,mobileno:req.body.mobileno,photo:req.body.photo,UserName:req.body.UserName}},{new:true},function(err,resp){
    console.log("response:",resp)
    res.status(200).json({res:"Success"}) 
  })

 })
}



function handleError(res, err) {
  return res.status(500).send(err);
}