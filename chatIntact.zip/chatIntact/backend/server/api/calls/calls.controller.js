'use strict';

var _ = require('lodash');
var Calls = require('./calls.model');

// Get list of callss
exports.index = function(req, res) {
  Calls.find(function (err, callss) {
    if(err) { return handleError(res, err); }
    return res.status(200).json(callss);
  });
};

// Get a single calls
exports.show = function(req, res) {
  Calls.findById(req.params.id, function (err, calls) {
    if(err) { return handleError(res, err); }
    if(!calls) { return res.status(404).send('Not Found'); }
    return res.json(calls);
  });
};

// Creates a new calls in the DB.
exports.create = function(req, res) {
  Calls.create(req.body, function(err, calls) {
    if(err) { return handleError(res, err); }
    return res.status(201).json(calls);
  });
};

// Updates an existing calls in the DB.
exports.update = function(req, res) {
  if(req.body._id) { delete req.body._id; }
  Calls.findById(req.params.id, function (err, calls) {
    if (err) { return handleError(res, err); }
    if(!calls) { return res.status(404).send('Not Found'); }
    var updated = _.merge(calls, req.body);
    updated.save(function (err) {
      if (err) { return handleError(res, err); }
      return res.status(200).json(calls);
    });
  });
};

// Deletes a calls from the DB.
exports.destroy = function(req, res) {
  Calls.findById(req.params.id, function (err, calls) {
    if(err) { return handleError(res, err); }
    if(!calls) { return res.status(404).send('Not Found'); }
    calls.remove(function(err) {
      if(err) { return handleError(res, err); }
      return res.status(204).send('No Content');
    });
  });
};

function handleError(res, err) {
  return res.status(500).send(err);
}