'use strict';

var mongoose = require('mongoose'),
    Schema = mongoose.Schema;

var CallsSchema = new Schema({
  name: String,
  info: String,
  active: Boolean,
  callerId: String,
  callreceiverIdList: Object,
  create_At: { type: Date, required: true, default: Date.now },
  Type: {type: String, status:'inactive'}
});

module.exports = mongoose.model('Calls', CallsSchema);