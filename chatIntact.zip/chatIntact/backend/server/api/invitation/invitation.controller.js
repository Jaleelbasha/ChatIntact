'use strict';

var _ = require('lodash');
var Invitation = require('./invitation.model');
const nodemailer = require('nodemailer');
var async = require('async');
const moment = require('moment');
var crypto = require('crypto');
var algorithm = 'aes256'; // or any other algorithm supported by OpenSSL
var key = '123';
var User = require('../user/user.model');
var Groupmember = require('../groupmember/groupmember.model');

// Get list of invitations
exports.index = function(req, res) {
  Invitation.find(function (err, invitations) {
    if(err) { return handleError(res, err); }
    return res.status(200).json(invitations);
  });
};

// get list of friends
exports.getFriends = function(req, res) {
  var id = req.user._id;
  Invitation.find({
    $or:[
      {senderId: id},
      {receiverid:id}]
  }, function(err, Friends) {
    if(err) { return handleError(res, err); }
    return res.status(200).json(Friends);
    });
}

// Get a single invitation
exports.show = function(req, res) {
  Invitation.findById(req.params.id, function (err, invitation) {
    if(err) { return handleError(res, err); }
    if(!invitation) { return res.status(404).send('Not Found'); }
    return res.json(invitation);
  });
};

// Creates a new invitation in the DB.
exports.create = function (req, res) {
console.log(req.body)
var usersdata=req.body


Object.size = function(obj) {
var size = 0, key;
for (key in obj) {
  if (obj.hasOwnProperty(key)) size++;
}
return size;
};
// Get the size of an object
var size = Object.size(req.body.EmailId);
// for(var i=0;i<size;i++){
  let userObj = {
    EmailId : req.body.Emailid
  };          
let obj = {
  EmailId : req.body.Emailid,
  senderEmailId : req.body.senderEmailId
}
  req.body.sender = req.body.id;
  var mailCreatedAt = moment().format('ddd, MMM D, YYYY hh:mm:ss A');
  var mailExpiredAt = moment().add(1800, 'seconds').format('ddd, MMM D, YYYY hh:mm:ss A');
  req.body.create_At = mailCreatedAt;
  req.body.expire_At = mailExpiredAt;
  var text = req.body.EmailId + "-" + mailCreatedAt + "-" + mailExpiredAt;
  var cipher = crypto.createCipher(algorithm, key);
  var encrypted = cipher.update(text, 'utf8', 'hex') + cipher.final('hex');

  nodemailer.createTestAccount((err, account) => {
    let transporter = nodemailer.createTransport({
      service: 'gmail',
      port: 25,
      secure: false, 
      auth: {
        user: 'rahul.pentakota@cognitiveinnovations.in',
        pass: 'anna@COGNITIVE' 
      }
    });

    // setup email data with unicode symbols
    let mailOptions = {
      from: '"CHATINTACT 👻" <rahul.pentakota@cognitiveinnovations.in>',
      to: obj.EmailId, 
      subject: 'INVITATION ✔',
      text: 'Hello', 
      html: "Click here to join the ChatApp : " + req.body.urllink + '/' + obj.EmailId
      // html: 'http://localhost:4200/?'+  req.body.slug + '/' + req.body.EmailId 
    };
    console.log('mailoptions', mailOptions.html);
     User.findOne(userObj,function(err,resp){
      if(!resp){
       Invitation.findOne(obj,function(err,response){
         if(!response){
           transporter.sendMail(mailOptions, (error, info) => {
             if (error) { }
              req.body.slug = req.body.slug;
              // usersdata.Emailid='';
              usersdata.Emailid=userObj.EmailId
              usersdata.receiverid=req.body.senderId;
              usersdata.urllink=req.body.urllink;
              console.log("usersdata: ",usersdata);
              Invitation.create(usersdata,function(err,response){
              console.log("response",response)
              })               
           });
         }
       else{
           // return res.status(200).json("you already sent the invitation");
          }
        });
    }
     else {
       // return res.status(200).json("User already is registered");
 }
    })
  });
// }
// return res.status(200).json("Invitation Sent"); 
}

// Updates an existing invitation in the DB.
exports.update = function(req, res) {
  if(req.body._id) { delete req.body._id; }
  Invitation.findById(req.params.id, function (err, invitation) {
    if (err) { return handleError(res, err); }
    if(!invitation) { return res.status(404).send('Not Found'); }
    var updated = _.merge(invitation, req.body);
    updated.save(function (err) {
      if (err) { return handleError(res, err); }
      return res.status(200).json(invitation);
    });
  });
};

// Deletes a invitation from the DB.
exports.destroy = function(req, res) {
  Invitation.findById(req.params.id, function (err, invitation) {
    if(err) { return handleError(res, err); }
    if(!invitation) { return res.status(404).send('Not Found'); }
    invitation.remove(function(err) {
      if(err) { return handleError(res, err); }
      return res.status(204).send('No Content');
    });
  });
};

exports.GroupinvitationExpiry = function(req,res) {
  console.log("Group.body",req.body);
  let presentTime = moment().format();
  Invitation.findOne({$and:[{GroupId: req.body.GroupId},{senderId:req.body.InvitedBy},{EmailId:req.body.InviteeEmail}]},async function(req2,response){
    // console.log("invitationExpiry: ",response)
    if(response){
      let expireTime = moment(response.expire_At).format();
      console.log("expireTime: ",expireTime)
      console.log("presentTime: ",presentTime)
      if(presentTime <= expireTime) {
      res.status(200).json("SUCCESS");
      }
      else {
        await Invitation.remove(response,function(req1,res1) {
          console.log("Expired Invitation Deleted");
        });
        console.log("Req.body: ",req.body)
        await Groupmember.remove({$and:[{GroupId: req.body.GroupId},{memberEmailId: req.body.InviteeEmail}]},function(req3,res2) {
          console.log("Invalid Group Member deleted.")
        })
        return await res.status(401).json("Link Expired");
      }
    }
  });
}

exports.invitationExpiry = function(req,res){   
  let obj = {
    slug : req.body.invitationexpirydata.slug,
    EmailId : req.body.invitationexpirydata.email
  };
  let presentTime = moment().format();
  Invitation.findOne(obj,(req,response)=>{
    console.log("invitationExpiry: ",response)
    if(response){
      let createdTime = moment(response.expire_At).format();
      if(presentTime <= createdTime) {
      res.status(200).json("SUCCESS");
      }
    }
  });
};

function handleError(res, err) {
  return res.status(500).send(err);
}