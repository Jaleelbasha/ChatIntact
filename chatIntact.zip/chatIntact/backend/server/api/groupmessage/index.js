'use strict';

var express = require('express');
var controller = require('./groupmessage.controller');

var router = express.Router();

router.get('/', controller.index);
router.get('/:id', controller.show);
router.post('/', controller.create);
router.post('/groupMessages', controller.groupMessages)
router.post('/removeBadgeCount', controller.removeBadgeCount)
router.get('/getMessages/:id', controller.getMessages);
router.post('/getMessageschat', controller.getMessageschat);
router.post('/editMessage', controller.editGroupMessage);
router.put('/:id', controller.update);
router.patch('/:id', controller.update);
router.delete('/:id', controller.destroy);

module.exports = router;