'use strict';

var _ = require('lodash');
var Groupmessage = require('./groupmessage.model');
const async = require('async');
var Groupmember = require('../groupmember/groupmember.model')

// Get list of groupmessages
exports.index = function (req, res) {
  Groupmessage.find(function (err, groupmessages) {
    if (err) {
      return handleError(res, err);
    }
    return res.status(200).json(groupmessages);
  });
};

// Get a single groupmessage
exports.show = function (req, res) {
  Groupmessage.findById(req.params.id, function (err, groupmessage) {
    if (err) {
      return handleError(res, err);
    }
    if (!groupmessage) {
      return res.status(404).send('Not Found');
    }
    return res.json(groupmessage);
  });
};
//Creates a new groupmessages in the DB
exports.groupMessages = function (req, res) {
  Groupmessage.create({
    message: req.body.message,
    groupSenderId: req.body.groupSenderId,
    groupReceiverId: req.body.groupReceiverId,
    GroupId: req.body.groupId,
    unReadMessages: req.body.unReadMessages,
    photo: req.body.photo
  }, function (err, result) {
    console.log("groupmessage populate", result)
    if (err) throw err;
    if (result) {
      Groupmessage.findById({
        _id: result._id
      }).populate('groupSenderId').populate('groupReceiverId').populate('GroupId').populate('photo').exec((err, createdMessage) => {
        console.log("populated msg", createdMessage);
        if (err) {
          return handleError(res, err);
        }
        if (!createdMessage) {
          return res.status(404).send('Not Found');
        } else {
          require('../../app').socket.emit('gmessages:save', createdMessage);
          return res.status(201).json(result)
        }
      });
    }
    // require('../../app').socket.emit('gmessages:save',result); 
    // return res.status(201).json(result)
  });
}
// Getting group messages
exports.getMessages = function (req, res) {
  Groupmessage.find({
    $and: [{
      GroupId: req.params.id
    }, {
      deletedStatus: true
    }]
  }).populate('photo').populate('groupSenderId').populate('groupReceiverId').populate('GroupId').exec((err, messages) => {
    if (err) throw err;
    return res.status(200).json(messages)

  })

}
// Edit group message
exports.editGroupMessage = function(req, res){
  Groupmessage.findOneAndUpdate({_id:req.body.id}, {$set:{photo:req.body.photo, message:req.body.message}},{new:true}).populate('groupSenderId').populate('groupReceiverId').populate('GroupId').populate('photo').exec(function(err, response){
    if(err) throw err;
    require('../../app').socket.emit('gedit:save', response);    
  })
  
}



//Getting badge count of groups
exports.getMessageschat = function (req, res) {
  Groupmember.find({
    $and: [{
      memberId: req.body.id
    }, {
      isJoin: 'Accepted'
    }, {
      deletedStatus: true
    }]
  }).populate('creatorId').populate('memberId').populate('GroupId').exec(function (err, result) {
    if (err) throw err;
    var groups = JSON.parse(JSON.stringify(result));
    async.each(groups, function (group, callback) {
      Groupmessage.find({
        $and: [{
          GroupId: group.GroupId._id,
          deletedStatus: true,
          unReadMessages: {
            $all: req.body.id
          }
        }]
      }).populate('unReadMessages').exec((err, count) => {
        if (err) throw err;
        var bCount = count.length
        group.badgeCount = bCount
        console.log(group.badgeCount);
        callback();
      })

    }, function (err) {
      return res.status(200).json(groups)
    })
  })
}
//remove Badge count
exports.removeBadgeCount = function (req, res) {
  Groupmessage.update({
    GroupId: req.body.gid
  }, {
    $pull: {
      unReadMessages: {
        $in: req.body.id
      }
    }
  }, {
    multi: true
  }, (err, result) => {
    if (err) throw err;
    console.log(result);
    // require('../../app').socket.emit('gcount:save',result); 
    return res.status(200).json(result)



  })
}

// Creates a new groupmessage in the DB.
exports.create = function (req, res) {
  Groupmessage.create(req.body, function (err, groupmessage) {
    if (err) {
      return handleError(res, err);
    }
    return res.status(201).json(groupmessage);
  });
};

// Updates an existing groupmessage in the DB.
exports.update = function (req, res) {
  if (req.body._id) {
    delete req.body._id;
  }
  Groupmessage.findById(req.params.id, function (err, groupmessage) {
    if (err) {
      return handleError(res, err);
    }
    if (!groupmessage) {
      return res.status(404).send('Not Found');
    }
    var updated = _.merge(groupmessage, req.body);
    updated.save(function (err) {
      if (err) {
        return handleError(res, err);
      }
      return res.status(200).json(groupmessage);
    });
  });
};

// Deletes a groupmessage from the DB.
exports.destroy = function (req, res) {
  Groupmessage.findById(req.params.id, function (err, groupmessage) {
    if (err) {
      return handleError(res, err);
    }
    if (!groupmessage) {
      return res.status(404).send('Not Found');
    }
    groupmessage.remove(function (err) {
      if (err) {
        return handleError(res, err);
      }
      return res.status(204).send('No Content');
    });
  });
};

function handleError(res, err) {
  return res.status(500).send(err);
}