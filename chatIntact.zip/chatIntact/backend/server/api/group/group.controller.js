'use strict';

var _ = require('lodash');
var Group = require('./group.model');
var shortid = require('shortid');
var Groupmember = require('../groupmember/groupmember.model')
// Get list of groups
exports.index = function (req, res) {
  Group.find(function (err, groups) {
    if (err) {
      return handleError(res, err);
    }
    return res.status(200).json(groups);
  });
};

// Get a single group
exports.show = function (req, res) {
  Group.findById(req.params.id, function (err, group) {
    if (err) {
      return handleError(res, err);
    }
    if (!group) {
      return res.status(404).send('Not Found');
    }
    return res.json(group);
  });
};
// Checking group exist or not
exports.checkingGroupExist = function(req, res) {
  Group.find({_id:req.params.gid}, function(err, group){
    if(err) throw err;
    return res.status(200).json(group)
  })
}

// Creates a new group in the DB.
exports.create = function (req, res) {
  console.log("req.body group", req.body);
  var groupdata = req.body;
  console.log("user data", req.user._id)
  Group.find({
    $and: [{
      GroupName: req.body.GroupName
    }, {
      creatorId: req.user._id
    }]
  }).exec(function (err, groupfound) {
    if (err) throw err;
    console.log("groupfound", groupfound);
    if (groupfound !== null && groupfound.length > 0) {
      return res.json({
        response: 'You already created this group'
      });
    } else {
      groupdata.GuniqueId = groupdata.GroupName + shortid.generate(groupdata.GroupName);
      console.log('groupdata', groupdata);

      Group.create(groupdata, function (err, groupresult) {
        if (err) throw err;
        console.log('lllllllllllllppppppppppppppppp', groupresult);
        require('../../app').socket.emit('groupsGetting:save', groupresult);
        Groupmember.create({
          GroupId: groupresult._id,
          creatorId: groupresult.creatorId,
          isJoin: 'Accepted',
          memberId: groupresult.creatorId,
          memberEmailId: groupresult.creatorEmailId
        }, function (err, results) {
          if (err) throw err;
          console.log(results);
        });
        return res.status(201).json({
          response: 'Group Created Successfully',
          groupresult
        })
      });
    }
  })

};
// Rename the group
exports.renameGroup = (req, res) => {
  Group.findByIdAndUpdate({
    _id: req.body.id
  }, {
    $set: {
      GroupName: req.body.rename
    }
  }, {
    new: true
  }, (err, change) => {
    if (err) throw err;
    console.log(change);
    require('../../app').socket.emit('grename:save', change);
    return res.status(200).json(change)

  })

}

// Updates an existing group in the DB.
exports.update = function (req, res) {
  if (req.body._id) {
    delete req.body._id;
  }
  Group.findById(req.params.id, function (err, group) {
    if (err) {
      return handleError(res, err);
    }
    if (!group) {
      return res.status(404).send('Not Found');
    }
    var updated = _.merge(group, req.body);
    updated.save(function (err) {
      if (err) {
        return handleError(res, err);
      }
      return res.status(200).json(group);
    });
  });
};

// Deletes a group from the DB.
exports.destroy = function (req, res) {
  Group.findById(req.params.id, function (err, group) {
    if (err) {
      return handleError(res, err);
    }
    if (!group) {
      return res.status(404).send('Not Found');
    }
    group.remove(function (err) {
      if (err) {
        return handleError(res, err);
      }
      return res.status(204).send('No Content');
    });
  });
};



exports.groupsMail = function (req, res) {
  console.log('lllllllllllllllll', req.body);

  nodemailer.createTestAccount((err, account) => {
    let transporter = nodemailer.createTransport({
      service: 'gmail',
      port: 25,
      secure: false,
      auth: {
        user: 'rahul.pentakota@cognitiveinnovations.in',
        pass: 'anna@COGNITIVE'
      }
    });
    req.body.mail.forEach(Email => {


      // setup email data with unicode symbols
      let mailOptions = {
        from: '"CHATINTACT 👻" <rahul.pentakota@cognitiveinnovations.in>',
        to: Email,
        subject: 'INVITATION ✔',
        text: 'Hello',
        html: "Click here to join the chat Group: " + req.body.url + Email
        // html: 'http://localhost:4200/?'+  req.body.slug + '/' + req.body.EmailId 
      };
      transporter.sendMail(mailOptions, (error, info) => {
        if (error) {}
      })
    })
  })
}


exports.updatingGroup = function (req, res) {
  console.log("groupdata", req.body)

  Groupmember.findOneAndUpdate({
    _id: req.body._id
  }, {
    $set: {
      memberStatus: req.body.status
    }
  }, (err, data) => {
    if (err) throw err;
    else {
      require('../../app').socket.emit('friendslist:save', data);
      console.log("updatestatus", data);
      Notifications.findOneAndUpdate({
        Grid: data._id
      }, {
        $set: {
          status: data.memberStatus
        }
      }, function (err, res) {
        console.log("ressssssssssssss", res);
        Notifications.findOne({
          _id: res._id
        }).populate('creatorId').populate('memberId').exec(function (err, updatenotifier) {
          if (err) throw err;
          else {
            console.log("updatenotifier", updatenotifier);
            require('../../app').socket.emit('friendslist:save', updatenotifier); // emit update friend to data
            require('../../app').socket.emit('groupNotifications:save', updatenotifier);
          }
        });
      });
      // UpdateNotification(data);
    }
    return res.status(200).json(data);
  })
}

function handleError(res, err) {
  return res.status(500).send(err);
}