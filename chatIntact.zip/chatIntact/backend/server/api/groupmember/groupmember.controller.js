'use strict';
``

var _ = require('lodash');
var Groupmember = require('./groupmember.model');
var async = require('async')
var User = require('../user/user.model')
var Notification = require('../notification/notification.model');
var Invitation = require('../invitation/invitation.model');
const nodemailer = require('nodemailer');
const moment = require('moment');
var Group = require('../group/group.model');
var Groupmessage = require('../groupmessage/groupmessage.model');

// Get list of groupmembers
exports.index = function (req, res) {
  Groupmember.find(function (err, groupmembers) {
    if (err) {
      return handleError(res, err);
    }
    return res.status(200).json(groupmembers);
  });
};

// Get a single groupmember
exports.show = function (req, res) {
  Groupmember.findById(req.params.id, function (err, groupmember) {
    if (err) {
      return handleError(res, err);
    }
    if (!groupmember) {
      return res.status(404).send('Not Found');
    }
    return res.json(groupmember);
  });
};

// Creates a new groupmember in the DB.
exports.create = function (req, res) {
  Groupmember.create(req.body, function (err, groupmember) {
    if (err) {
      return handleError(res, err);
    }
    return res.status(201).json(groupmember);
  });
};
//Getting groups 
exports.getgroups = function (req, res) {
  Groupmember.find({
      $and: [{
        memberId: req.params.id
      }, {
        isJoin: 'Accepted'
      }, {
        deletedStatus: true
      }]
    })
    .populate('creatorId').populate('memberId').populate('GroupId').exec(function (err, result) {
      if (err) throw err;
      return res.status(200).json(result)
    })
}

exports.getgroups2 = function (req, res) {
  console.log("req.params.id: ", req.params.id)
  Groupmember.find({
      GroupId: req.params.id
    })
    .populate('creatorId').populate('memberId').populate('GroupId').exec(function (err, result) {
      console.log("Result of new document: ", result)
      if (err) throw err;
      return res.status(200).json(result)
    })
}

//adding members in a group
exports.addingMembers = async function (req, res) {
  console.log("req.body Adding Members: ", req.body);
  var weburl = req.body.weburl;

  async.each(req.body.members, function (data, cb) {
    if (data.category == "1") {
      console.log("Category 1 member: ", data)
      Groupmember.create({
        GroupId: req.body.groupId,
        creatorId: req.body.creatorId,
        isJoin: req.body.isJoin,
        memberId: data.id,
        memberEmailId: data.emailid
      }, function (err, response) {
        if (err) throw err;
        createNotification(response)
        cb(); //Switch to next element in async each
      })
    } else if (data.category == "2") {
      console.log("Category 2 member: ", data)
      var flag = false;
      User.find({
        EmailId: data.emailid
      }, function (err, res1) {
        if (err) throw err;
        if (res1.length > 0) {
          console.log("res1: ", res1)
          if (data.emailid == res1[0].EmailId) {
            Groupmember.create({
              GroupId: req.body.groupId,
              creatorId: req.body.creatorId,
              isJoin: req.body.isJoin,
              memberId: res1[0]._id,
              memberEmailId: res1[0].EmailId,
            }, function (err1, response) {
              if (err1) throw err;
              console.log("response1: ", response);
              createNotification(response);
            })
          }
        } else {
          Groupmember.create({
            GroupId: req.body.groupId,
            creatorId: req.body.creatorId,
            isJoin: req.body.isJoin,
            memberId: null,
            memberEmailId: data.emailid
          }, function (err1, response) {
            if (err1) throw err;
            console.log("response2: ", response);
            var groupurllink = weburl + '/?join=' + req.body.groupId._id + '&a=' + req.body.userEmail.id + '&b=' + data.emailid;
            var mailCreatedAt = moment().format('ddd, MMM D, YYYY hh:mm:ss A');
            var mailExpiredAt = moment().add(1800, 'seconds').format('ddd, MMM D, YYYY hh:mm:ss A');

            nodemailer.createTestAccount((err, account) => {
              let transporter = nodemailer.createTransport({
                service: 'gmail',
                port: 25,
                secure: false,
                auth: {
                  user: 'rahul.pentakota@cognitiveinnovations.in',
                  pass: 'anna@COGNITIVE'
                }
              });

              // setup email data with unicode symbols
              let mailOptions = {
                from: '"CHATINTACT 👻" <rahul.pentakota@cognitiveinnovations.in>',
                to: data.emailid,
                subject: 'GROUP INVITATION ✔',
                text: 'Hello. ' + req.body.userEmail.Name + ' has asked you to join the group: ' + req.body.groupId.GroupName,
                html: "Click here to join the ChatApp : " + groupurllink
                // html: 'http://localhost:4200/?'+  req.body.slug + '/' + req.body.EmailId 
              };
              console.log('mailoptions', mailOptions.html);
              User.findOne({
                EmailId: data.emailid
              }, function (err, resp) {
                console.log("Inside user query")
                if (!resp) {
                  Invitation.find({
                    $and: [{
                      EmailId: data.emailid
                    }, {
                      senderId: req.body.userEmail.id
                    }, {
                      GroupId: req.body.groupId._id
                    }]
                  }, function (err, response) {

                    if (response.length == 0) {
                      transporter.sendMail(mailOptions, (error, info) => {
                        if (error) {}
                        //  console.log("Response from nodemailer: ",info);
                        console.log("Nodemailer EMail: ", data.emailid)
                        Invitation.create({
                          EmailId: data.emailid,
                          slug: req.body.userEmail.slug,
                          urllink: groupurllink,
                          senderId: req.body.userEmail.id,
                          senderEmailId: req.body.userEmail.EmailId,
                          create_At: mailCreatedAt,
                          expire_At: mailExpiredAt,
                          GroupId: req.body.groupId._id
                        }, function (err, resp) {
                          console.log("resp: ", resp);
                        })
                      });
                    } else {
                      // return res.status(200).json("you already sent the invitation");
                      console.log("invitation Exists: ", response);
                    }
                  });
                } else {
                  // return res.status(200).json("User already is registered");
                }
              })
            });
          });
        }
        cb()
      })

    }
    //  cb()
    // });
  })
}
// Create Notification for adding member
function createNotification(data) {
  console.log("nc", data)
  var notificationdata = {
    Grid: data._id,
    senderId: data.creatorId,
    receiverid: data.memberId,
    status: data.isJoin,
    read: 'false',
    type: 'GroupRequest'
  }
  console.log("notification data2", notificationdata);

  Notification.create(notificationdata, (err, response) => {
    require('../../app').socket.emit('groupNotifications:save', response);
    if (err) throw err;
    else {
      console.log("notification ack", response);
    }
  });
}
//Invitations of groups
exports.getInvitations = function (req, res) {


  Groupmember.find({
    $and: [{
      memberId: req.params.id
    }, {
      isJoin: 'Pending'
    }, {
      deletedStatus: true
    }]
  }).populate('GroupId').populate('creatorId').populate('memberId').sort({
    create_At: -1
  }).exec(function (err, response) {
    if (err) throw err;
    return res.status(200).json(response)

  })
}
//Updating status of member
exports.updateMemberStatus = function (req, res) {
  console.log(req.body);
  if (req.body.status === 'Rejected') {
    return res.status(200).json('Rejected')
  } else {
    Groupmember.findOneAndUpdate({
      _id: req.body.id
    }, {
      $set: {
        isJoin: req.body.status
      }
    }, {
      new: true
    }).populate('creatorId').populate('memberId').populate('GroupId').exec((err, data) => {
      if (err) throw err;
      else {
        require('../../app').socket.emit('updateGroup:save', data);
        console.log("updatestatus", data);
        // Update notification updation
        Notification.findOneAndUpdate({
          Grid: data._id
        }, {
          $set: {
            status: data.isJoin
          }
        }, function (err, res) {
          if (err) throw err;
          console.log("ressssssssssssss", res);
          if (res) {
            Notification.findOne({
              _id: res._id
            }).populate('creatorId').populate('memberId').exec(function (err, updatenotifier) {
              if (err) throw err;
              else {
                console.log("updatenotifier", updatenotifier);
                // require('../../app').socket.emit('updateGroup:save',updatenotifier); // emit update friend to data
                require('../../app').socket.emit('notification:save', updatenotifier);
              }
            });
          }

        });
      }
      return res.status(200).json(data);
    })
  }

}
// Getting members list to login
exports.gettingMembers = function (req, res) {
  console.log("req.params.id", req.params.id)
  Groupmember.find({
    $and: [{
      GroupId: req.params.id
    }, {
      $or: [{
        isJoin: "Accepted"
      }, {
        isJoin: "Pending"
      }]
    }, {
      deletedStatus: true
    }, {
      isLeave: false
    }, {
      isRemoved: false
    }, {
      isBlocked: false
    }]
  }, function (err, result) {
    console.log("result: ", result);
    if (err) throw err;
    return res.status(200).json(result);
  })
}
// View members
exports.viewMembers = function (req, res) {
  Groupmember.find({
    $and: [{
      GroupId: req.params.id
    }, {
      isJoin: 'Accepted'
    }, {
      deletedStatus: true
    }]
  }).populate('GroupId').populate('creatorId').populate('memberId').exec((err, result) => {
    if (err) throw err;
    console.log(result);
    return res.status(200).json(result)

  })
}

//getting Count of members
exports.gettingCount = function (req, res) {

  Groupmember.find({
    $and: [{
      GroupId: req.params.id
    }, {
      isJoin: 'Accepted'
    }, {
      deletedStatus: true
    }]
  }, function (err, count) {
    if (err) throw err;
    return res.status(200).json(count)
  })
}
//Leave the group
exports.leaveGroup = function (req, res) {
  Groupmember.find({$and:[{
    GroupId: req.params.gid
  },{isJoin:'Accepted'}]}, (err, result) => {
    if (err) throw err
    else if (result.length == 1) {


      Group.update({
        _id: req.params.gid
      }, {
        $set: {
          deletedStatus: false
        }
      }, (err, del) => {
        if (err) throw err;
        console.log(del);
          Groupmember.updateMany({
            GroupId: req.params.gid
          }, {
            $set: {
              deletedStatus: false
            }
          },{new:true}, (err, deleteRes) => {
            if (err) throw err;
            require('../../app').socket.emit('gleave:save', deleteRes);
            return res.status(200).json(deleteRes);
          });
        })
    } else {
      Groupmember.findByIdAndUpdate({
        _id: req.params.did
      }, {
        $set: {
          deletedStatus: false
        }
      }, (err, deleteRes) => {
        if (err) throw err;
        require('../../app').socket.emit('gleave:save', deleteRes);
        return res.status(200).json(deleteRes);
      })
    }
  })


}
// Selected group details
exports.selectedGroup = (req, res) => {
  console.log("req.params", req.params);
  Groupmember.find({
    $and: [{
      GroupId: req.params.gid
    }, {
      memberId: req.params.id
    }, {
      deletedStatus: true
    }]
  }).populate('GroupId').populate('creatorId').populate('memberId').exec((err, result) => {
    if (err) throw err;
    console.log('zzzzzz', result);

    return res.status(200).json(result)

  })

}
// Updates an existing groupmember in the DB.
exports.update = function (req, res) {
  if (req.body._id) {
    delete req.body._id;
  }
  Groupmember.findById(req.params.id, function (err, groupmember) {
    if (err) {
      return handleError(res, err);
    }
    if (!groupmember) {
      return res.status(404).send('Not Found');
    }
    var updated = _.merge(groupmember, req.body);
    updated.save(function (err) {
      if (err) {
        return handleError(res, err);
      }
      return res.status(200).json(groupmember);
    });
  });
};

// Deletes a groupmember from the DB.
exports.destroy = function (req, res) {
  Groupmember.findById(req.params.id, function (err, groupmember) {
    if (err) {
      return handleError(res, err);
    }
    if (!groupmember) {
      return res.status(404).send('Not Found');
    }
    groupmember.remove(function (err) {
      if (err) {
        return handleError(res, err);
      }
      return res.status(204).send('No Content');
    });
  });
};

function handleError(res, err) {
  return res.status(500).send(err);
}