'use strict';

var mongoose = require('mongoose'),
    Schema = mongoose.Schema;

var GroupmemberSchema = new Schema({
  GroupId: { type: Schema.Types.ObjectId, ref: 'Group' },
  Role:String, // new member role
  isJoin:{type: String, default:'Pending'}, // user join or not
  isLeave: {type: Boolean, default: 'false'},
  isRemoved: {type: Boolean, default: 'false'},
  isBlocked: {type: Boolean, default: 'false'},
  ReportAbuse: {type: Number, default: 0},
  badgeCount : { type:Number, defalut: 0},
  create_At: { type: Date, required: true, default: Date.now },
  creatorId: {type: Schema.Types.ObjectId, ref: 'User' },
  memberId:{type: Schema.Types.ObjectId, ref: 'User' },
  memberEmailId:{type: String},
  deletedStatus: {type: Boolean, default: 'true'}
});

module.exports = mongoose.model('groupmember', GroupmemberSchema);