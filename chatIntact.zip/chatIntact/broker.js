var mosca = require('mosca');
var express = require('express');
var mosca = require('mosca');
var mqtt = require('mqtt');
var app = express();
var server = require('http').createServer(app);
// Connect to database  using mongoose  , useUnifiedTopology: true, useNewUrlParser: true, useCreateIndex: true 
// var client = mqtt.connect('mqtt://172.16.1.25');



//settings of mosca
var settings = {
    port:1883,
    persistence:{
        factory : mosca.persistence.Mongo,
        url : 'mongodb://localhost/testDB'
    },
    // keepalive: 1,
    // clean: false,
    // reconnectPeriod: 500 * 1
};

//creating server connection
var MoscaServer = new mosca.Server(settings);
    MoscaServer.on('ready',function() {
    console.log('Mosca server ready');
    })

    MoscaServer.on('clientConnected', function(client) {
    console.log('Client Connected:', client.id);
    });
    
    // fired when a client disconnects
    MoscaServer.on('clientDisconnected', function(client) {
    console.log('Client Disconnected:', client.id);
    });

    server.listen(3000, '172.16.1.23', function () {
        console.log('Express server listening on 3000 port');
    });
